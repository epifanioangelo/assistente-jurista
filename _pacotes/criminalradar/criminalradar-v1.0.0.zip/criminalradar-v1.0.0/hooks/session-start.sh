#!/bin/sh
# Rápido e silencioso quando está tudo certo (só lê arquivos locais; nunca acessa a rede).
DIR="$(cd "$(dirname "$0")/.." && pwd)"
if command -v python3 >/dev/null 2>&1; then exec python3 "$DIR/scripts/a100x.py" hook-session-start 2>/dev/null; fi
exit 0
