"""Layout do PDF do Radar (marca e cores vêm de marca.py)."""
from __future__ import annotations

from pathlib import Path
from typing import List, Optional

from . import NOME, PRODUTO, ROTULO, VERSAO
from .marca import M as MARCA
from .pdf import A4, PDF, hexcor, largura_texto, quebrar
from .prazos import formatar_br
from .texto import corrigir_texto_tribunal, documento_legivel, titulo_classe, truncar, uma_linha

C = {
    "navy": hexcor(MARCA["cores"]["primaria"]), "azul": hexcor(MARCA["cores"]["secundaria"]), "cinza": hexcor("#5F6B7A"), "cinza_claro": hexcor("#D9DFE7"),
    "fundo": hexcor("#F3F5F9"), "branco": (1.0, 1.0, 1.0), "preto": hexcor("#111418"), "verde": hexcor("#2E7D32"),
    "CRITICA": hexcor("#C62828"), "ALTA": hexcor("#E65100"), "MEDIA": hexcor("#B8860B"), "BAIXA": hexcor("#2E7D32"), "CANCELADA": hexcor("#757575"),
    "GARGALO": hexcor("#C62828"), "ATENCAO": hexcor("#E65100"), "VERIFICAR": hexcor("#B8860B"), "NORMAL": hexcor("#2E7D32"),
}
ROTULO_URG = {"CRITICA": "CRÍTICA", "ALTA": "ALTA", "MEDIA": "MÉDIA", "BAIXA": "BAIXA", "CANCELADA": "CANCELADA"}
ROTULO_ALERTA = {"GARGALO": "GARGALO", "ATENCAO": "ATENÇÃO", "VERIFICAR": "VERIFICAR", "NORMAL": "OK"}
MARGEM = 40.0
LARG_PAG, ALT_PAG = A4
LARG = LARG_PAG - 2 * MARGEM
RODAPE_Y = ALT_PAG - 34


def ajustar(s: str, largura: float, tam: float, bold: bool = False) -> str:
    """Trunca `s` (uma linha) para caber em `largura` pontos, com reticências."""
    s = uma_linha(s or "")
    if largura_texto(s, tam, bold) <= largura:
        return s
    lo, hi = 0, len(s)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if largura_texto(s[:mid].rstrip() + "…", tam, bold) <= largura:
            lo = mid
        else:
            hi = mid - 1
    return s[:lo].rstrip(" ,;:·-") + "…"


def org(s: str) -> str:
    return corrigir_texto_tribunal(uma_linha(s or ""))


class Doc:
    def __init__(self, modelo: dict):
        self.m = modelo
        self.pdf = PDF(titulo=f"{ROTULO} — {modelo['data_br']}", autor=NOME, assunto=f"{PRODUTO} — {modelo['data_br']}")
        self.y = 0.0
        self._pagina(primeira=True)

    # ------------------------------------------------------------------ páginas
    def _pagina(self, primeira: bool = False) -> None:
        self.pdf.nova_pagina()
        m = self.m
        if primeira:
            self.pdf.retangulo(0, 0, LARG_PAG, 78, preenchimento=C["navy"])
            self.pdf.texto(MARGEM, 34, MARCA["cabecalho"], 19, bold=True, cor=C["branco"])
            self.pdf.texto(MARGEM, 52, MARCA["subtitulo"], 8.5, cor=hexcor(MARCA["cores"]["clara"]))
            self.pdf.texto_direita(LARG_PAG - MARGEM, 32, m["data_extenso"], 11, bold=True, cor=C["branco"])
            self.pdf.texto_direita(LARG_PAG - MARGEM, 48, ajustar(m["escopo_curto"], LARG - 190, 8.5), 8.5, cor=hexcor(MARCA["cores"]["clara"]))
            self.pdf.texto_direita(LARG_PAG - MARGEM, 62, f"Janela: {formatar_br(m['janela']['inicio'])} a {formatar_br(m['janela']['fim'])}  ·  gerado às {m['hora_geracao']}", 7.5, cor=hexcor(MARCA["cores"]["suave"]))
            self.y = 100
            if m["escritorio"].get("nome"):
                resp = f"Responsável: {m['escritorio']['responsavel']}" if m["escritorio"].get("responsavel") else ""
                self.pdf.texto(MARGEM, self.y, ajustar(m["escritorio"]["nome"], LARG - largura_texto(resp, 8.5) - 16, 12, True), 12, bold=True, cor=C["navy"])
                if resp:
                    self.pdf.texto_direita(LARG_PAG - MARGEM, self.y, resp, 8.5, cor=C["cinza"])
                self.y += 20
        else:
            self.pdf.retangulo(0, 0, LARG_PAG, 30, preenchimento=C["navy"])
            self.pdf.texto(MARGEM, 19, MARCA["cabecalho"] + "  ·  " + PRODUTO.upper(), 8.5, bold=True, cor=C["branco"])
            self.pdf.texto_direita(LARG_PAG - MARGEM, 19, m["data_extenso"], 8.5, cor=hexcor(MARCA["cores"]["clara"]))
            self.y = 52

    def garantir(self, h: float) -> bool:
        if self.y + h > RODAPE_Y - 12:
            self._pagina()
            return True
        return False

    # ------------------------------------------------------------------ blocos
    def titulo(self, txt: str, sub: str = "") -> None:
        self.garantir(96)  # nunca deixa o título sozinho no fim da página
        self.pdf.texto(MARGEM, self.y + 10, txt, 13, bold=True, cor=C["navy"])
        if sub:
            livre = LARG - largura_texto(txt, 13, True) - 12
            while sub and largura_texto(sub, 8) > livre:
                sub = truncar(sub, max(0, len(sub) - 8))
            if sub:
                self.pdf.texto_direita(LARG_PAG - MARGEM, self.y + 10, sub, 8, cor=C["cinza"])
        self.pdf.retangulo(MARGEM, self.y + 16, 34, 2.2, preenchimento=C["azul"])
        self.pdf.linha(MARGEM + 34, self.y + 17.1, LARG_PAG - MARGEM, self.y + 17.1, C["cinza_claro"], 0.6)
        self.y += 30

    def kpis(self) -> None:
        k = self.m["kpis"]
        caixas = [
            ("PUBLICAÇÕES NOVAS", str(k["novas"]), C["navy"]),
            ("CRÍTICAS", str(k["criticas"]), C["CRITICA"] if k["criticas"] else C["verde"]),
            (f"PRAZOS ATÉ {k['alerta_dias']} DIAS" + (" ÚTEIS" if not k.get("penal_total") else (" CORRIDOS" if k.get("penal_total") == k.get("novas") else "")), str(k["prazos_proximos"]), C["ALTA"] if k["prazos_proximos"] else C["verde"]),
            ("PROCESSOS PARADOS", str(k["gargalos"]), C["CRITICA"] if k["gargalos"] else C["verde"]),
            ("AUDIÊNCIAS / SESSÕES", str(k.get("eventos", 0)), C["ALTA"] if k.get("eventos_7d") else (C["navy"] if k.get("eventos") else C["verde"])),
        ]
        gap, h = 10.0, 54.0
        w = (LARG - gap * (len(caixas) - 1)) / len(caixas)
        self.garantir(h + 10)
        for i, (rot, val, cor) in enumerate(caixas):
            x = MARGEM + i * (w + gap)
            self.pdf.retangulo(x, self.y, w, h, preenchimento=C["fundo"], borda=C["cinza_claro"], espessura=0.6, raio=6)
            self.pdf.retangulo(x, self.y, 4, h, preenchimento=cor)
            tam_rot = 6.8
            while largura_texto(rot, tam_rot, True) > w - 18 and tam_rot > 5.2:
                tam_rot -= 0.3
            self.pdf.texto(x + 12, self.y + 16, rot, tam_rot, bold=True, cor=C["cinza"])
            self.pdf.texto(x + 12, self.y + 42, val, 22, bold=True, cor=cor)
        self.y += h + 16
        linha = self.m["linha_resumo"]
        self.y = self.pdf.paragrafo(MARGEM, self.y + 4, linha, LARG, 9.5, cor=C["preto"], entrelinha=1.35) + 6

    def badge(self, x: float, y: float, rotulo: str, cor, tam: float = 6.8) -> float:
        w = largura_texto(rotulo, tam, True) + 10
        self.pdf.retangulo(x, y - tam - 2.5, w, tam + 6, preenchimento=cor, raio=3)
        self.pdf.texto(x + 5, y, rotulo, tam, bold=True, cor=C["branco"])
        return w

    def prioridades(self) -> None:
        itens = self.m["prioridades"]
        self.titulo("Prioridades do dia", f"{len(itens)} de {self.m['kpis']['novas']} publicações" if itens else "")
        if not itens:
            self.garantir(20)
            self.pdf.texto(MARGEM, self.y + 4, "Nenhuma publicação com prazo crítico ou alto nesta janela.", 9.5, italico=True, cor=C["cinza"])
            self.y += 22
            return
        for n, it in enumerate(itens, 1):
            tr = it["triagem"]
            resumo = self._resumo(it)
            linhas_resumo = quebrar(resumo, LARG - 24, 8.8)[:6]
            h_card = 62 + len(linhas_resumo) * 11.5
            self.garantir(h_card + 8)
            y0 = self.y
            self.pdf.retangulo(MARGEM, y0, LARG, h_card, preenchimento=C["fundo"], raio=5)
            self.pdf.retangulo(MARGEM, y0, 4, h_card, preenchimento=C.get(tr["urgencia"], C["MEDIA"]))
            x = MARGEM + 12
            self.pdf.texto(x, y0 + 15, f"{n}.", 10, bold=True, cor=C["navy"])
            x += 14
            x += self.badge(x, y0 + 15, ROTULO_URG.get(tr["urgencia"], tr["urgencia"]), C.get(tr["urgencia"], C["MEDIA"])) + 8
            self.pdf.texto(x, y0 + 15, it.get("processo") or "(sem número)", 10, bold=True, cor=C["preto"])
            largura_util = LARG - 24
            if it.get("link"):
                self.pdf.link(x, y0 + 5, largura_texto(it.get("processo") or "", 10, True), 12, it["link"])
            self.pdf.texto_direita(LARG_PAG - MARGEM - 10, y0 + 15, f"{it.get('tribunal','')}  ·  {formatar_br(it['data'])}", 8, cor=C["cinza"])
            # nome do processo não pode invadir a data à direita
            
            np_ = tr.get("nossa_parte") or {}
            parte_txt = f"  ·  nossa parte: {truncar(np_.get('nome') or '?', 40)} ({np_.get('polo')})" if np_.get("polo") in ("ativo", "passivo") else ""
            self.pdf.texto(MARGEM + 12, y0 + 28, ajustar(f"{org(it.get('orgao',''))}  ·  {titulo_classe(it.get('classe',''))}{parte_txt}", largura_util, 8), 8, cor=C["cinza"])
            self.pdf.texto(MARGEM + 12, y0 + 41, "Ação: ", 9, bold=True, cor=C["navy"])
            self.pdf.texto(MARGEM + 12 + largura_texto("Ação: ", 9, True), y0 + 41, ajustar(self._acao(it), largura_util - largura_texto("Ação: ", 9, True), 9), 9, cor=C["preto"])
            self.pdf.texto(MARGEM + 12, y0 + 53, "Prazo: ", 9, bold=True, cor=C["navy"])
            ptxt, pcor = self._prazo_txt(it)
            self.pdf.texto(MARGEM + 12 + largura_texto("Prazo: ", 9, True), y0 + 53, ajustar(ptxt, largura_util - largura_texto("Prazo: ", 9, True), 9, pcor is not None), 9, bold=pcor is not None, cor=pcor or C["preto"])
            yy = y0 + 66
            for l in linhas_resumo:
                self.pdf.texto(MARGEM + 12, yy, l, 8.8, cor=C["preto"])
                yy += 11.5
            self.y = y0 + h_card + 8

    def _resumo(self, it: dict) -> str:
        ia = it.get("ia") or {}
        if ia.get("resumo"):
            return ia["resumo"]
        corpo = (it.get("triagem") or {}).get("corpo_resumo") or ""
        return truncar(corpo or uma_linha(it.get("texto") or ""), 300) or "(publicação sem texto)"

    def _acao(self, it: dict) -> str:
        ia = it.get("ia") or {}
        tr = it["triagem"]
        tag = "[SEEU] " if tr.get("execucao_penal") else ("[penal] " if tr.get("perfil") == "penal" and MARCA.get("perfil") != "criminal" else "")
        return tag + (ia.get("acao") or tr["ato"])

    def _prazo_txt(self, it: dict):
        tr = it["triagem"]
        p = tr.get("prazo")
        if not p:
            extra = ""
            if tr.get("prazo_outra_parte"):
                extra = f" — o texto fixa {tr['prazo_outra_parte']} dias para a parte contrária"
            elif tr.get("prazo_futuro"):
                extra = f" — {tr['prazo_futuro']} dias condicionados a evento futuro (aguardar nova intimação)"
            return ("sem prazo para a nossa parte" + extra + (" (publicação cancelada)" if it.get("cancelada") else ""), None)
        restam = it.get("dias_uteis_restantes")
        cor = None
        if restam is not None and restam <= self.m["kpis"]["alerta_dias"]:
            cor = C["CRITICA"]
        base = f" · {tr['base_legal']}" if tr.get("base_legal") else ""
        obs = f" · {tr['observacao_ia']}" if tr.get("observacao_ia") else ""
        base += obs
        dobro = " · EM DOBRO" if p.get("dobro") else (" · verificar dobro" if tr.get("dobro_sugerido") else "")
        un = "corridos" if p.get("corrido") else "úteis"
        rest = f" · restam {restam} dias {un}" if restam is not None and restam >= 0 else (" · VENCIDO?" if restam is not None else "")
        return (f"{formatar_br(p['fim'])} (estimado — {p['dias']} dias {un}, origem: {tr.get('origem_prazo')}{base}{dobro}{rest})", cor)

    # ------------------------------------------------------------------ tabelas
    def tabela(self, colunas: List[tuple], linhas: List[List[dict]], tam: float = 7.6) -> None:
        """colunas: [(título, largura, alinhamento)]; célula: {"runs": [(texto, bold, cor, tam)], "link": url}"""
        pad, entre = 4.0, 1.28

        def cabecalho():
            self.pdf.retangulo(MARGEM, self.y, LARG, 16, preenchimento=C["navy"])
            x = MARGEM
            for (tit, w, _al) in colunas:
                self.pdf.texto(x + pad, self.y + 11, tit, 7.2, bold=True, cor=C["branco"])
                x += w
            self.y += 16

        # altura da primeira linha, para não deixar o cabeçalho órfão no fim da página
        def altura_linha(linha):
            alt = 0.0
            for cel, (_t, w, _a) in zip(linha, colunas):
                htot = sum(len(quebrar(txt, w - 2 * pad, t or tam, bold)) * (t or tam) * entre for (txt, bold, cor, t) in cel.get("runs", []))
                alt = max(alt, htot)
            return alt + 2 * pad + 1
        self.garantir(16 + (altura_linha(linhas[0]) if linhas else 20))
        cabecalho()
        for i, linha in enumerate(linhas):
            preparadas, alt = [], 0.0
            for cel, (_t, w, _a) in zip(linha, colunas):
                runs_q = []
                htot = 0.0
                for (txt, bold, cor, t) in cel.get("runs", []):
                    t = t or tam
                    ls = quebrar(txt, w - 2 * pad, t, bold)
                    runs_q.append((ls, bold, cor, t))
                    htot += len(ls) * t * entre
                preparadas.append(runs_q)
                alt = max(alt, htot)
            h = alt + 2 * pad + 1
            if self.garantir(h):
                cabecalho()
            if i % 2 == 0:
                self.pdf.retangulo(MARGEM, self.y, LARG, h, preenchimento=C["fundo"])
            x = MARGEM
            for cel, runs_q, (_t, w, al) in zip(linha, preparadas, colunas):
                yy = self.y + pad
                for (ls, bold, cor, t) in runs_q:
                    for l in ls:
                        yy += t
                        if al == "d":
                            self.pdf.texto_direita(x + w - pad, yy, l, t, bold=bold, cor=cor or C["preto"])
                        elif al == "c":
                            self.pdf.texto_centro(x + w / 2, yy, l, t, bold=bold, cor=cor or C["preto"])
                        else:
                            self.pdf.texto(x + pad, yy, l, t, bold=bold, cor=cor or C["preto"])
                        yy += t * (entre - 1)
                if cel.get("link"):
                    self.pdf.link(x, self.y, w, h, cel["link"])
                x += w
            self.pdf.linha(MARGEM, self.y + h, LARG_PAG - MARGEM, self.y + h, C["cinza_claro"], 0.4)
            self.y += h
        self.y += 10

    def agenda(self) -> None:
        ag = self.m.get("agenda") or []
        if not ag:
            return
        self.titulo(f"Agenda: audiências, perícias e sessões ({len(ag)})", "extraídas do texto — confira no processo")
        cols = [("QUANDO", 92, "e"), ("EVENTO", 118, "e"), ("PROCESSO · TRIBUNAL", 110, "e"), ("ÓRGÃO · NOSSA PARTE", 135, "e"), ("EM", 60, "c")]
        linhas = []
        for ev in ag:
            em = "HOJE" if ev["em_dias"] == 0 else ("amanhã" if ev["em_dias"] == 1 else (f"{ev['em_dias']} dias" if ev["em_dias"] > 1 else "ontem"))
            cor = C["CRITICA"] if 0 <= ev["em_dias"] <= 3 else (C["ALTA"] if ev["em_dias"] <= 7 else None)
            linhas.append([
                {"runs": [(formatar_br(ev["data"]) + (f"  {ev['hora']}" if ev.get("hora") else ""), True, cor or C["navy"], None)]},
                {"runs": [(ev["tipo"].capitalize() + (f" · {ev['modalidade']}" if ev.get("modalidade") else ""), True, None, None), (truncar(ev.get("frase") or "", 110), False, C["cinza"], 6.5)], "link": ev.get("link") or ""},
                {"runs": [(ev.get("processo") or "—", True, C["navy"], None), (ev.get("tribunal") or "", False, C["cinza"], 6.8)], "link": ev.get("link_processo") or ""},
                {"runs": [(truncar(org(ev.get("orgao") or ""), 60), False, None, None), (truncar(ev.get("nossa_parte") or "", 50), False, C["cinza"], 6.8)]},
                {"runs": [(em, True, cor, None)]},
            ])
        self.tabela(cols, linhas)

    def execucao_penal(self) -> None:
        """Bloco próprio das publicações de execução penal (SEEU) — só aparece quando há alguma."""
        pubs = [it for it in self.m["publicacoes"] if (it.get("triagem") or {}).get("execucao_penal")]
        if not pubs:
            return
        self.titulo(f"Execução penal · SEEU ({len(pubs)})", "intimações do SEEU chegam pelo DJEN · autos só no SEEU (login)")
        self.garantir(16)
        self.pdf.texto(MARGEM, self.y + 4, "Agravo em execução em 5 dias corridos (LEP 197; Súm. 700 STF). Andamento: DataJud quando o tribunal sincroniza; senão, seeu.pje.jus.br.", 8, italico=True, cor=C["cinza"])
        self.y += 14
        self._tabela_pubs(pubs)

    def publicacoes(self) -> None:
        pubs = self.m["publicacoes"]
        extra = f" · {self.m['ja_vistas']} já relatadas antes" if self.m.get("ja_vistas") else ""
        self.titulo(f"Todas as publicações novas ({len(pubs)})", f"DJEN · {self.m['janela_br']}{extra}")
        if not pubs:
            self.garantir(20)
            self.pdf.texto(MARGEM, self.y + 4, "Nenhuma publicação nova para os critérios monitorados nesta janela.", 9.5, italico=True, cor=C["cinza"])
            self.y += 22
            return
        self._tabela_pubs(pubs)

    def _tabela_pubs(self, pubs: List[dict]) -> None:
        cols = [("DATA", 44, "e"), ("PROCESSO · TRIBUNAL", 104, "e"), ("ÓRGÃO · TIPO", 104, "e"), ("AÇÃO · RESUMO", 174, "e"), ("URG.", 44, "c"), ("PRAZO", 45, "c")]
        linhas = []
        for it in pubs:
            tr = it["triagem"]
            urg = tr["urgencia"]
            p = tr.get("prazo")
            prazo_txt = (formatar_br(p["fim"])[:6] + p["fim"][2:4]) if p else ("outra parte" if tr.get("prazo_outra_parte") else ("condicionado" if tr.get("prazo_futuro") else "—"))
            restam = it.get("dias_uteis_restantes")
            pcor = C["CRITICA"] if (restam is not None and restam <= self.m["kpis"]["alerta_dias"]) else None
            linhas.append([
                {"runs": [(formatar_br(it["data"])[:5], False, None, None), (it["data"][:4], False, C["cinza"], 6.5)]},
                {"runs": [(it.get("processo") or "—", True, C["navy"], None), (it.get("tribunal", ""), False, C["cinza"], 6.8)], "link": it.get("link") or ""},
                {"runs": [(truncar(org(it.get("orgao", "")), 70), False, None, None), (documento_legivel(f"{it.get('tipo','')} · {it.get('documento','')}"), False, C["cinza"], 6.8)]},
                {"runs": [(truncar(self._acao(it), 90), True, None, None), (truncar(self._resumo(it), 210), False, None, 7.0)]},
                {"runs": [(ROTULO_URG.get(urg, urg), True, C.get(urg, C["MEDIA"]), None)]},
                {"runs": [(prazo_txt, pcor is not None, pcor, None), ((f"{tr['prazo_dias']}d" + ("×2" if p and p.get("dobro") else "")) if tr.get("prazo_dias") else "", False, C["cinza"], 6.5)]},
            ])
        self.tabela(cols, linhas)

    def andamentos(self) -> None:
        ands = self.m["andamentos"]
        f = self.m["fontes"]["datajud"]
        sub = f"DataJud/CNJ · {f.get('consultados', 0)} consultados · {f.get('nao_encontrados', 0)} não localizados" if f.get("ok") else "DataJud indisponível nesta execução"
        self.titulo(f"Andamento processual ({len(ands)})", sub)
        if not ands:
            self.garantir(20)
            self.pdf.texto(MARGEM, self.y + 4, "Nenhum processo consultado (cadastre processos ou ative a consulta a partir das publicações).", 9.5, italico=True, cor=C["cinza"])
            self.y += 22
            return
        cols = [("PROCESSO", 104, "e"), ("CLASSE · ÓRGÃO", 114, "e"), ("ÚLTIMO MOVIMENTO", 128, "e"), ("DATA", 53, "c"), ("PARADO", 40, "c"), ("STATUS", 76, "e")]
        linhas = []
        for a in ands:
            if not a.get("encontrado"):
                linhas.append([
                    {"runs": [(a["numero"], True, C["navy"], None), (a.get("apelido") or a.get("tribunal", ""), False, C["cinza"], 6.8)]},
                    {"runs": [("—", False, C["cinza"], None)]},
                    {"runs": [(a.get("erro") or "não localizado", False, C["cinza"], None)]},
                    {"runs": [("—", False, None, None)]}, {"runs": [("—", False, None, None)]},
                    {"runs": [("VERIFICAR", True, C["VERIFICAR"], None)]},
                ])
                continue
            um = a.get("ultimo_movimento") or {}
            al = a.get("alerta") or {}
            niv = al.get("nivel", "NORMAL")
            compl = "; ".join(um.get("complementos") or [])
            linhas.append([
                {"runs": [(a["numero"], True, C["navy"], None), (uma_linha(f"{a.get('apelido') or ''} {a.get('tribunal','')} {a.get('grau','')}").strip(), False, C["cinza"], 6.8)]},
                {"runs": [(truncar(titulo_classe(a.get("classe", "")), 60), False, None, None), (truncar(org(a.get("orgao", "")), 70), False, C["cinza"], 6.8)]},
                {"runs": [(truncar(um.get("nome", "—"), 90), False, None, None), (truncar(compl, 90), False, C["cinza"], 6.5)]},
                {"runs": [(formatar_br(um["data"]) if um.get("data") else "—", False, None, None), (f"sync {formatar_br(a['atualizado_em'])[:5]}" if a.get("atualizado_em") else "", False, C["cinza"], 6.2)]},
                {"runs": [(f"{a['dias_parado']}d" if a.get("dias_parado") is not None else "—", True, C.get(niv, C["NORMAL"]) if niv != "NORMAL" else None, None)]},
                {"runs": [(a.get("status", ""), True, C.get(niv, C["NORMAL"]), 6.8), (truncar(al.get("mensagem", ""), 170), False, C["cinza"], 6.3)]},
            ])
        self.tabela(cols, linhas)

    def checklist(self) -> None:
        self.titulo("Checklist de hoje")
        for item in self.m["checklist"]:
            ls = quebrar(item, LARG - 26, 9)
            h = len(ls) * 12 + 5
            self.garantir(h)
            self.pdf.retangulo(MARGEM + 2, self.y + 1, 9, 9, borda=C["navy"], espessura=0.8, raio=1.5)
            yy = self.y + 8.5
            for l in ls:
                self.pdf.texto(MARGEM + 18, yy, l, 9, cor=C["preto"])
                yy += 12
            self.y += h
        self.y += 6

    def notas(self) -> None:
        self.titulo("Fontes, metodologia e avisos")
        for n in self.m["notas"]:
            ls = quebrar(n, LARG - 10, 7.4)
            h = len(ls) * 9.6 + 3
            self.garantir(h)
            yy = self.y + 7
            self.pdf.texto(MARGEM, yy, "•", 7.4, cor=C["cinza"])
            for l in ls:
                self.pdf.texto(MARGEM + 8, yy, l, 7.4, cor=C["cinza"])
                yy += 9.6
            self.y += h

    def finalizar(self) -> PDF:
        total = len(self.pdf.paginas)
        for i, p in enumerate(self.pdf.paginas, 1):
            self.pdf.pag = p
            self.pdf.linha(MARGEM, RODAPE_Y - 6, LARG_PAG - MARGEM, RODAPE_Y - 6, C["cinza_claro"], 0.5)
            self.pdf.texto(MARGEM, RODAPE_Y + 4, f"{NOME} · {PRODUTO} · {self.m['data_br']} · v{VERSAO}", 7, cor=C["cinza"])
            self.pdf.texto_direita(LARG_PAG - MARGEM, RODAPE_Y + 4, f"página {i} de {total}", 7, cor=C["cinza"])
            self.pdf.texto(MARGEM, RODAPE_Y + 14, "Este relatório não substitui a leitura integral da intimação nem o controle de prazos do escritório. Prazos são estimativas — confira feriados locais e prazo em dobro.", 6.4, italico=True, cor=C["cinza"])
        return self.pdf


def gerar_pdf(modelo: dict, caminho: Path, encarte: bool = True, versao_encarte: int = 2) -> Path:
    doc = Doc(modelo)
    doc.kpis()
    doc.prioridades()
    doc.agenda()
    doc.execucao_penal()
    doc.publicacoes()
    doc.andamentos()
    doc.checklist()
    doc.notas()
    pdf = doc.finalizar()
    if encarte:
        try:
            if MARCA.get("encarte") == "criminal":
                from .pdf_encarte_criminal import Encarte
            else:
                from .pdf_encarte import Encarte
            Encarte(pdf, versao_encarte).desenhar()
        except ImportError:
            pass  # pacote sem o módulo de encarte desta marca — o Radar sai sem encarte, nunca deixa de sair
    pdf.salvar(caminho)
    return Path(caminho)
