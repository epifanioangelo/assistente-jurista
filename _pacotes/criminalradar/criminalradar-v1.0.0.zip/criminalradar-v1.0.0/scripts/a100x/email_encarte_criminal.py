"""Encarte do Núcleo de Prática Criminal com o Claude (CriminalRadar) em HTML compatível com Gmail (mesma narrativa do PDF, 3 versões)."""
from __future__ import annotations

import html as _html

from .pdf_encarte_criminal import ARQUITETURA, ERAS, IDENTIDADES, LEIS, NIVEIS, OFERTA, PIPELINE, SQUADS, VERSOES, WHATSAPP_FMT, WHATSAPP_URL

_F = "font-family:Helvetica,Arial,sans-serif"
_PRETO, _BORDO, _DOURADO, _AREIA, _CINZA, _CREME = "#111010", "#7E1F2D", "#C6A15B", "#DED6CE", "#8D8580", "#FBF8F3"


def _e(s) -> str:
    return _html.escape(str(s or ""), quote=True)


def _bloco(cor: str, extra: str = "") -> str:
    return f'bgcolor="{cor}" style="background-color:{cor};{extra}'


def html_encarte(versao: int = 2) -> str:
    v = VERSOES.get(int(versao) if str(versao).isdigit() else 2, VERSOES[2])
    eras = "".join(
        f'<td width="25%" valign="top" style="padding:0 3px"><table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr><td {_bloco("#F6E9EB" if i == 3 else _CREME, f"border-radius:6px;padding:9px 10px;{_F}")}">'
        f'<div style="font-size:9px;font-weight:bold;color:{_BORDO if i == 3 else _DOURADO}">{_e(era)}</div><div style="font-size:12px;font-weight:bold;color:{_PRETO};margin:2px 0 4px">{_e(t)}</div><div style="font-size:10.5px;color:{_PRETO};line-height:1.35">{_e(d)}</div></td></tr></table></td>'
        for i, (era, t, d) in enumerate(ERAS))
    idents = "".join(f'<td width="33%" valign="top" style="padding:0 4px;{_F}"><div style="border-left:3px solid {_BORDO if i == 2 else _DOURADO};padding-left:8px"><div style="font-size:13px;font-weight:bold;color:{_BORDO if i == 2 else _PRETO}">{_e(t)}</div><div style="font-size:11px;color:{_PRETO};line-height:1.35;margin-top:3px">{_e(d)}</div></div></td>' for i, (t, d) in enumerate(IDENTIDADES))
    niveis = " · ".join(f'<b>{_e(n)}</b> {_e(l)}' for n, l in NIVEIS)
    pipeline = " → ".join(f"<b>{_e(t)}</b>" if i in (0, 3, 4) else _e(t) for i, (_, t, _) in enumerate(PIPELINE))
    arquitetura = " · ".join(_e(a) for a in ARQUITETURA)
    squads = "".join(
        f'<tr><td {_bloco(_CREME if i % 2 == 0 else "#FFFFFF", f"border-left:2px solid {_BORDO};padding:5px 8px;font-size:10.5px;color:{_PRETO};line-height:1.35;{_F}")}"><b>{_e(n)}</b> &nbsp;·&nbsp; {_e(m)}</td></tr>'
        for i, (n, m) in enumerate(SQUADS))
    leis = "".join(f'<div style="font-size:11.5px;color:{_PRETO};line-height:1.4;margin-top:3px"><span style="font-weight:bold;color:{_DOURADO}">LEI {i + 1}</span> &nbsp;<b>{_e(l)}</b></div>' for i, l in enumerate(LEIS))
    oferta = "".join(f'<div style="font-size:11.5px;color:{_PRETO};line-height:1.4;margin-top:3px"><span style="font-weight:bold;color:{_BORDO}">{_e(t.upper())}</span> &nbsp;{_e(d)}</div>' for t, d in OFERTA)
    return f'''
<tr><td {_bloco(_PRETO, f"border-bottom:3px solid {_DOURADO};padding:22px 26px;{_F}")}">
  <div style="font-size:10px;font-weight:bold;color:{_DOURADO};letter-spacing:.5px">{_e(v["eyebrow"])}</div>
  <div style="font-size:21px;font-weight:bold;color:#fff;margin-top:8px;line-height:1.2">{_e(v["titulo"])}</div>
  <div style="font-size:14px;font-weight:bold;color:#E8E2DA;margin-top:6px;line-height:1.3">{_e(v["sub1"])} {_e(v["sub2"])}</div>
  <div style="font-size:11px;color:#B8B0A8;margin-top:8px">{_e(v["linha"])}</div>
</td></tr>
<tr><td style="padding:16px 26px 0;{_F}">
  <div style="font-size:10px;font-weight:bold;color:{_DOURADO};letter-spacing:.4px">QUATRO ERAS DA OPERAÇÃO JURÍDICA — A TECNOLOGIA MUDOU; O MODELO DE TRABALHO PRECISA MUDAR TAMBÉM</div>
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin-top:8px"><tr>{eras}</tr></table>
  <p style="font-size:13px;font-weight:bold;color:{_PRETO};line-height:1.45;margin:14px 0 0">{_e(v["intro"])}</p>
  <div style="font-size:10px;font-weight:bold;color:{_DOURADO};letter-spacing:.4px;margin-top:16px">A DEFINIÇÃO</div>
  <div style="font-size:15px;font-weight:bold;color:{_BORDO};margin-top:4px">Prompt é instrução. Pipeline é processo.</div>
  <p style="font-size:12px;color:{_PRETO};line-height:1.45;margin:6px 0 0">Orquestração é dividir o trabalho em papéis, ordem e conferências: um chefe de gabinete entende o pedido e distribui; cada especialista faz uma tarefa; os gates conferem fontes e devolvem o que reprova; você aprova antes de qualquer ato externo. Não é um modelo mais inteligente — é um método de trabalho. E, no criminal, sem fonte não há autoridade: nenhuma súmula, tese ou precedente é citado de memória.</p>
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin-top:14px"><tr>{idents}</tr></table>
  <div style="font-size:11.5px;color:{_PRETO};line-height:1.5;margin-top:12px"><span style="font-weight:bold;color:{_DOURADO}">QUATRO NÍVEIS DE UTILIZAÇÃO DA IA</span> &nbsp;{niveis}</div>
</td></tr>
<tr><td style="padding:16px 26px 0;{_F}">
  <div style="font-size:15px;font-weight:bold;color:{_PRETO}">O Criminal Squad, em uma frase</div>
  <p style="font-size:12px;color:{_PRETO};line-height:1.45;margin:6px 0 0">É uma equipe de assistentes jurídicos de IA que não dorme — cada um especialista em uma tarefa — coordenada por um chefe de gabinete que entende o pedido e distribui o trabalho. Você fala normalmente, como falaria com alguém da equipe. Sem menu. Sem comando decorado.</p>
  <div style="font-size:12px;color:{_PRETO};line-height:1.5;margin-top:10px"><span style="color:{_CINZA}">Do pedido à entrega:</span> {pipeline}. <span style="color:{_CINZA}">A revisão pode devolver o trabalho para correção. Sete peças da arquitetura: {arquitetura}. Quem manda continua sendo você.</span></div>
  <div style="font-size:10px;font-weight:bold;color:{_DOURADO};letter-spacing:.4px;margin-top:16px">MUITO ALÉM DAS PEÇAS — OS SQUADS DA OPERAÇÃO CRIMINAL</div>
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin-top:6px;border:1px solid {_AREIA};border-radius:4px">{squads}</table>
  <div style="font-size:10.5px;color:{_CINZA};margin-top:6px;font-style:italic">Um mesmo mecanismo, múltiplas operações: do processo ao site, da audiência à palestra, do áudio à estratégia.</div>
  <div style="font-size:10px;font-weight:bold;color:{_DOURADO};letter-spacing:.4px;margin-top:16px">ESCALA COM CONTROLE — AS CINCO LEIS</div>
  {leis}
  <div style="font-size:12px;font-weight:bold;color:{_BORDO};margin-top:8px">O sistema prepara. O operador decide.</div>
  <div style="font-size:10.5px;color:{_CINZA};margin-top:3px">Arquitetura local-first: arquivos e ferramentas locais; indexação e acervo controlados pelo operador; envio ao modelo conforme provedor e configuração.</div>
  <div style="font-size:15px;font-weight:bold;color:{_PRETO};margin-top:16px">Núcleo de Prática Criminal com o Claude</div>
  <div style="font-size:11px;color:{_CINZA};margin-top:2px">Criminal Squad é a tecnologia. O Núcleo é a implementação — formação, implementação e prática continuada durante 12 meses.</div>
  <div style="margin-top:6px">{oferta}</div>
  <p style="font-size:11.5px;color:{_PRETO};line-height:1.45;margin:10px 0 0">Você recebe: CriminalSquad instalado na sua máquina, pronto para rodar · FirmaOS, o segundo cérebro no Claude · trilha quinzenal de IA na prática jurídica · trilha quinzenal de atualização jurídica criminal · grupo exclusivo no WhatsApp · garantia de 15 dias após a matrícula.</p>
  <div style="font-size:11.5px;font-weight:bold;color:{_BORDO};margin-top:6px">O CriminalRadar que você acabou de ler — DJEN + SEEU + DataJud — é a primeira peça instalada.</div>
</td></tr>
<tr><td style="padding:16px 26px 22px;{_F}">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr><td {_bloco(_PRETO, f"border-left:5px solid {_DOURADO};border-radius:8px;padding:18px 20px;{_F}")}">
    <div style="font-size:15px;font-weight:bold;color:#fff">{_e(v["cta_titulo"])}</div>
    <div style="font-size:12px;color:#E8E2DA;line-height:1.45;margin-top:6px">{_e(v["cta_corpo"])}</div>
    <table role="presentation" cellspacing="0" cellpadding="0" style="margin-top:12px"><tr><td {_bloco("#25D366", "border-radius:22px;padding:11px 20px;font-size:14px;font-weight:bold")}"><a href="{_e(WHATSAPP_URL)}" style="color:#fff;text-decoration:none">Ficha de interesse pelo WhatsApp · {_e(WHATSAPP_FMT)}</a></td></tr></table>
    <div style="font-size:10px;color:#B8B0A8;margin-top:10px">A peça é uma entrega. A operação é o futuro. <b style="color:{_DOURADO}">E QUEM MANDA CONTINUA SENDO VOCÊ.</b> O sistema prepara. O operador decide. Revisão humana em toda entrega.</div>
  </td></tr></table>
</td></tr>'''
