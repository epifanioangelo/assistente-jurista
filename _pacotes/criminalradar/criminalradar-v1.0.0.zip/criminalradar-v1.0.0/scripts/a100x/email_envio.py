"""Envio do Radar por e-mail via SMTP (stdlib). Suporta STARTTLS (587), SSL (465) ou sem TLS."""
from __future__ import annotations

import smtplib
import socket
import ssl
from email.message import EmailMessage
from email.utils import formataddr, make_msgid
from pathlib import Path
from typing import Iterable, List, Optional

from . import NOME, ROTULO, VERSAO
from .config import senha_smtp


class ErroEmail(Exception):
    pass


PROVEDORES = {
    "gmail.com": ("smtp.gmail.com", 587, "starttls"),
    "googlemail.com": ("smtp.gmail.com", 587, "starttls"),
    "outlook.com": ("smtp-mail.outlook.com", 587, "starttls"),
    "hotmail.com": ("smtp-mail.outlook.com", 587, "starttls"),
    "live.com": ("smtp-mail.outlook.com", 587, "starttls"),
    "office365.com": ("smtp.office365.com", 587, "starttls"),
    "icloud.com": ("smtp.mail.me.com", 587, "starttls"),
    "me.com": ("smtp.mail.me.com", 587, "starttls"),
    "yahoo.com": ("smtp.mail.yahoo.com", 465, "ssl"),
    "yahoo.com.br": ("smtp.mail.yahoo.com", 465, "ssl"),
    "zoho.com": ("smtp.zoho.com", 465, "ssl"),
    "uol.com.br": ("smtps.uol.com.br", 587, "starttls"),
    "bol.com.br": ("smtps.bol.com.br", 587, "starttls"),
    "terra.com.br": ("smtp.terra.com.br", 587, "starttls"),
}


# Relays transacionais recomendados (não dependem do provedor do e-mail do escritório)
RELAYS = {
    # Brevo: grátis 300/dia, remetente verificado por clique (sem precisar de domínio); usuário = e-mail da conta Brevo, senha = chave SMTP
    "brevo": {"host": "smtp-relay.brevo.com", "porta": 587, "seguranca": "starttls", "usuario_dica": "e-mail de login da conta Brevo", "senha_dica": "chave SMTP (Brevo → SMTP & API → SMTP)", "remetente_dica": "remetente verificado em Brevo → Remetentes"},
    # Resend: grátis 3.000/mês (100/dia), exige domínio verificado; usuário fixo "resend", senha = API key
    "resend": {"host": "smtp.resend.com", "porta": 465, "seguranca": "ssl", "usuario": "resend", "senha_dica": "API key (Resend → API Keys)", "remetente_dica": "endereço no domínio verificado no Resend"},
}


def sugerir_smtp(endereco: str) -> Optional[dict]:
    """Preset por provedor do e-mail (gmail.com, outlook.com…) ou por relay ("brevo", "resend")."""
    chave = (endereco or "").strip().lower()
    if chave in RELAYS:
        r = dict(RELAYS[chave])
        return {"host": r["host"], "porta": r["porta"], "seguranca": r["seguranca"], "usuario": r.get("usuario", ""), "dicas": {k: v for k, v in r.items() if k.endswith("_dica")}, "relay": chave}
    dom = chave.rsplit("@", 1)[-1]
    if dom in PROVEDORES:
        h, p, s = PROVEDORES[dom]
        return {"host": h, "porta": p, "seguranca": s, "usuario": endereco}
    return None


def _conectar(smtp: dict, timeout: int = 60):
    host, porta, seg = smtp.get("host", ""), int(smtp.get("porta") or 587), (smtp.get("seguranca") or "starttls").lower()
    ctx = ssl.create_default_context()
    if seg == "ssl":
        return smtplib.SMTP_SSL(host, porta, timeout=timeout, context=ctx)
    s = smtplib.SMTP(host, porta, timeout=timeout)
    s.ehlo()
    if seg == "starttls":
        s.starttls(context=ctx)
        s.ehlo()
    return s


def montar(cfg: dict, assunto: str, html: str, texto: str, anexos: Iterable[Path] = (), destinatarios: Optional[List[str]] = None) -> EmailMessage:
    email = cfg.get("email") or {}
    smtp = email.get("smtp") or {}
    brutos = destinatarios or email.get("destinatarios") or []
    if isinstance(brutos, str):
        brutos = brutos.split(",")
    dest = [d.strip() for d in brutos if d and d.strip()]
    if not dest:
        raise ErroEmail("Nenhum destinatário configurado.")
    remetente = email.get("remetente") or smtp.get("usuario") or ""
    if not remetente:
        raise ErroEmail("Remetente não configurado (email.remetente ou email.smtp.usuario).")
    msg = EmailMessage()
    msg["Subject"] = assunto
    msg["From"] = formataddr((email.get("nome_remetente") or ROTULO, remetente))
    msg["To"] = ", ".join(dest)
    msg["Message-ID"] = make_msgid(domain=remetente.rsplit("@", 1)[-1] or "radar.local")
    msg["X-Mailer"] = f"{NOME} Radar {VERSAO}"
    msg.set_content(texto)
    msg.add_alternative(html, subtype="html")
    for a in anexos:
        p = Path(a)
        sub = "pdf" if p.suffix.lower() == ".pdf" else "octet-stream"
        msg.add_attachment(p.read_bytes(), maintype="application", subtype=sub, filename=p.name)
    return msg


def enviar(cfg: dict, assunto: str, html: str, texto: str, anexos: Iterable[Path] = (), destinatarios: Optional[List[str]] = None, log=None) -> dict:
    email = cfg.get("email") or {}
    smtp = email.get("smtp") or {}
    msg = montar(cfg, assunto, html, texto, anexos, destinatarios)
    senha = senha_smtp(cfg)
    host, porta, seg = smtp.get("host", ""), smtp.get("porta"), smtp.get("seguranca")
    if not host:
        raise ErroEmail("Servidor SMTP não configurado (email.smtp.host).")
    try:
        with _conectar(smtp) as s:
            if smtp.get("usuario"):
                s.login(smtp["usuario"], senha)
            s.send_message(msg)
    except smtplib.SMTPAuthenticationError as e:
        raise ErroEmail("Autenticação SMTP recusada. No Gmail/Google Workspace e no Outlook é preciso usar uma SENHA DE APP "
                        f"(não a senha normal) e o usuário deve ser o e-mail completo. Detalhe do servidor: {e.smtp_error!r}") from e
    except smtplib.SMTPRecipientsRefused as e:
        raise ErroEmail(f"Destinatário recusado pelo servidor: {e.recipients}") from e
    except (smtplib.SMTPSenderRefused, smtplib.SMTPDataError) as e:
        raise ErroEmail(f"O servidor recusou a mensagem: {e}") from e
    except (smtplib.SMTPConnectError, smtplib.SMTPServerDisconnected) as e:
        raise ErroEmail(f"Conexão com {host}:{porta} ({seg}) caiu ou foi recusada: {e}") from e
    except smtplib.SMTPException as e:  # antes de OSError — SMTPException herda de OSError
        raise ErroEmail(f"Falha SMTP: {e}") from e
    except (socket.gaierror, socket.timeout, ConnectionRefusedError, ssl.SSLError, OSError) as e:
        raise ErroEmail(f"Não foi possível falar com {host}:{porta} ({seg}). Confira host/porta/segurança e a conexão. Detalhe: {e}") from e
    if log:
        log(f"  e-mail enviado para {', '.join(msg['To'].split(', '))}")
    return {"ok": True, "destinatarios": msg["To"].split(", "), "anexos": [Path(a).name for a in anexos]}
