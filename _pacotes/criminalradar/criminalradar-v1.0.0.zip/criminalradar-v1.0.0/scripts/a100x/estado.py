"""Estado persistente do Radar: publicações já relatadas (dedup), histórico de execuções e lock."""
from __future__ import annotations

import json
import os
import time
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Iterable, List, Optional, Tuple

from .config import base_dir


class ErroLock(Exception):
    pass


def caminho_estado() -> Path:
    return base_dir() / "estado.json"


def _vazio() -> dict:
    return {"versao": 1, "publicacoes_vistas": {}, "runs": [], "ultimo_run": None, "ultimo_ok": None}


def carregar() -> dict:
    p = caminho_estado()
    if not p.exists():
        return _vazio()
    try:
        e = json.loads(p.read_text(encoding="utf-8") or "{}")
    except json.JSONDecodeError:
        p.rename(p.with_suffix(f".corrompido-{int(time.time())}.json"))
        return _vazio()
    base = _vazio()
    base.update(e)
    return base


def salvar(estado: dict) -> None:
    p = caminho_estado()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(estado, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    os.replace(tmp, p)


def filtrar_novas(estado: dict, itens: Iterable[dict]) -> Tuple[List[dict], List[dict]]:
    vistas = estado.setdefault("publicacoes_vistas", {})
    novas, antigas = [], []
    for it in itens:
        k = str(it.get("id") or it.get("hash") or "")
        (antigas if k and k in vistas else novas).append(it)
    return novas, antigas


def marcar_vistas(estado: dict, itens: Iterable[dict], quando: Optional[date] = None) -> None:
    q = (quando or date.today()).isoformat()
    vistas = estado.setdefault("publicacoes_vistas", {})
    for it in itens:
        k = str(it.get("id") or it.get("hash") or "")
        if k:
            vistas[k] = q


def podar(estado: dict, dias: int = 120) -> int:
    limite = (date.today() - timedelta(days=dias)).isoformat()
    vistas = estado.setdefault("publicacoes_vistas", {})
    velhas = [k for k, v in vistas.items() if (v or "") < limite]
    for k in velhas:
        del vistas[k]
    return len(velhas)


def registrar_run(estado: dict, resumo: dict) -> None:
    resumo = dict(resumo)
    resumo.setdefault("quando", datetime.now().isoformat(timespec="seconds"))
    runs = estado.setdefault("runs", [])
    runs.append(resumo)
    del runs[:-60]
    estado["ultimo_run"] = resumo
    if resumo.get("ok"):
        estado["ultimo_ok"] = resumo["quando"]
        if resumo.get("email_enviado"):
            estado["ultimo_email"] = resumo["quando"]


def gerou_hoje(estado: dict, hoje: Optional[date] = None) -> bool:
    hoje = hoje or date.today()
    ur = estado.get("ultimo_run") or {}
    return bool(ur.get("ok")) and str(ur.get("quando", "")).startswith(hoje.isoformat())


class Lock:
    """Lock de arquivo para impedir duas execuções simultâneas.

    macOS/Linux: fcntl.flock (o kernel libera quando o processo morre — não há lock "velho").
    Windows: O_EXCL com quebra de lock antigo.
    """

    def __init__(self, nome: str = "radar.lock", expira_seg: int = 2 * 3600):
        self.caminho = base_dir() / nome
        self.expira = expira_seg
        self.fd: Optional[int] = None
        self._flock = None
        try:
            import fcntl  # noqa: F401
            self._flock = fcntl
        except ImportError:
            self._flock = None

    def __enter__(self):
        self.caminho.parent.mkdir(parents=True, exist_ok=True)
        if self._flock:
            self.fd = os.open(self.caminho, os.O_CREAT | os.O_RDWR, 0o600)
            try:
                self._flock.flock(self.fd, self._flock.LOCK_EX | self._flock.LOCK_NB)
            except OSError:
                os.close(self.fd)
                self.fd = None
                try:
                    idade = int(time.time() - self.caminho.stat().st_mtime)
                except FileNotFoundError:
                    idade = 0
                raise ErroLock(f"Outra execução do Radar está em andamento (lock: {self.caminho}, há {idade}s).")
            try:
                os.ftruncate(self.fd, 0)
                os.write(self.fd, f"{os.getpid()} {time.time()}".encode())
            except OSError:
                pass
            return self
        for _ in range(2):
            try:
                self.fd = os.open(self.caminho, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                try:
                    os.write(self.fd, f"{os.getpid()} {time.time()}".encode())
                except OSError:
                    pass
                return self
            except FileExistsError:
                try:
                    idade = time.time() - self.caminho.stat().st_mtime
                except FileNotFoundError:
                    continue
                if idade > self.expira:
                    self.caminho.unlink(missing_ok=True)
                    continue
                raise ErroLock(f"Outra execução do Radar está em andamento há {int(idade)}s (lock: {self.caminho}).")
        raise ErroLock("não foi possível obter o lock")

    def __exit__(self, *exc):
        if self.fd is not None:
            try:
                if self._flock:
                    self._flock.flock(self.fd, self._flock.LOCK_UN)
                os.close(self.fd)
            except OSError:
                pass
            self.fd = None
        if not self._flock:
            self.caminho.unlink(missing_ok=True)
        return False
