"""Marca do produto (camada de white-label do motor).

O mesmo motor serve a mais de um produto (Advocacia 100X · Radar Processual, CriminalRadar…).
Tudo que é nome, pasta, cor, oferta e perfil de triagem vem daqui. Sem `marca.json` na raiz do plugin
(ou na variável RADAR_MARCA), vale o padrão Advocacia 100X. Este módulo não importa nada do pacote.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

PADRAO: Dict[str, Any] = {
    "id": "advocacia-100x",                      # id do plugin (marketplace/plugin.json), CLI e prefixo das skills
    "nome": "Advocacia 100X",
    "produto": "Radar Processual",
    "cabecalho": "ADVOCACIA 100X",              # faixa do PDF e do e-mail
    "subtitulo": "RADAR PROCESSUAL DIÁRIO",
    "pasta_home": ".advocacia-100x",            # ~/<pasta_home>: config, estado, relatórios, logs
    "env_home": "A100X_HOME",                   # variável que redireciona a pasta home (testes)
    "env_prefixo": "A100X",                     # prefixo das demais variáveis (<PREFIXO>_SMTP_SENHA, <PREFIXO>_DATAJUD_KEY)
    "pasta_instalacao": "Advocacia100X",        # ~/<pasta_instalacao>/<id>: cópia instalada pelo instalador
    "launchd_label": "com.advocacia100x.radar",
    "marcador_cron": "# advocacia-100x-radar",
    "tarefa_windows": "Advocacia100X Radar",
    "prefixo_arquivo": "Radar-Advocacia100X",   # nome dos PDFs/HTML/JSON gerados
    "user_agent": "Advocacia100X-Radar",
    "site": "https://advocacia100x.com.br",
    "perfil": "civel",                          # perfil de triagem: civel | criminal | auto (detecta por publicação)
    "encarte": "acelerador",                    # encarte institucional: acelerador | criminal
    "oferta": "Acelerador de Advocacia 100X",
    "publico": "escritório de advocacia",
    "whatsapp": "5581988440860",
    "whatsapp_fmt": "(81) 98844-0860",
    "whatsapp_msg": "Olá, recebi o Radar Advocacia 100X e quero conhecer o Acelerador.",
    "cta_email": "Conhecer o Acelerador de Advocacia 100X",
    "cores": {"primaria": "#0F2545", "secundaria": "#2E6BFF", "destaque": "#2E6BFF", "clara": "#B9C6DA", "suave": "#8FA3C2", "fundo": "#F3F5F9"},
}


def raiz_plugin() -> Path:
    return Path(__file__).resolve().parents[2]


def carregar() -> Dict[str, Any]:
    m = json.loads(json.dumps(PADRAO))
    cand = os.environ.get("RADAR_MARCA") or str(raiz_plugin() / "marca.json")
    try:
        p = Path(cand).expanduser()
        if os.environ.get("RADAR_MARCA") and not p.is_file():
            import sys
            print(f"[marca] RADAR_MARCA aponta para arquivo inexistente ({p}) — usando a marca padrão", file=sys.stderr)
        if p.is_file():
            dados = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(dados, dict):
                cores = dict(m["cores"]); cores.update(dados.get("cores") or {})
                m.update({k: v for k, v in dados.items() if k != "cores"})
                m["cores"] = cores
    except (OSError, ValueError) as e:
        # marca inválida → padrão (o motor nunca pode deixar de rodar por causa da marca), mas avisa no stderr
        import sys
        print(f"[marca] marca.json inválido ({e}) — usando a marca padrão", file=sys.stderr)
    m.setdefault("cli", m["id"])
    m.setdefault("rotulo", f"Radar {m['nome']}")  # como o produto é chamado em assuntos/títulos ("Radar Advocacia 100X", "CriminalRadar")
    m.setdefault("skill_prefixo", f"/{m['id']}:")
    m["whatsapp_url"] = "https://wa.me/" + str(m["whatsapp"]) + "?text=" + _quote(m["whatsapp_msg"])
    return m


def _quote(s: str) -> str:
    from urllib.parse import quote
    return quote(s, safe="")


M = carregar()


def skill(nome: str) -> str:
    """'/advocacia-100x:configurar' ou '/criminalradar:configurar'."""
    return f"{M['skill_prefixo']}{nome}"
