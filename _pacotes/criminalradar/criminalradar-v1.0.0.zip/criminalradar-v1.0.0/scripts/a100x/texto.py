"""Utilitários de texto: limpeza de HTML do DJEN, normalização e truncamento."""
from __future__ import annotations

import html as _html
import re
import unicodedata

_RE_SCRIPT = re.compile(r"<(script|style)[^>]*>.*?</\1>", re.S | re.I)
_RE_QUEBRA = re.compile(r"</?(br|p|div|section|article|header|footer|li|tr|h[1-6]|table|ul|ol)[^>]*>", re.I)
_RE_TAG = re.compile(r"<[^>]+>")
_RE_ESPACOS = re.compile(r"[ \t\r\f\v ]+")
_RE_LINHAS = re.compile(r"\n\s*\n+")


def limpar_html(s: str) -> str:
    if not s:
        return ""
    s = _RE_SCRIPT.sub(" ", s)
    s = _RE_QUEBRA.sub("\n", s)
    s = _RE_TAG.sub(" ", s)
    s = _html.unescape(s)
    s = _RE_ESPACOS.sub(" ", s)
    s = "\n".join(l.strip() for l in s.split("\n"))
    s = _RE_LINHAS.sub("\n\n", s)
    return s.strip()


def uma_linha(s: str) -> str:
    return re.sub(r"\s+", " ", s or "").strip()


def sem_acentos(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", s or "") if not unicodedata.combining(c))


def chave(s: str) -> str:
    """Forma canônica para casar palavras-chave: minúsculas, sem acentos, espaços únicos."""
    return uma_linha(sem_acentos(s).lower())


def truncar(s: str, n: int, sufixo: str = "…") -> str:
    s = s or ""
    if len(s) <= n:
        return s
    corte = s[: max(0, n - len(sufixo))]
    if " " in corte[-20:]:
        corte = corte[: corte.rfind(" ")]
    return corte.rstrip(" ,;:.") + sufixo


def plural(n: int, singular: str, plural_: str) -> str:
    return f"{n} {singular if n == 1 else plural_}"


_MOJIBAKE = [
    (r"(\d)\?(\s|$)", r"\1ª\2"), (r"C\?VEL", "CÍVEL"), (r"C\?veis", "Cíveis"), (r"C\?VEIS", "CÍVEIS"), (r"BRAS\?LIA", "BRASÍLIA"), (r"Bras\?lia", "Brasília"),
    (r"JU\?ZO", "JUÍZO"), (r"Ju\?zo", "Juízo"), (r"FAM\?LIA", "FAMÍLIA"), (r"Fam\?lia", "Família"), (r"\?RF\?OS", "ÓRFÃOS"), (r"SUCESS\?ES", "SUCESSÕES"),
    (r"EXECU\?\?O", "EXECUÇÃO"), (r"EXECU\?\?ES", "EXECUÇÕES"), (r"P\?BLIC", "PÚBLIC"), (r"P\?blic", "Públic"), (r"PRECAT\?RIOS", "PRECATÓRIOS"), (r"INF\?NCIA", "INFÂNCIA"),
    (r"COMPET\?NCIA", "COMPETÊNCIA"), (r"GEN\?RIC", "GENÉRIC"), (r"AUDI\?NCIA", "AUDIÊNCIA"), (r"CONCILIA\?\?O", "CONCILIAÇÃO"), (r"MEDIA\?\?O", "MEDIAÇÃO"),
    (r"FAL\?NCIAS", "FALÊNCIAS"), (r"RECUPERA\?\?O", "RECUPERAÇÃO"), (r"VIOL\?NCIA", "VIOLÊNCIA"), (r"DOM\?STICA", "DOMÉSTICA"), (r"TR\?NSITO", "TRÂNSITO"),
    (r"CRIMIN\?", "CRIMINA"), (r"TRIBUT\?RI", "TRIBUTÁRI"), (r"AGR\?RI", "AGRÁRI"), (r"ORG\?NIC", "ORGÂNIC"), (r"REL\?", "RELA"), (r"REGI\?O", "REGIÃO"), (r"SE\?\?O", "SEÇÃO"), (r"Se\?\?o", "Seção"),
    (r"JUDICI\?RI", "JUDICIÁRI"), (r"COMPET\?NCIA", "COMPETÊNCIA"), (r"MUNIC\?PIO", "MUNICÍPIO"), (r"JU\?ZES", "JUÍZES"), (r"C\?MARA", "CÂMARA"), (r"C\?mara", "Câmara"),
    (r"REGISTRO P\?BLICO", "REGISTRO PÚBLICO"), (r"FAZ\. P\?B", "FAZ. PÚB"), (r"A\?\?ES", "AÇÕES"), (r"A\?\?O", "AÇÃO"),
]
_RE_MOJI = [(re.compile(a), b) for a, b in _MOJIBAKE]


def corrigir_texto_tribunal(s: str) -> str:
    """Repara acentos perdidos na origem (DataJud/TJDFT entrega '7? VARA C?VEL DE BRAS?LIA')."""
    if not s or "?" not in s:
        return s or ""
    for rx, rep in _RE_MOJI:
        s = rx.sub(rep, s)
    return s


_MINUSCULAS = {"de", "da", "do", "das", "dos", "e", "em", "a", "o", "no", "na", "nos", "nas", "por", "com", "para", "ao", "à", "às", "aos"}


def titulo_classe(s: str) -> str:
    """'PROCEDIMENTO COMUM CíVEL' → 'Procedimento Comum Cível'; mantém siglas curtas (JEC, ED)."""
    s = corrigir_texto_tribunal(uma_linha(s or ""))
    if not s:
        return ""
    palavras = []
    for i, w in enumerate(s.split(" ")):
        wl = w.lower()
        if i and wl in _MINUSCULAS:
            palavras.append(wl)
        elif len(w) <= 3 and w.isupper() and w.isalpha():
            palavras.append(w)
        else:
            palavras.append(wl[:1].upper() + wl[1:])
    return " ".join(palavras)


def documento_legivel(s: str) -> str:
    """'Despacho_Intimação_Intimação (Outros)' → 'Despacho · Intimação (Outros)' (sem repetições)."""
    partes = [uma_linha(x) for x in re.split(r"[_/|]+", s or "") if uma_linha(x)]
    vistos, saida = set(), []
    for x in partes:
        k = chave(x)
        if k in vistos:
            continue
        vistos.add(k)
        saida.append(x)
    return " · ".join(saida)
