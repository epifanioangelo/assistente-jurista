"""Classificação de publicações do DJEN (v2) — corpo dispositivo, nossa parte/polo, prazo dirigido e regras cientes do polo.

Determinística. A IA, quando presente, refina (política definida em `combinar_ia`).
"""
from __future__ import annotations

import re
from datetime import date
from typing import Dict, Iterable, List, Optional, Set, Tuple

from . import penal, prazos
from .texto import chave, uma_linha

URGENCIAS = ("CRITICA", "ALTA", "MEDIA", "BAIXA")

# ----------------------------------------------------------------------------- papéis processuais
ATIVO = r"autor|autora|autores|exequente|exequentes|requerente|requerentes|embargante|apelante|agravante|impugnante|recorrente|reclamante|demandante|impetrante|credor|credora|habilitante|suscitante|exeqte|reqte|apte|agte|embargte|recte|impte|agravte|apelte"
PASSIVO = r"reu|re|reus|res|executad[oa]s?|requerid[oa]s?|embargad[oa]s?|apelad[oa]s?|agravad[oa]s?|impugnad[oa]s?|recorrid[oa]s?|reclamad[oa]s?|demandad[oa]s?|impetrad[oa]s?|devedor|devedora|devedores|suscitad[oa]|exectd[oa]|reqd[oa]|apd[oa]|agd[oa]|embargd[oa]|recd[oa]|impd[oa]|agravd[oa]|apeld[oa]"
GENERICO = r"partes?|interessad[oa]s?|advogad[oa]s?|patron[oa]s?|procurador(es|a)?"
# penal: papéis exclusivos do processo penal (entram sempre — não existem no cível); MP/defesa só no modo penal (no cível o MP é custos legis)
ATIVO_P = r"querelante|assistente (de|da) acusacao|vitima|ofendid[oa]"
PASSIVO_P = r"acusad[oa]s?|denunciad[oa]s?|indiciad[oa]s?|investigad[oa]s?|reeducand[oa]s?|apenad[oa]s?|sentenciad[oa]s?|condenad[oa]s?|paciente|querelad[oa]s?|autor(a)? do fato|representad[oa]s?|flagrantead[oa]s?|custodiad[oa]s?|averiguad[oa]s?"
_ATIVO_REC, _PASSIVO_REC = ATIVO, PASSIVO  # papéis do recurso/ação (sem os exclusivamente penais) — base da direção no modo penal
ATIVO_PENAL = ATIVO + "|" + ATIVO_P + "|" + penal.ATIVO_PENAL
PASSIVO_PENAL = PASSIVO + "|" + PASSIVO_P + "|" + penal.PASSIVO_PENAL
ATIVO = ATIVO + "|" + ATIVO_P
PASSIVO = PASSIVO + "|" + PASSIVO_P
_RE_PARTE = re.compile(r"^\s*([A-ZÇÃÕÉÊÍÓÚÂÁÀ/() \.]{2,40}?)\s*:\s*(.+?)\s*$")
_RE_ADV = re.compile(r"^\s*ADVOGAD[OA]\(?A?\)?\s*:\s*(.+?)\s*\(OAB\s*([A-Z]{2})\s*0*(\d+)\)", re.I)
_RE_OAB_QUALQUER = re.compile(r"\(OAB\s*([A-Z]{2})\s*0*(\d+)\)", re.I)


def polo_do_papel(papel: str) -> str:
    p0 = uma_linha(chave(papel).replace("(a)", "").replace("(s)", "").replace("(es)", ""))
    p1 = uma_linha(re.sub(r"\b(parte|polo|co|litisconsorte|do|da|de|o|a)\b", " ", p0))
    for p in (p0, p1):  # "AUTOR DO FATO" / "ASSISTENTE DE ACUSAÇÃO" casam inteiros; "PARTE AUTORA" cai na forma reduzida
        if re.fullmatch(rf"({ATIVO_PENAL})", p):
            return "ativo"
        if re.fullmatch(rf"({PASSIVO_PENAL})", p):
            return "passivo"
    return "outro"


_PAPEIS = r"(?:AUTOR|AUTORA|AUTORES|R[ÉE]U|R[ÉE]|R[ÉE]US|EXEQUENTE|EXECUTAD[OA]|REQUERENTE|REQUERID[OA]|EMBARGANTE|EMBARGAD[OA]|APELANTE|APELAD[OA]|AGRAVANTE|AGRAVAD[OA]|IMPUGNANTE|IMPUGNAD[OA]|RECORRENTE|RECORRID[OA]|RECLAMANTE|RECLAMAD[OA]|DEMANDANTE|DEMANDAD[OA]|IMPETRANTE|IMPETRAD[OA]|CREDOR|CREDORA|DEVEDOR|DEVEDORA|SUSCITANTE|SUSCITAD[OA]|HABILITANTE|INTERESSAD[OA]|TERCEIRO|PERITO|TESTEMUNHA|EMBARGTE|EMBARGD[OA]|APTE|APD[OA]|AGTE|AGD[OA]|EXEQTE|EXECTD[OA]|REQTE|REQD[OA]|RECTE|RECD[OA]|IMPTE|IMPD[OA]|" + penal.PAPEIS_PENAL + r")"
_RE_ROTULO = re.compile(rf"\b(?:ADVOGAD[OA]S?\s*(?:do\(a\)|da|do|de)?\s*)?((?:PARTE\s+|CO-?|LITIS\w*\s+)?{_PAPEIS}(?:\(S\)|\(ES\)|S)?)\s*(?:\(S\)|\(ES\))?\s*[:\-–]\s*", re.I)
_RE_OAB_MENCAO_TPL = r"(?:\(?\s*OAB\s*[:\-]?\s*{uf}\s*0*{n}\b|\(?\s*OAB\s*[:\-]?\s*0*{n}\s*[/\-]\s*{uf}\b|\b{uf}\s*0*{n}\b|\b0*{n}\s*[/\-]\s*{uf}\b)"


def _nome_apos_rotulo(texto: str, m: "re.Match") -> str:
    """Nome que segue o rótulo 'PAPEL :' até o próximo rótulo/quebra."""
    trecho = texto[m.end():m.end() + 160]
    trecho = re.split(r"\n|\s{2,}|\s-\s|\s(?:ADVOGAD|OAB|Advogado|Advs?:|registrad[oa])|\s(?=[A-ZÇÃÕÉ][A-Za-zÇÃÕÉçãõé()]{2,}\s*[:\-–])|\s\(", trecho)[0]
    trecho = re.sub(r"^\s*\d+\.\s*", "", trecho)  # "2. BANCO X" → "BANCO X"
    return uma_linha(trecho)[:80]


def nossa_parte_por_oab(texto: str, oabs: Iterable[Tuple[str, str]]) -> Optional[dict]:
    """Rótulo de papel processual mais próximo ANTES da menção à nossa OAB (eproc, PJe federal/BA, STJ, TJSE…)."""
    cab = texto[:4000]
    for n, uf in oabs:
        n, uf = str(n).lstrip("0"), str(uf).upper()
        if not n or len(uf) != 2:
            continue
        rx = re.compile(_RE_OAB_MENCAO_TPL.format(n=re.escape(n), uf=uf), re.I)
        for m in rx.finditer(cab):
            antes = cab[:m.start()]
            rotulos = [r_ for r_ in _RE_ROTULO.finditer(antes) if m.start() - r_.end() <= 450]  # rótulo precisa estar perto da OAB
            if not rotulos:
                continue
            # rótulo mais próximo cujo papel não seja "advogado do(a) X" sem parte — pega o último
            r = rotulos[-1]
            papel = r.group(1)
            polo = polo_do_papel(papel)
            if polo == "outro" and len(rotulos) > 1:
                r = rotulos[-2]
                papel = r.group(1)
                polo = polo_do_papel(papel)
            # penal: "RÉU: X … VÍTIMA: Y … ADVOGADO: nós" — a vítima/MP não constitui advogado privado; fica com o último rótulo de defesa
            if re.search(r"v[ií]tima|ofendid|minist[eé]rio p[uú]blico|promotor", chave(papel)) and len(rotulos) > 1:
                for r2 in reversed(rotulos[:-1]):
                    if re.search(rf"^(?:{penal.PAPEIS_PENAL}|R[ÉE]U|R[ÉE]|R[ÉE]US)$", uma_linha(r2.group(1)).upper().replace("(A)", "").replace("(S)", "").strip()) and polo_do_papel(r2.group(1)) == "passivo":
                        r, papel, polo = r2, r2.group(1), "passivo"
                        break
            return {"papel": uma_linha(papel), "nome": _nome_apos_rotulo(antes, r) or None, "polo": polo, "origem": "cabecalho"}
    return None


def nossa_parte_eproc(texto: str, oabs: Iterable[Tuple[str, str]]) -> Optional[dict]:
    """Compatibilidade: formato eproc é coberto por nossa_parte_por_oab."""
    return nossa_parte_por_oab(texto, oabs)


_RE_SUFIXO_EMPRESA = re.compile(r"\b(s/?a\.?|s\.a\.?|sa|ltda\.?|me|epp|eireli|cia\.?|companhia|banco multiplo|multiplo|sociedade anonima|espolio de|em recuperacao judicial)\b|[^a-z0-9 ]")


def nome_canonico(nome: str) -> str:
    """'Banco Bradesco S/A' ≈ 'BANCO BRADESCO S.A.' ≈ '2. BANCO BRADESCO SA (AGRAVADO)' ≈ 'banco bradesco'."""
    n = re.sub(r"^\s*\d+\.\s*", "", nome or "")
    n = re.sub(r"\([^)]*\)", " ", n)  # "(AGRAVADO)", "(EM RECUPERAÇÃO)"
    return uma_linha(_RE_SUFIXO_EMPRESA.sub(" ", chave(n)))


def _casa(nome: str, lista: List[str]) -> bool:
    n = nome_canonico(nome)
    return bool(n) and len(n) >= 4 and any(c == n or c in n or (len(n) > 8 and n in c) for c in lista)


def nossa_parte(item: dict, oabs: Iterable[Tuple[str, str]], clientes: Iterable[str] = (), adversarios: Iterable[str] = ()) -> dict:
    """Devolve {nome, papel, polo, origem}. polo ∈ ativo|passivo|outro|indeterminado.

    Ordem: (1) rótulo de papel antes da nossa OAB no texto; (2) parte única na API; (3) cliente conhecido entre as partes;
    (4) adversário habitual entre as partes (nosso polo é o oposto); (5) indeterminado.
    """
    r = nossa_parte_por_oab(item.get("texto") or "", oabs)
    if r and r["polo"] in ("ativo", "passivo"):
        return r
    partes = [p for p in (item.get("partes") or []) if p.get("nome")]
    api_polo = lambda p: "ativo" if p.get("polo") == "A" else ("passivo" if p.get("polo") == "P" else "outro")
    eh_mp = lambda p: bool(penal._RE_ACUSACAO_NOME.search(chave(p.get("nome") or "")))
    if len(partes) == 1 and api_polo(partes[0]) != "outro":
        if eh_mp(partes[0]):  # o Ministério Público nunca constitui advogado privado: somos a outra parte
            return {"nome": None, "papel": "?", "polo": "passivo" if api_polo(partes[0]) == "ativo" else "ativo", "origem": "parte-unica-mp"}
        return {"nome": partes[0]["nome"], "papel": "?", "polo": api_polo(partes[0]), "origem": "parte-unica"}
    cl = [nome_canonico(c) for c in clientes if c]
    for p in partes:
        if _casa(p["nome"], cl) and api_polo(p) != "outro" and not eh_mp(p):
            return {"nome": p["nome"], "papel": "?", "polo": api_polo(p), "origem": "clientes"}
    adv = [nome_canonico(a) for a in adversarios if a]
    polos_adv = {api_polo(p) for p in partes if _casa(p["nome"], adv)}
    if len(polos_adv) == 1 and polos_adv <= {"ativo", "passivo"}:
        oposto = "passivo" if "ativo" in polos_adv else "ativo"
        nosso = [p["nome"] for p in partes if api_polo(p) == oposto]
        return {"nome": nosso[0] if nosso else None, "papel": "?", "polo": oposto, "origem": "adversario"}
    # rótulo no texto de um adversário habitual ("REU: BANCO X") → somos o oposto
    texto = item.get("texto") or ""
    for m in _RE_ROTULO.finditer(texto[:3000]):
        nome = _nome_apos_rotulo(texto, m)
        if nome and _casa(nome, adv):
            pl = polo_do_papel(m.group(1))
            if pl in ("ativo", "passivo"):
                return {"nome": None, "papel": "?", "polo": "passivo" if pl == "ativo" else "ativo", "origem": "adversario-texto"}
    if r:
        return r
    return {"nome": None, "papel": None, "polo": "indeterminado", "origem": None}


# ----------------------------------------------------------------------------- corpo dispositivo
_RE_CAB_LINHA = re.compile(r"^(Assunto|Processo|Classe|Valor da causa|Juiz\(a\)|Autuado em|Distribui[cç][aã]o|Vara|Comarca|Foro)\b", re.I)
_RE_TITULO_CLASSE = re.compile(r"^[A-ZÇÃÕÉÊÍÓÚÂ0-9ª° ,\-/()]{6,}N[ºo°]\s*\d")
_RE_INICIO_ESAJ = re.compile(
    r"^(Vistos|VISTOS|Visto|Fls?\.|Fl\.|Trata-se|Cuida-se|Fica|Ficam|Intime|Intimem|Manifeste|Manifestem|Certifico|CERTIFICO|Ante|Diante|Defiro|Indefiro|DEFIRO|INDEFIRO|Recebo|RECEBO|Homologo|HOMOLOGO|Julgo|JULGO|Cumpra|Aguarde|Providencie|Considerando|Rejeito|REJEITO|Acolho|ACOLHO|Conhe[cç]o|Nos termos|Em face|Tendo em vista|Chamo|Reconsidero|DISPOSITIVO|Dispositivo|Isto posto|Posto isso|Ex positis|Diante do exposto|Ante o exposto|Pelo exposto|Decido|DECIDO|Recebo|Anote|Defiro|Concedo|Determino|Expe[cç]a|Oficie|Publique|Arquive|Remetam|Torno|Designo|Suspendo|Sentença|SENTENÇA|Decisão|DECISÃO|Despacho|DESPACHO|Ato|ATO|Certidão|CERTIDÃO|Edital|EDITAL|\d+[\)\.\-]|[IVX]+\s*[\)\.\-]|a\)|\(a\))")


_RE_MARCADOR_CORPO = re.compile(
    r"(conforme segue transcrito abaixo:\s*\"?|seguinte trecho do ato judicial[^:]*:\s*\"?|transcrito abaixo:\s*\"?|"
    r"\b(?:DESPACHO/DECIS[ÃA]O|DECIS[ÃA]O INTERLOCUT[ÓO]RIA|DECIS[ÃA]O MONOCR[ÁA]TICA|ATO ORDINAT[ÓO]RIO|SENTEN[ÇC]A|DECIS[ÃA]O|DESPACHO|CERTID[ÃA]O|EMENTA|AC[ÓO]RD[ÃA]O|EDITAL|INTIMA[ÇC][ÃA]O|DISPOSITIVO|RELAT[ÓO]RIO|VOTO)\b\s*[:\-–]?\s*)")


def corpo_dispositivo(texto: str) -> Tuple[str, str]:
    """Isola o corpo (o que o juízo/cartório escreveu) do cabeçalho de partes. Devolve (corpo, formato)."""
    texto = texto or ""
    linhas = texto.split("\n")
    # 1) formatos com quebras de linha (eproc, STJ): última linha de cabeçalho → corpo
    if len(linhas) > 4:
        ult_cab = -1
        for i, l in enumerate(linhas[:80]):
            s_ = l.strip()
            if not s_:
                continue
            if _RE_ADV.match(s_) or (_RE_PARTE.match(s_) and len(s_) < 200) or _RE_CAB_LINHA.match(s_) or _RE_TITULO_CLASSE.match(s_) or _RE_OAB_QUALQUER.search(s_) or re.match(r"^(RELATOR|ADVOGADOS?|EMBARGANTE|EMBARGADO|AGRAVANTE|AGRAVADO|RECORRENTE|RECORRIDO|INTERES\.)\b", s_):
                ult_cab = i
            elif ult_cab >= 0 and len(s_) > 60:
                break
        if ult_cab >= 0:
            resto = "\n".join(linhas[ult_cab + 1:]).strip()
            if len(resto) > 20:
                return resto, "eproc"
    # 2) e-SAJ: "Processo N - Classe - Assunto - Parte - Parte - - Parte - Corpo…"
    cab = texto[:1200]
    if re.match(r"^\s*(ADV:.*?-\s*)?Processo\s+\d", cab):
        segs = cab.split(" - ")
        pos = 0
        for i, seg in enumerate(segs):
            if i >= 3 and (_RE_INICIO_ESAJ.match(seg.strip()) or len(seg) > 140):
                return texto[pos:].strip(), "esaj"
            pos += len(seg) + 3
    # 3) PJe inline (TJPE, TJDFT, TRF, TJBA, TJSE…): último rótulo de papel/OAB no cabeçalho e o marcador de peça seguinte
    cab = texto[:2500]
    fim_cab = 0
    for m in _RE_ROTULO.finditer(cab):
        fim_cab = max(fim_cab, m.end())
    for m in _RE_OAB_QUALQUER.finditer(cab):
        fim_cab = max(fim_cab, m.end())
    m = re.search(r"(conforme segue transcrito abaixo|seguinte trecho do ato judicial[^:]*|transcrito abaixo)\s*:\s*\"?\s*(\[\.\.\.\])?\s*", texto[:3000], re.I) or _RE_MARCADOR_CORPO.search(texto, fim_cab)
    if m and m.start() < 3000:
        resto = texto[m.end():].strip()
        if len(resto) > 20:
            return resto, "pje"
    if fim_cab:
        # sem marcador: corpo = depois do nome que segue o último rótulo
        resto = texto[fim_cab:]
        m2 = re.search(r"[\.\n]\s+|\s{2,}", resto[:200])
        resto = resto[m2.end():].strip() if m2 else resto.strip()
        if len(resto) > 40:
            return resto, "pje"
    return texto, "integral"


# ----------------------------------------------------------------------------- prazo dirigido
_NUM_EXT = {"um": 1, "uma": 1, "dois": 2, "duas": 2, "tres": 3, "quatro": 4, "cinco": 5, "seis": 6, "sete": 7, "oito": 8, "nove": 9, "dez": 10, "quinze": 15,
            "vinte": 20, "trinta": 30, "quarenta e cinco": 45, "sessenta": 60, "noventa": 90, "cento e vinte": 120, "cento e oitenta": 180}
_ALT = "|".join(sorted(_NUM_EXT, key=len, reverse=True))
_RE_PRAZO = re.compile(r"prazo\s+(?:comum\s+|legal\s+|improrrogavel\s+|sucessivo\s+|de\s+|e\s+)*(?:de\s+)?(\d{1,3}|" + _ALT + r")\s*(?:\([^)]{1,40}\))?\s*(dias?|horas?)")
_RE_PRAZO2 = re.compile(r"\b(\d{1,3})\s*\((?:[a-z]+\s?){1,4}\)\s*(dias?|horas?)")
_RE_PRAZO3 = re.compile(r"\bem\s+(\d{1,3}|" + _ALT + r")\s+(dias?)\b(?=\s*($|[,.;:)]|uteis|corridos|a contar|contados|para|sob|apresent|manifest|junt|compro|recolh|de\b|inform|requeira|diga|informe|esclare|junte|comprove|promova|indique))")
_RE_PRAZO4 = re.compile(r"\bprazo\s*:\s*(\d{1,3}|" + _ALT + r")\s*(?:\([^)]{1,40}\))?\s*(dias?|horas?)")
_RE_NAO_PRAZO = re.compile(r"repeti[cç][aã]o|reitera|teimosinha|sobrest|suspens[aã]o|suspenso|suspend[oa]|renova[cç][aã]o|pelo periodo de|(protetivas?|vigencia|vigor|validade|duracao|monitora\w+|cautelares?)[^.;]{0,60}pelo prazo de|edital.{0,40}prazo|prazo d[oe] (presente )?edital|prazo de \d+ dias,? contados? da (publicacao|expedicao) do edital|com validade de|validade de \d+ dias|permanecerao em cartorio|aguard(e-se|ara|ar-se-a) (por|pelo prazo de|o prazo de)|resposta (ao|aos|do|dos) ofici|prazo anuo|por 1 ano|por um ano|conferencia da integridade")
_RE_PRAZO_REF = re.compile(r"no (mesmo|referido|aludido|igual) prazo|no prazo (assinalado|fixado|acima|supra|retro|do item \d|ja fixado)|igual prazo|mesmo prazo")
_RE_PRAZO_LEGAL = re.compile(r"no prazo legal|prazo legal|prazo da lei|prazo do art")
_RE_FUTURO = re.compile(r"\b(com a resposta|com as respostas|apos|oportunamente|havendo|decorrido|transcorrido|findo|no silencio|em caso de|caso (nao|haja|seja|sejam|positiv|negativ)|se houver|sobrevindo|com o retorno|com a juntada|juntad[oa]s? (a|as|o|os)? ?(resposta|respostas|extrato|comprovante)|cumprida|certificad[oa]|em seguida|na sequencia|posteriormente|vindo (aos autos|a resposta)|uma vez|assim que|tao logo|na hipotese|nao (havendo|sendo|sobrevindo)|em nao havendo|sem prejuizo, (apos|oportunamente))\b")
# ":" seguido de número só NÃO quebra quando é um prazo ("PRAZO: 10 DIAS"); enumerações ("…: 1) … 2) …") continuam quebrando
_RE_SENT = re.compile(r"(?<=[\.\;!?])\s+(?=[A-ZÀ-Ú0-9(])|(?<=:)\s+(?=[A-ZÀ-Ú(])|(?<=:)\s+(?=\d)(?!\d{1,3}\s*(?:\([^)]{1,40}\)\s*)?(?:[Dd][Ii][Aa][Ss]?|[Hh][Oo][Rr][Aa][Ss]?)\b)|\n+")
_RE_ORDEM = re.compile(r"cite-se|citem-se|\bresponder\b|ofere[cç]|(?<!tendo em )(?<!em )\bvista (para|a |as |ao |aos |do |dos |da |das )|intime|intimem|fica(m)? intimad|manifeste|manifestem|manifestar|apresent|junte|comprov|recolh|informe|esclare|diga|digam|fale|falem|providenci|cumpra|regulariz|emend|indique|traga|promova|requeira|abra-se vista|vista a|de-se vista|abra-se|\ba parte (autora|re|reu|exequente|executada|requerente|requerida|credora|devedora|embargante|embargada|apelante|apelada|agravante|agravada) para|\bas partes para|\bpara que|\bdevera|\bdeverao|\bsob pena|demonstr|justifi|esclarec|especifi|para (se )?manifest")


def extrair_prazo(s: str) -> Optional[int]:
    for rx in (_RE_PRAZO, _RE_PRAZO4, _RE_PRAZO2, _RE_PRAZO3):
        m = rx.search(s)
        if m:
            bruto, unidade = m.group(1), m.group(2)
            n = int(bruto) if bruto.isdigit() else _NUM_EXT.get(bruto)
            if not n or n > 365:
                continue
            if unidade.startswith("hora"):
                n = max(1, round(n / 24))
            return n
    return None


_DEFESA_W = r"defesa|defensor(a|ia)?( publica)?|advogad[oa] de defesa|" + PASSIVO_P
_ACUSACAO_W = r"ministerio publico|promotor(a|ia)?( de justica)?|acusacao|parquet|\bmp\b|\bmpf\b|\bmpe\b|" + ATIVO_P


def direcao(sent_chave: str, polo: str, penal_: bool = False, lado: str = "") -> str:
    """nos | outra | ambos | generico | indef — a quem a frase se dirige.
    No modo penal, além dos papéis do recurso (agravante/agravado…), 'defesa/réu/apenado…' e 'Ministério Público/acusação…'
    são atribuídos conforme o nosso LADO (defesa × acusação) — a defesa pode ser agravante (polo ativo) num agravo em execução."""
    if polo not in ("ativo", "passivo") and not (penal_ and lado in ("defesa", "acusacao")):
        return "generico" if _RE_ORDEM.search(sent_chave) else "indef"
    if penal_:
        base_ours = (_ATIVO_REC if polo == "ativo" else _PASSIVO_REC) if polo in ("ativo", "passivo") else ""
        base_theirs = (_PASSIVO_REC if polo == "ativo" else _ATIVO_REC) if polo in ("ativo", "passivo") else ""
        lado_ours = _DEFESA_W if lado == "defesa" else (_ACUSACAO_W if lado == "acusacao" else "")
        lado_theirs = _ACUSACAO_W if lado == "defesa" else (_DEFESA_W if lado == "acusacao" else "")
        ours = "|".join(x for x in (base_ours, lado_ours) if x)
        theirs = "|".join(x for x in (base_theirs, lado_theirs) if x)
    else:
        ours = ATIVO if polo == "ativo" else PASSIVO
        theirs = PASSIVO if polo == "ativo" else ATIVO
    tem_ours = re.search(rf"\b({ours})\b", sent_chave) is not None
    tem_theirs = re.search(rf"\b({theirs})\b", sent_chave) is not None
    if tem_ours and not tem_theirs:
        return "nos"
    if tem_theirs and not tem_ours:
        return "outra"
    if tem_ours and tem_theirs:
        return "ambos"
    if re.search(rf"\b({GENERICO})\b", sent_chave) or _RE_ORDEM.search(sent_chave):
        return "generico"
    return "indef"


def frases(corpo: str) -> List[str]:
    return [x.strip() for x in _RE_SENT.split(corpo) if x and x.strip()]


def prazos_no_corpo(corpo: str, polo: str, penal_: bool = False, lado: str = "") -> dict:
    """{'nosso': (dias, direcao, frase) | None, 'outra': (dias, frase) | None, 'ignorados': [dias]}"""
    nosso = outra = None
    ignorados: List[int] = []
    futuros: List[tuple] = []
    anterior = ""
    ultimo_num: Optional[int] = None
    legal: Optional[tuple] = None
    for fr in frases(corpo):
        s = chave(fr)
        p = extrair_prazo(s)
        if not p and _RE_PRAZO_REF.search(s) and ultimo_num:
            p = ultimo_num  # "no mesmo prazo", "no prazo assinalado no item 1"
        if not p and _RE_PRAZO_LEGAL.search(s) and legal is None and _RE_ORDEM.search(s):
            d0 = direcao(s, polo, penal_, lado)
            if d0 in ("nos", "generico", "ambos", "indef"):
                legal = (d0, fr[:200])
        if not p:
            anterior = s
            continue
        ultimo_num = p
        if len(s) <= 70 and direcao(s, polo, penal_, lado) == "indef" and anterior:
            s = anterior + " " + s  # "Prazo comum de 5 dias." refere-se à ordem da frase anterior
            fr = fr
        anterior = s
        if _RE_NAO_PRAZO.search(s) and not re.search(r"sob pena|manifest|apresent|junt|recolh|compro|emend|regulariz|contest|impugn|embarg|recurso|recorr", s):
            ignorados.append(p)
            continue
        d = direcao(s, polo, penal_, lado)
        mf, mo = _RE_FUTURO.search(s), _RE_ORDEM.search(s)
        if mf and (mo is None or mf.start() < mo.start()):
            futuros.append((p, d, fr[:200]))
            continue
        if d in ("nos", "generico", "ambos", "indef"):
            if nosso is None or (d == "nos" and nosso[1] != "nos"):
                nosso = (p, d, fr[:200])
        elif d == "outra" and outra is None:
            outra = (p, fr[:200])
    return {"nosso": nosso, "outra": outra, "ignorados": ignorados, "futuros": futuros, "legal": legal}


# ----------------------------------------------------------------------------- eventos com data (audiência, perícia, sessão, leilão)
_MESES = {"janeiro": 1, "fevereiro": 2, "marco": 3, "abril": 4, "maio": 5, "junho": 6, "julho": 7, "agosto": 8, "setembro": 9, "outubro": 10, "novembro": 11, "dezembro": 12}
_RE_DATA_NUM = re.compile(r"\b(\d{1,2})/(\d{1,2})/(\d{2,4})\b")
_RE_DATA_EXT = re.compile(r"\b(\d{1,2})\s+de\s+(" + "|".join(_MESES) + r")\s+de\s+(\d{4})\b")
_RE_HORA = re.compile(r"\b(?:as|às|a partir das|com inicio as)\s*(\d{1,2})\s*(?:[:h]\s*(\d{2}))?\s*(?:h|hs|horas|min)?\b|\b(\d{1,2})[:h](\d{2})\s*(?:h|hs|horas|min)?\b")
_RE_EVENTO = re.compile(
    r"(?P<tipo>audiencia(?:\s+(?:de instrucao e julgamento|de tentativa de conciliacao|de conciliacao|de mediacao|de instrucao|de justificacao|de custodia|de saneamento|una|virtual|por videoconferencia|preliminar|inicial|admonitoria|de apresentacao|de proposta|de homologacao|de retratacao|de suspensao condicional|de transacao|de oitiva))?|"
    r"sessao plenaria(?: do (?:tribunal do )?juri)?|plenario do (?:tribunal do )?juri|julgamento (?:pelo|em plenario do) (?:tribunal do )?juri|reuniao (?:periodica |ordinaria )?do (?:tribunal do )?juri|"
    r"sessao (?:de julgamento|virtual|de mediacao|de conciliacao)|julgamento (?:virtual|presencial|telepresencial)|data da pauta|"
    r"pericia|trabalhos periciais|inicio dos trabalhos|vistoria|"
    r"leilao|hasta publica|praca|alienacao judicial|"
    r"inspecao judicial|oitiva|depoimento pessoal|interrogatorio)")
_RE_DESIGNACAO = re.compile(r"design|marcad|agendad|realizar|realiza[cç]ao|a realizar-se|ocorrer|sera realizad|serao realizad|inclus[aã]o em pauta|incluid[oa] em pauta|data da pauta|pauta de julgamento|sessao (de julgamento|virtual|ordinaria|extraordinaria)|inicio dos trabalhos|comparec|fica(m)? (as partes )?(intimad|cientificad)|redesign|aprazad|para o dia|no dia \d")
_RE_MODALIDADE = re.compile(r"videoconferencia|video conferencia|virtual|telepresencial|remot[oa]|presencial|hibrid[oa]|semipresencial|por meio eletronico|plataforma (zoom|teams|webex|google meet)|zoom|teams|webex|meet\.google")
_RE_LINK = re.compile(r"https?://[^\s\"'<>)\]]+")
_RE_LOCAL = re.compile(r"(?:na sala|no forum|no foro|na sede|no endereco|localizad[oa]|em (?:[A-Z][a-zà-ú]+(?:/[A-Z]{2})?))([^.;]{0,120})")


def _data_de(m_num, m_ext) -> Optional[date]:
    try:
        if m_num:
            d, mth, y = int(m_num.group(1)), int(m_num.group(2)), int(m_num.group(3))
            if y < 100:
                y += 2000
            return date(y, mth, d)
        if m_ext:
            return date(int(m_ext.group(3)), _MESES[m_ext.group(2)], int(m_ext.group(1)))
    except ValueError:
        return None
    return None


def extrair_eventos(corpo: str, texto_original: str = "", ref: Optional[date] = None) -> List[dict]:
    """Eventos datados no corpo: audiência/perícia/sessão/leilão com data, hora, modalidade, local e link.
    `ref` = data da publicação: datas anteriores a ela são narrativa (provimento antigo, audiência já realizada) e são ignoradas."""
    eventos: List[dict] = []
    vistos = set()
    for fr in frases(corpo):
        s = chave(fr)
        me = _RE_EVENTO.search(s)
        if not me:
            continue
        if not _RE_DESIGNACAO.search(s):
            continue  # menção narrativa ("a prova pericial não é essencial…"), não designação
        # a data pode estar na própria frase ou na seguinte curta; procuramos na frase — a primeira que não seja anterior à publicação
        m_num, m_ext, d = None, None, None
        for cand in sorted(list(_RE_DATA_NUM.finditer(s)) + list(_RE_DATA_EXT.finditer(s)), key=lambda m: m.start()):
            dc = _data_de(cand, None) if cand.re is _RE_DATA_NUM else _data_de(None, cand)
            if dc and (ref is None or dc >= ref - __import__("datetime").timedelta(days=1)):
                m_num, m_ext, d = (cand, None, dc) if cand.re is _RE_DATA_NUM else (None, cand, dc)
                break
        if not d:
            continue
        # evita datas de assinatura/publicação ("São Paulo, 09/09/2026")
        if re.search(r"^(sao paulo|recife|brasilia|rio de janeiro|belo horizonte|curitiba|porto alegre|salvador|fortaleza|goiania|[a-z ]{3,25}),\s*(\d{1,2}|\w+) de \w+ de \d{4}", s):
            continue
        if re.search(r"(publicad|disponibilizad|assinad|protocolad|ajuizad|distribuid|proferid|juntad)[oa]s? (em|no dia|aos)\s*" + re.escape(m_num.group(0) if m_num else m_ext.group(0)), s):
            continue
        mh = _RE_HORA.search(s)
        hora = None
        if mh:
            hh = mh.group(1) or mh.group(3)
            mm = mh.group(2) or mh.group(4) or "00"
            try:
                if 0 <= int(hh) <= 23:
                    hora = f"{int(hh):02d}:{int(mm):02d}"
            except ValueError:
                hora = None
        tipo_raw = me.group("tipo")
        tipo = ("audiência" if tipo_raw.startswith("audiencia") else
                "sessão do júri" if re.search(r"juri|plenari", tipo_raw) else
                "sessão de julgamento" if re.search(r"sessao|julgamento|pauta", tipo_raw) else
                "perícia" if re.search(r"pericia|trabalhos|vistoria", tipo_raw) else
                "leilão/praça" if re.search(r"leilao|hasta|praca|alienacao", tipo_raw) else
                "inspeção/oitiva" if re.search(r"inspecao|oitiva|depoimento|interrogatorio", tipo_raw) else "audiência")
        mm_ = _RE_MODALIDADE.search(s)
        modalidade = mm_.group(0) if mm_ else ""
        link = ""
        ml = _RE_LINK.search(fr)
        if ml:
            link = ml.group(0).rstrip(".,;)")
        chave_ev = (tipo, d.isoformat(), hora)
        if chave_ev in vistos:
            continue
        vistos.add(chave_ev)
        eventos.append({"tipo": tipo, "descricao": uma_linha(tipo_raw), "data": d.isoformat(), "hora": hora, "modalidade": modalidade,
                        "link": link, "frase": uma_linha(fr)[:240]})
    eventos.sort(key=lambda e: (e["data"], e["hora"] or "99"))
    return eventos


# ----------------------------------------------------------------------------- gabaritos de cartório (templates) — avaliados antes das regras
# (regex sobre os primeiros 700 chars do corpo canônico, ato, urgência, prazo em dias (None), base)
TEMPLATES = [
    (r"aguardara? o prazo de (30|trinta) .{0,40}dias para conferencia da integridade", "Migração eproc — conferir integridade e manifestar prosseguimento em 30 dias", "ALTA", 30, "Comunicado TJSP (migração eproc)"),
    (r"passara a tramitar (eletronicamente )?no sistema eproc|foi migrado para o sistema eproc|migracao dos autos para o sistema eproc|de-se ciencia .{0,40}migracao", "Migração para o eproc — conferir credenciamento/cadastro", "BAIXA", None, "Comunicado TJSP"),
    (r"intimacao realizada no sistema eproc\.? ?o ato refere-se", "Ler o documento no eproc (evento indicado) — pode haver diligência negativa", "MEDIA", None, "Comunicado eproc"),
    (r"processo sigiloso|para visualizacao do documento,? consulte os autos|arquivos digitais indisponiveis", "Ler o documento no sistema do tribunal (sigilo/indisponível no DJEN)", "MEDIA", None, "—"),
    (r"logradouro nao cadastrado|cep .{0,30}nao (cadastrado|zoneado)", "Regularizar endereço/CEP da parte contrária", "MEDIA", None, "CPC 246"),
    (r"^ciencia (as partes |a parte )?d[oe]\(?s\)? ofici", "Ciência de ofício recebido", "BAIXA", None, "—"),
    (r"mandado de levantamento eletronico|expedicao de mle|expeca-se mle|\bmle\b", "Consultar/resgatar MLE (mandado de levantamento eletrônico)", "MEDIA", None, "Res. CNJ 4/2022 (MLE)"),
    (r"(suspend[oa]|suspensao|suspende-se) .{0,80}art(igo)?\.? ?921|prazo anuo|arquivo provisorio|suspensao (da execucao )?por (1|um) ano", "Suspensão art. 921 CPC — agendar controle de 1 ano (prescrição intercorrente)", "MEDIA", None, "CPC 921 §§1º-4º"),
    (r"transito em julgado da sentenca|houve o transito em julgado", "Trânsito em julgado — ciência/arquivamento", "BAIXA", None, "CPC 1.006"),
]
_RE_DILIG = re.compile(r"sisbajud|bacenjud|renajud|infojud|bloqueio|penhora|arresto|sniper|serasajud|cnib|pesquisa de bens|desarquivamento|expedicao de oficio|busca de bens|indisponibilidade")
_RE_INDEFERE = re.compile(r"\b(indefiro|nao conheco|nego|rejeito o pedido|nao acolho|indeferido)\b")
_RE_DEFERE = re.compile(r"\b(defiro|determino|autorizo|deferido|acolho o pedido)\b")
_RE_BOILER_CUSTAS = re.compile(r"ficam as partes cientes|deverao ser (gerad|recolhid)[oa]s (exclusivamente )?(por meio|pelo|no) (do )?sistema eproc|infoeproc|botao custas|as custas no sistema eproc devem ser recolhidas")
_RE_SOB_PENA = re.compile(r"sob pena|no silencio|na inercia|escoado o prazo sem|decorrido o prazo (sem|in albis)|art(igo)?\.? ?485|extincao|arquiv")
_RE_PROVIDENCIA = re.compile(r"recolh|comprov|junt|apresent|deposit|providenci|regulariz|inform|esclare|manifest|cumpra|encaminh|protocol|resposta|contrarraz|contraminuta|impugn|contest|replica|requeira|de andamento|prosseguimento|indique|traga|promova|diga|fale")


# ----------------------------------------------------------------------------- regras de ato (cientes do polo)
# (regex sobre frase canônica, ato, prazo padrão, urgência, base legal, polos a que se aplica, exige_ordem)
# exige_ordem=True: só dispara se a frase contiver um verbo de ordem/intimação (evita narrativa: "rejeito os embargos", "carta de citação devolvida")
ATOS = [
    (r"contrarraz|contraminuta", "Apresentar contrarrazões/contraminuta", 15, "CRITICA", "CPC 1.010 §1º / 1.019 II", ("ativo", "passivo", "indeterminado", "outro"), True),
    (r"embargos de declaracao", "Manifestar sobre embargos de declaração (contrarrazões)", 5, "CRITICA", "CPC 1.023 §2º", ("ativo", "passivo", "indeterminado", "outro"), True),
    (r"emend[ae]r? a (peticao )?inicial|emenda a inicial|regulariz\w+ a (peticao )?inicial", "Emendar a petição inicial", 15, "CRITICA", "CPC 321", ("ativo", "indeterminado"), False),
    (r"recurso inominado", "Recurso inominado (JEC)", 10, "CRITICA", "Lei 9.099/95 art. 42", ("ativo", "passivo", "indeterminado", "outro"), False),
    (r"recurso ordinario", "Recurso ordinário (JT)", 8, "CRITICA", "CLT 895", ("ativo", "passivo", "indeterminado", "outro"), False),
    (r"impugna\w* (ao|do) cumprimento|impugnacao a execucao", "Impugnação ao cumprimento de sentença", 15, "CRITICA", "CPC 525", ("passivo", "indeterminado"), True),
    (r"embargos a execucao|embargos do devedor", "Embargos à execução", 15, "CRITICA", "CPC 915", ("passivo", "indeterminado"), True),
    (r"pagamento voluntario|art\.? ?523|pagar o debito|efetuar o pagamento|para (que )?pague|para pagamento", "Cumprimento de sentença — pagar ou impugnar", 15, "CRITICA", "CPC 523 / 525", ("passivo", "indeterminado"), True),
    (r"replica|manifest\w* sobre (a )?contestacao|impugna\w* (a )?contestacao|contestacao (e documentos )?apresentad", "Réplica", 15, "ALTA", "CPC 350-351", ("ativo", "indeterminado"), False),
    (r"(para |querendo,? |querendo )?contest(ar|e|em)\b|apresent\w* (a |sua )?(contestacao|defesa)|prazo (legal )?para (a )?(contestacao|defesa|resposta)|oferec\w* (contestacao|defesa)", "Contestar", 15, "CRITICA", "CPC 335", ("passivo", "indeterminado"), True),
    (r"laudo|pericia|perit[oa]|quesitos|assistente tecnico", "Manifestar sobre laudo/perícia", 15, "ALTA", "CPC 477 §1º / 465", ("ativo", "passivo", "indeterminado", "outro"), True),
    (r"especific\w* (as )?provas|provas que pretende|producao de provas", "Especificar provas", 15, "ALTA", "CPC 357 (prazo judicial)", ("ativo", "passivo", "indeterminado", "outro"), True),
    (r"recolh\w*\s+(d?[oa]s?\s+)?(valor|custas|taxa|diligencia|despesas)|custas de desarquivamento|\bufesps?\b|guia (fedtj|de recolhimento)|\bpreparo\b|diligencia do oficial|despesas de conducao|complementa\w* (das|as) custas|taxa judiciaria|custas (iniciais|finais|remanescentes|complementares)", "Recolher custas/diligências", 5, "ALTA", "CPC 290 / 1.007 §2º", ("ativo", "passivo", "indeterminado", "outro"), True),
    (r"prosseguimento|prossiga|de andamento|dar andamento|de prosseguimento|requerer o que (entender )?de direito|requeira o que|termos de prosseguimento|em termos|promov\w* (o|a) (execucao|citacao|andamento)|indique bens|indicar bens|indique (o )?endereco|novo endereco|endereco atualizado", "Requerer o prosseguimento do feito", 5, "ALTA", "CPC 485 III / 921", ("ativo", "indeterminado"), True),
    (r"audiencia", "Audiência designada — preparar", None, "ALTA", "CPC 334 / 358", ("ativo", "passivo", "indeterminado", "outro"), False),
    (r"transito em julgado|transitad[oa] em julgado|arquivem-se|ao arquivo|baixa definitiva", "Encerramento/arquivamento — ciência", None, "BAIXA", "CPC 1.006 / 925", ("ativo", "passivo", "indeterminado", "outro"), False),
    (r"julgo (procedente|improcedente|extint|parcialmente|prejudicad)|\bextingo\b|\bhomologo\b|\bcondeno\b|resolvo o merito|pronuncio a prescricao|p\.\s?r\.\s?i\.|publique-se,? registre-se|sentenca de (procedencia|improcedencia|extincao)", "Sentença — avaliar apelação", 15, "CRITICA", "CPC 1.003 §5º / 1.009", ("ativo", "passivo", "indeterminado", "outro"), False),
    (r"\bacordam\b|nego provimento|dou provimento|nego seguimento|nao conheco do (recurso|agravo)|recurso (nao )?(conhecido|provido)|agravo (nao )?provido|desprovido|provimento negado|acordao (publicado|proferido)", "Acórdão/decisão colegiada — avaliar ED/REsp/RE", 15, "CRITICA", "CPC 1.003 §5º", ("ativo", "passivo", "indeterminado", "outro"), False),
    (r"rejeito os embargos de declaracao|acolho os embargos de declaracao|embargos de declaracao (rejeitad|acolhid|conhecid|nao conhecid)", "Decisão sobre ED — reaberto o prazo recursal", 15, "CRITICA", "CPC 1.026 / 1.003 §5º", ("ativo", "passivo", "indeterminado", "outro"), False),
    (r"\bagravo\b", "Agravo — avaliar ou contraminutar", 15, "CRITICA", "CPC 1.003 §5º / 1.019", ("ativo", "passivo", "indeterminado", "outro"), True),
    (r"prazo", "Providência determinada pelo juízo — ver texto", None, "ALTA", "CPC 218 (prazo judicial)", ("ativo", "passivo", "indeterminado", "outro"), True),
    (r"indefiro|defiro|determino|autorizo|concedo|nao conheco|acolho|rejeito|decido|reconsidero|mantenho|torno sem efeito|declaro|reconheco|suspendo|converto|libero|expeca-se|oficie-se|proceda-se|bloqueio|penhora|sisbajud|renajud|infojud|serasajud|cnib|arresto|leilao|hasta|adjudica", "Decisão/diligência deferida — ciência e acompanhamento", None, "MEDIA", "CPC 1.015 (se houver gravame)", ("ativo", "passivo", "indeterminado", "outro"), False),
    (r"\bedital\b", "Edital — apenas ciência (salvo se for parte)", None, "MEDIA", "CPC 256-259", ("ativo", "passivo", "indeterminado", "outro"), False),
    (r"lista de distribuicao|distribuid[oa]", "Distribuição — ciência", None, "BAIXA", "CPC 284-286", ("ativo", "passivo", "indeterminado", "outro"), False),
    (r"mero expediente|junte-se|aguarde-se|ciencia|cientifique-se|arquive-se|certifique-se|cumpra-se|\bint\b|intimem-se|desarquiv|anote-se|publique-se|registre-se|nada a (prover|decidir)|aguardem|sobreste-se|remetam-se|encaminhe-se|traslad|cadastr", "Despacho de mero expediente / ciência", None, "BAIXA", "CPC 1.001", ("ativo", "passivo", "indeterminado", "outro"), False),
]
_FORTES_TIPO = {
    "pauta": ("Pauta de julgamento — conferir data da sessão; avaliar sustentação oral/memoriais", None, "ALTA", "CPC 934-937 / RITJ"),
    "citacao": ("Citação — apresentar contestação", 15, "CRITICA", "CPC 335"),
    "sentenca": ("Sentença — avaliar apelação", 15, "CRITICA", "CPC 1.003 §5º / 1.009"),
    "acordao": ("Acórdão — avaliar ED/REsp/RE", 15, "CRITICA", "CPC 1.003 §5º"),
    "edital": ("Edital — apenas ciência (salvo se for parte)", None, "MEDIA", "CPC 256-259"),
    "lista de distribuicao": ("Distribuição — ciência", None, "BAIXA", "CPC 284-286"),
}
_RE_DOBRO = re.compile(r"prazo em dobro|defensoria publica|fazenda publica|ministerio publico|litisconsortes?.{0,60}(procuradores|advogados) (distintos|diferentes)|art\.? ?(180|183|186|229)\b")
_PESO = {"CRITICA": 0, "ALTA": 1, "MEDIA": 2, "BAIXA": 3, "CANCELADA": 4}


_RE_NARRATIVA = re.compile(r"\b(apresentou|apresentaram|apresentad[oa]s?|manifestou|manifestaram|juntou|juntaram|informou|informaram|requereu|requereram|comprovou|ofereceu|ofereceram|indicou|esclareceu|recolheu|cumpriu|respondeu|pugnou|pugnando|foi (pessoalmente )?citad[oa]|foram citad[oa]s|deixou de|nao apresentou)\b")
_RE_IMPERATIVO = re.compile(r"intime|intimem|cite-se|citem-se|fica(m)? intimad|manifeste(m)?\b|apresente(m)?\b|junte(m)?\b|comprove(m)?\b|recolha(m)?\b|informe(m)?\b|esclare[cç]a(m)?\b|diga(m)?\b|providencie(m)?\b|cumpra(m)?\b|regularize(m)?\b|emende(m)?\b|indique(m)?\b|traga(m)?\b|promova(m)?\b|requeira(m)?\b|abra-se vista|de-se vista|\bdevera|\bdeverao|\bpara que|\bsob pena|\bpara (se )?manifest|\bpara (apresent|junt|comprov|recolh|inform|esclarec|respond|oferec|contest|impugn)")


def _regra_por_frases(frs: List[str], polo: str, atos: Optional[list] = None, penal_: bool = False, lado: str = "") -> Optional[dict]:
    """Primeira regra (na ordem de prioridade da tabela) que casa numa frase dirigida a nós/genérica."""
    for rx, ato, p, u, base, polos, exige_ordem in (atos or ATOS):
        if penal_:
            if lado == "acusacao" and "ativo" not in polos:
                continue
        elif polo not in polos:
            continue
        for fr in frs:
            s = chave(fr)
            if not re.search(rx, s):
                continue
            d = direcao(s, polo, penal_, lado)
            if d == "outra":
                continue
            if exige_ordem and not _RE_ORDEM.search(s):
                continue
            if exige_ordem and _RE_NARRATIVA.search(s) and not _RE_IMPERATIVO.search(s):
                continue  # relato do que já foi feito ("apresentou contrarrazões"), não ordem
            if ato.startswith("Recolher custas") and _RE_BOILER_CUSTAS.search(s):
                continue
            if ato.startswith("Providência determinada") and (not extrair_prazo(s) or d not in ("nos", "generico", "ambos", "indef")):
                continue
            mf, mo = _RE_FUTURO.search(s), _RE_ORDEM.search(s)
            if mf and mo and mf.start() < mo.start() and not ato.startswith(("Sentença", "Acórdão", "Decisão", "Encerramento", "Edital", "Distribuição", "Despacho", "Prisão", "Liberdade", "Pronúncia", "HC ", "Denúncia", "Execução penal", "Agravo em execução")):
                continue  # ordem condicionada a evento futuro ("com a resposta, intime-se…") — não é prazo corrente
            return {"ato": ato, "prazo_tab": p, "urgencia": u, "base": base, "frase": fr[:200], "direcao": d}
    return None


_RE_PROCEDENTE = re.compile(r"julgo (totalmente |integralmente )?procedente|\bprocedente[s]? (o|os|a|as) pedido|acolho (o|os) pedido|homologo o acordo")
_RE_IMPROCEDENTE = re.compile(r"julgo (totalmente )?improcedente|\bimprocedente[s]? (o|os|a|as) pedido|rejeito (o|os) pedido|\bextingo\b|\bextincao\b|indefiro a (peticao )?inicial|pronuncio a prescricao")
_RE_PARCIAL = re.compile(r"parcialmente procedente|procedente em parte|procedencia parcial")


def resultado_sentenca(corpo_chave: str, polo: str) -> Optional[str]:
    """favoravel | desfavoravel | parcial | None — do ponto de vista do nosso polo."""
    if _RE_PARCIAL.search(corpo_chave):
        return "parcial"
    proc, improc = bool(_RE_PROCEDENTE.search(corpo_chave)), bool(_RE_IMPROCEDENTE.search(corpo_chave))
    if not proc and not improc:
        return None
    if polo == "ativo":
        return "favoravel" if proc and not improc else ("desfavoravel" if improc and not proc else "parcial")
    if polo == "passivo":
        return "favoravel" if improc and not proc else ("desfavoravel" if proc and not improc else "parcial")
    return None


def classificar(item: dict, cfg_prazos: Optional[dict] = None, hoje: Optional[date] = None, oabs: Iterable[Tuple[str, str]] = (), clientes: Iterable[str] = (), adversarios: Iterable[str] = ()) -> dict:
    cfg_prazos = cfg_prazos or {}
    texto = item.get("texto") or ""
    parte = nossa_parte(item, oabs, clientes, adversarios)
    # perfil: cível (dias úteis, CPC) ou penal (dias corridos, CPP) — "auto" decide por publicação
    perfil_cfg = str(cfg_prazos.get("perfil") or "auto").lower()
    motivo_penal = penal.eh_penal(item)
    eh_pen = perfil_cfg == "criminal" or (perfil_cfg == "auto" and bool(motivo_penal))
    if eh_pen and parte["polo"] not in ("ativo", "passivo"):
        polo_cfg = penal.polo_por_papel_config(cfg_prazos.get("papel") or "")
        if polo_cfg:
            parte = dict(parte, polo=polo_cfg, origem=(parte.get("origem") or "papel-config") if parte.get("polo") in ("ativo", "passivo") else "papel-config")
    polo = parte["polo"]
    lado = penal.lado_penal(parte, cfg_prazos.get("papel") or "") if eh_pen else ""
    if eh_pen:
        parte = dict(parte, lado=lado)
    tabela_atos = penal.ATOS_PENAL if eh_pen else ATOS
    fortes = penal.FORTES_TIPO_PENAL if eh_pen else _FORTES_TIPO
    corpo, formato = corpo_dispositivo(texto)
    frs = frases(corpo)
    cab = chave(f"{item.get('tipo', '')} {item.get('documento', '')}")
    pz = prazos_no_corpo(corpo, polo, eh_pen, lado)

    ato, prazo_tab, urg, base, origem_regra, frase = "Publicação — ler e classificar", None, "MEDIA", "", "padrao", ""
    # 1) tipos fortes do cabeçalho
    if "ementa" in cab and "acordao" not in cab:
        cab += " acordao"
    for k, (a, p, u, b) in fortes.items():
        if k in cab:
            if k == "citacao" and polo == "ativo":
                ato, prazo_tab, urg, base, origem_regra = "Citação da parte contrária — acompanhar", None, "MEDIA", ("CPP 351-369" if eh_pen else "CPC 238-239"), "tipo"
            else:
                ato, prazo_tab, urg, base, origem_regra = a, p, u, b, "tipo"
            break
    # 0a) penal: sentença identificada no próprio texto ("SENTENÇA … RELATÓRIO/DISPOSITIVO") quando o cabeçalho não diz
    if eh_pen and origem_regra == "padrao" and re.search(r"\bsentenca\b\s*(i\s*[–-]\s*)?(relatorio|do relatorio|vistos)|\bsentenca\b.{0,200}\bdispositivo\b", chave(texto[:3000])):
        a, p, u, b = fortes["sentenca"]
        ato, prazo_tab, urg, base, origem_regra = a, p, u, b, "tipo"
    # 0) gabaritos de cartório (R5) — só quando o tipo forte não decidiu
    corpo_chave = chave(corpo)
    template = None
    if origem_regra == "padrao":
        for rx, a, u, pdias, b in TEMPLATES:
            if re.search(rx, corpo_chave[:700] if pdias is None else corpo_chave):  # gabaritos com prazo (migração eproc) podem estar no fim do texto
                template = (a, u, pdias, b)
                break
    # 1a) pauta de julgamento (virtual ou presencial) — sessão marcada
    m_pauta = re.search(r"data da pauta|pauta (ordinaria |extraordinaria |virtual |de julgamentos? )?(de julgamento|da (\d+a |\w+ )?(turma|camara|secao|sessao))|inclus[aã]o .{0,40}(na |em )pauta|incluid[oa] (na |em )pauta|sessao (de julgamento|virtual)|julgamento (virtual|presencial|telepresencial)", chave(corpo)) if origem_regra == "padrao" else None
    data_sessao = None
    ref_data = None
    try:
        ref_data = date.fromisoformat(str(item.get("data") or "")[:10])
    except ValueError:
        ref_data = None
    if m_pauta:
        cc = chave(corpo)
        if not re.search(r"designad[oa]|incluid[oa]|inclusao|pauta (do|de|para o) dia|data da pauta|sessao (de julgamento )?(do dia|de \d)|julgamento (virtual|presencial|telepresencial)( com inicio| no dia| em \d| de \d| a partir|,|\.)|para julgamento|sera julgad|serao julgad", cc):
            m_pauta = None  # mera menção a sessão/pauta (acórdão, despacho do art. 422, relato) — não é designação de pauta
        elif pz["nosso"] and pz["nosso"][1] in ("nos", "generico", "ambos") and not re.search(r"virtual", cc) and re.search(r"abr[ao]-?se vista|abro vista|vista (a|as|ao|aos) |intime|manifest", cc):
            m_pauta = None  # há ordem com prazo dirigida a nós (ex.: art. 422 CPP) — as regras de ato decidem
    if m_pauta:
        for md in list(re.finditer(r"(?:data da pauta|sessao|julgamento|dia|para o dia|designad[oa] para)\D{0,40}?(\d{1,2}/\d{1,2}/\d{4})", cc)) + list(re.finditer(r"(\d{1,2}/\d{1,2}/\d{4})", cc)):
            try:
                d_, m_, a_ = md.group(1).split("/")
                cand = date(int(a_), int(m_), int(d_))
            except ValueError:
                continue
            if ref_data and (cand < ref_data or (cand - ref_data).days > 400):
                continue  # data narrativa (provimento antigo, sessão passada, término de pena)
            data_sessao = cand
            break
        prazo_opos = (pz["nosso"][0] if pz["nosso"] else (pz["futuros"][0][0] if pz["futuros"] and pz["futuros"][0][1] != "outra" else None))
        if not data_sessao and not re.search(r"virtual", cc) and (pz["nosso"] or re.search(r"art\.? ?422|abr[ao]-?se vista|abro vista dos autos", cc)):
            m_pauta = None  # sem data de sessão e com ordem dirigida às partes (ex.: art. 422 CPP) — as regras de ato decidem
        elif prazo_opos and re.search(r"julgamento virtual|sessao virtual|virtual", cc) and re.search(r"oposicao|opor-se|discord|manifest|sustentacao", cc):
            ato, prazo_tab, urg, base, origem_regra = (f"Julgamento virtual" + (f" em {data_sessao.strftime('%d/%m/%Y')}" if data_sessao else " designado") + f" — oposição/pedido de sessão presencial ou sustentação oral em {prazo_opos} dias"), prazo_opos, "ALTA", "RITJ (julgamento virtual); Res. CNJ 591/24", "pauta-virtual"
            if not pz["nosso"]:
                pz["nosso"] = (prazo_opos, "generico", pz["futuros"][0][2])
                pz["futuros"] = pz["futuros"][1:]
        else:
            ato, prazo_tab, urg, base, origem_regra = ("Pauta de julgamento — sessão em " + (data_sessao.strftime("%d/%m/%Y") if data_sessao else "data no texto") + "; destaque/sustentação oral até 48h antes"), None, "ALTA", ("CPP 610 p.ú.; RITJ; Res. CNJ 591/24" if eh_pen else "CPC 934-937; Res. CNJ 591/24"), "pauta"
    if origem_regra == "pauta" and m_pauta is None:
        ato, prazo_tab, urg, base, origem_regra = "Publicação — ler e classificar", None, "MEDIA", "", "padrao"
    # 1b) contexto pela classe do processo
    classe = chave(item.get("classe") or "")
    if eh_pen and "habeas corpus" in classe and origem_regra in ("padrao", "tipo") and re.search(r"denego|denegad|concedo a ordem|concedid|nao conhec|prejudicad|\bacordam\b|nego provimento|dou provimento|indefiro|defiro|liminar (indeferida|deferida)|nego seguimento|nao cabe (o )?habeas|nao conhecimento|indeferimento liminar|procedencia do (presente )?writ|julgo procedente", chave(corpo)):
        cc_ = chave(corpo)
        preso_ = bool(penal.RE_SEM_RECESSO.search(cc_[:6000]))
        if re.search(r"\bacordam\b|denego a ordem|concedo a ordem|ordem (denegada|concedida)|por unanimidade|procedencia do (presente )?writ|julgo procedente (o pedido|o writ|a ordem|o habeas)|concedo a ordem de oficio|concedo o habeas", cc_):
            ato, prazo_tab, urg, base, origem_regra = "HC julgado — RHC em 5 dias (Lei 8.038 art. 30) ou REsp/RE em 15 dias; ED em 2 dias", 5, "CRITICA", "Lei 8.038/90 art. 30; CPC 1.003 §5º; CPP 619", "classe"
        elif re.search(r"indefiro liminarmente|indeferimento liminar|nao conhec|nego seguimento|nao cabe (o )?habeas|prejudicad|nao conhecimento", cc_):
            ato, prazo_tab, urg, base, origem_regra = "HC — decisão monocrática do relator (não conhecimento/indeferimento liminar do writ): agravo regimental em 5 dias" + (" — PACIENTE PRESO" if preso_ else ""), 5, "CRITICA", "Lei 8.038/90 art. 39; RISTJ 258", "classe"
        elif re.search(r"liminar", cc_):
            if re.search(r"indefiro|indeferid|nego", cc_):
                ato, prazo_tab, urg, base, origem_regra = "HC — liminar indeferida: aguardar informações/parecer e julgamento do mérito (agravo contra a liminar em regra não cabe — Súm. 691 STF)" + (" — PACIENTE PRESO: avaliar HC ao tribunal superior" if preso_ else ""), None, ("ALTA" if preso_ else "MEDIA"), "Súm. 691 STF; CPP 660", "classe"
            else:
                ato, prazo_tab, urg, base, origem_regra = "HC — liminar deferida: acompanhar cumprimento e julgamento do mérito", None, "ALTA", "CPP 660 §2º", "classe"
    if eh_pen and origem_regra in ("padrao", "tipo") and re.search(r"agravo (de|em) execucao|recurso em sentido estrito", classe):
        cc = chave(corpo)
        if any(re.search(r"contrarraz|contraminuta|intime-se (o|a) agravad|resposta ao (recurso|agravo)", chave(f)) and _RE_ORDEM.search(chave(f)) and direcao(chave(f), polo, True) != "outra"
               and not re.search(r"apresentou|apresentadas|ofereceu|oferecidas|juntou|com contrarrazoes|sem contrarrazoes|contrarrazoes (as|às) fls|pugnando", chave(f)) for f in frs):
            ato, prazo_tab, urg, base, origem_regra = ("Agravo em execução" if "agravo" in classe else "RESE") + " — apresentar contrarrazões (2 dias — CPP 588)", 2, "CRITICA", "CPP 588; LEP 197", "classe"
        elif re.search(r"\bacordam\b|nego provimento|dou provimento|nao conheco|julgo prejudicado|desprovido|provido|conhecido e (des)?provido|por unanimidade", cc) and not re.search(r"^(recebo|recebi) o recurso|mantenho a decisao agravada", cc):
            ato, prazo_tab, urg, base, origem_regra = ("Agravo em execução" if "agravo" in classe else "RESE") + " julgado — ED em 2 dias (CPP 619); REsp/RE em 15 dias", 2, "CRITICA", "CPP 619; CPC 1.003 §5º e 1.029", "classe"
        elif re.search(r"recebo o (recurso|agravo)|mantenho a decisao (agravada|recorrida)|juizo de retratacao|nao me retrato|deixo de me retratar|subam os autos|remetam-se (os autos )?ao (e\.? )?tribunal", cc) and (re.search(r"\bvara\b|juizo|comarca|execucao penal|execucoes|execucao criminal|deecrim|\bvep\b|\bvec\b|unidade regional", chave(item.get("orgao") or "")) or re.search(r"remet\w*-se ao (egregio |e\.? )?tribunal|subam os autos|ao tribunal para apreciacao", cc)) and origem_regra == "padrao":
            ato, prazo_tab, urg, base, origem_regra = ("Agravo em execução" if "agravo" in classe else "RESE") + " recebido / retratação negativa no 1º grau — sobe ao tribunal (ciência; contrarrazões se ainda não apresentadas)", None, "MEDIA", "CPP 589; LEP 197", "classe"
        elif re.search(r"decisao monocratica|decisao terminativa|nego seguimento|conheco do recurso e|indefiro o pedido|defiro o pedido|retrata|mantenho a decisao|extingo o (agravo|recurso)|julgo extinto|nao conheco|julgo prejudicado|deixo de (receber|conhecer)", cc) and origem_regra == "padrao":
            ato, prazo_tab, urg, base, origem_regra = ("Agravo em execução" if "agravo" in classe else "RESE") + " — decisão monocrática/retratação: avaliar agravo regimental (5 dias)", 5, "CRITICA", "RISTJ 258; RITJ", "classe"
        elif origem_regra == "padrao" and not m_pauta:
            ato, prazo_tab, urg, base, origem_regra = ("Agravo em execução" if "agravo" in classe else "RESE") + " — acompanhar processamento (ver texto)", None, "ALTA", "LEP 197; CPP 581-592", "classe"
    if origem_regra == "padrao" and "agravo de instrumento" in classe and not eh_pen:
        if re.search(r"contraminuta|contrarraz|intime-se (o|a) agravad|resposta ao (recurso|agravo)", chave(corpo)):
            ato, prazo_tab, urg, base, origem_regra = "Agravo de instrumento — apresentar contrarrazões", 15, "CRITICA", "CPC 1.019 II", "classe"
        elif re.search(r"nego provimento|dou provimento|nao conheco|julgo prejudicado|acordao", chave(corpo)):
            ato, prazo_tab, urg, base, origem_regra = "Agravo julgado — avaliar ED/REsp", 15, "CRITICA", "CPC 1.003 §5º", "classe"
        else:
            ato, prazo_tab, urg, base, origem_regra = "Agravo de instrumento — acompanhar (decisão monocrática/processamento)", None, "ALTA", "CPC 1.019", "classe"
    # 2) regras sobre as frases do corpo (só se o tipo forte não decidiu, ou para refinar sentença/acórdão)
    # a frase com o nosso prazo define o ato, se houver
    frs_ordenadas = ([pz["nosso"][2]] if pz["nosso"] else []) + [f for f in frs if not pz["nosso"] or f[:200] != pz["nosso"][2]]
    r = _regra_por_frases(frs_ordenadas, polo, tabela_atos, eh_pen, lado) if origem_regra not in ("pauta", "pauta-virtual") else None
    if origem_regra == "padrao" and r:
        ato, prazo_tab, urg, base, origem_regra, frase = r["ato"], r["prazo_tab"], r["urgencia"], r["base"], "corpo", r["frase"]
    elif origem_regra == "tipo" and r and _PESO[r["urgencia"]] <= _PESO[urg] and r["ato"] != ato and r["prazo_tab"]:
        frase = r["frase"]

    # 2a) eventos datados (audiência, perícia, sessão, leilão)
    eventos = extrair_eventos(corpo, ref=ref_data)
    if origem_regra == "pauta" and data_sessao and not any(e["tipo"] == "sessão de julgamento" for e in eventos):
        eventos.insert(0, {"tipo": "sessão de julgamento", "descricao": "pauta de julgamento", "data": data_sessao.isoformat(), "hora": None, "modalidade": "virtual" if "virtual" in chave(corpo) else "", "link": (_RE_LINK.search(corpo) or [None])[0] if _RE_LINK.search(corpo) else "", "frase": ""})
    ev_principal = next((e for e in eventos if e["tipo"] in ("audiência", "perícia", "inspeção/oitiva", "leilão/praça", "sessão do júri")), None)
    if ev_principal and (origem_regra in ("padrao", "corpo") and not (r and r["prazo_tab"] and _PESO[r["urgencia"]] == 0)):
        if origem_regra == "padrao" or ato.startswith(("Audiência", "Despacho de mero", "Decisão/diligência", "Decisão/despacho", "Publicação —", "Ciência —", "Retirado de pauta")):
            ato = f"{ev_principal['tipo'].capitalize()} marcada para {date.fromisoformat(ev_principal['data']).strftime('%d/%m/%Y')}" + (f" às {ev_principal['hora']}" if ev_principal["hora"] else "") + (f" ({ev_principal['modalidade']})" if ev_principal["modalidade"] else "") + " — preparar"
            urg, base, origem_regra = "ALTA", ("CPP 399-400 / 411 / 453 / 185" if eh_pen else "CPC 334 / 358 / 361 / 474"), "evento"

    # 2b) sentença: resultado do ponto de vista do nosso polo
    if eh_pen and ato.startswith(("Sentença", "HC julgado", "Pronúncia", "Impronúncia", "Execução penal — incidente", "Execução penal — regressão", "Liberdade concedida", "Prisão decretada")) and lado in ("defesa", "acusacao"):
        res = penal.resultado_sentenca_penal(chave(corpo), lado)
        if ato.startswith("Sentença"):
            if "juizado especial criminal" in chave(item.get("orgao") or "") or re.search(r"termo circunstanciado|juizado especial criminal|jecrim", classe + " " + chave(item.get("orgao") or "")):
                apel, base_ap = 10, "Lei 9.099/95 art. 82 (apelação 10 dias, com razões); ED 5 dias (art. 83)"
            else:
                apel, base_ap = 5, "CPP 593 / 382 / 600"
            if res == "favoravel":
                ato, prazo_tab, urg, base = f"Sentença FAVORÁVEL à nossa parte — conferir dispositivo; acompanhar apelação da parte contrária ({apel} dias)", None, "ALTA", base_ap
            elif res == "desfavoravel":
                ato, prazo_tab, urg, base = f"Sentença DESFAVORÁVEL — apelação em {apel} dias (ED em {2 if apel == 5 else 5} dias)", apel, "CRITICA", base_ap
            elif res == "parcial":
                ato, prazo_tab, urg, base = f"Sentença parcialmente favorável — avaliar apelação ({apel} dias) / ED", apel, "CRITICA", base_ap
            elif apel == 10:
                ato, prazo_tab, base = "Sentença (JECrim) — apelação em 10 dias com razões", 10, base_ap
        elif res == "favoravel" and urg == "CRITICA":
            urg = "MEDIA" if ato.startswith(("HC ", "Execução penal", "Liberdade")) else "ALTA"
            ato = ato + " — resultado FAVORÁVEL à nossa parte (ciência; acompanhar eventual recurso da outra parte)"
            prazo_tab = None
        elif res == "desfavoravel":
            urg = "CRITICA"
            ato = ato + " — resultado DESFAVORÁVEL"
    # acórdão/decisão em recurso: quem recorreu decide se o resultado nos favorece; turma recursal (JECrim): ED em 5 dias
    if eh_pen and ato.startswith(("Acórdão", "Agravo em execução julgado", "RESE julgado", "Agravo julgado")):
        jecrim_ = bool(re.search(r"turma recursal|juizado especial criminal|jecrim", chave(item.get("orgao") or "") + " " + classe))
        ed_ = 5 if jecrim_ else 2
        resr = penal.resultado_recurso(chave(corpo), parte)
        if resr == "favoravel":
            ato, prazo_tab, urg = ato.split(" — ")[0] + " FAVORÁVEL (recurso da parte contrária não provido / nosso recurso provido) — acompanhar ED/REsp da outra parte", None, "MEDIA"
        elif resr == "desfavoravel":
            ato, prazo_tab, urg = ato.split(" — ")[0] + f" DESFAVORÁVEL — ED em {ed_} dias; REsp/RE em 15 dias", ed_, "CRITICA"
        elif jecrim_:
            ato, prazo_tab, base = "Acórdão da Turma Recursal (JECrim) — ED em 5 dias (Lei 9.099 art. 83); RE em 15 dias", 5, "Lei 9.099/95 art. 83; CPC 1.003 §5º"
    if not eh_pen and ato.startswith("Sentença") and polo in ("ativo", "passivo"):
        res = resultado_sentenca(chave(corpo), polo)
        if res == "favoravel":
            ato, prazo_tab, urg, base = "Sentença FAVORÁVEL — conferir dispositivo; ED se houver omissão; acompanhar apelação da parte contrária", 5, "ALTA", "CPC 1.023 / 1.010"
        elif res == "desfavoravel":
            ato = "Sentença DESFAVORÁVEL — avaliar apelação"
        elif res == "parcial":
            ato = "Sentença parcialmente procedente — avaliar apelação/ED"

    # 2c) diligência do exequente indeferida/deferida (R10) — quando nenhuma ordem a nós foi encontrada
    frase_nos = next((f for f in frs if direcao(chave(f), polo, eh_pen, lado) in ("nos", "generico", "ambos") and _RE_ORDEM.search(chave(f)) and _RE_PROVIDENCIA.search(chave(f))
                      and not (_RE_FUTURO.search(chave(f)) and (_RE_ORDEM.search(chave(f)) is None or _RE_FUTURO.search(chave(f)).start() < _RE_ORDEM.search(chave(f)).start()))), None)
    if polo == "ativo" and not eh_pen and not pz["nosso"] and frase_nos is None and origem_regra in ("padrao", "corpo") and not ato.startswith(("Sentença", "Acórdão", "Decisão sobre ED", "Agravo", "Pauta")):
        for f in frs:
            sf = chave(f)
            if _RE_DILIG.search(sf) and _RE_INDEFERE.search(sf):
                ato, prazo_tab, urg, base, origem_regra = "Indeferimento de diligência — avaliar agravo de instrumento", 15, "ALTA", "CPC 1.015 p.ú.", "diligencia"
                break
            if _RE_DILIG.search(sf) and _RE_DEFERE.search(sf) and urg in ("BAIXA", "CRITICA") and origem_regra != "tipo":
                ato, prazo_tab, urg, base, origem_regra = "Diligência deferida — acompanhar resultado", None, "MEDIA", "CPC 835 / 854", "diligencia"
                break
    # 2d) template de cartório (R5) prevalece sobre regra genérica/mero expediente
    if template and (origem_regra == "padrao" or ato.startswith(("Despacho de mero", "Decisão/diligência", "Publicação —", "Ciência —", "Recolher custas", "Cumprimento", "Encerramento"))) and not pz["nosso"]:
        ato, urg, prazo_tab, base, origem_regra = template[0], template[1], template[2], template[3], "template"

    # 3) prazo: o dirigido a nós vence a tabela; prazo só da outra parte não é nosso
    prazo_dias, origem_prazo = None, None
    texto_narrativo = (origem_regra in ("tipo", "classe", "corpo") and eh_pen and ato.startswith(("Sentença", "Acórdão", "HC ", "Agravo em execução", "RESE", "Agravo julgado", "Pronúncia", "Impronúncia", "Liberdade", "Prisão", "Execução penal — incidente", "Execução penal — regressão", "Medidas protetivas decididas"))
                       and pz["nosso"] and not (pz["nosso"][1] == "nos" and _RE_ORDEM.search(chave(pz["nosso"][2])))) or (origem_regra in ("tipo", "classe") and not eh_pen and ato.startswith(("Sentença", "Acórdão", "Agravo julgado", "Agravo de instrumento — acompanhar"))
                       and pz["nosso"] and not (pz["nosso"][1] == "nos" and _RE_ORDEM.search(chave(pz["nosso"][2]))))
    if pz["nosso"] and not texto_narrativo:
        prazo_dias, origem_prazo = pz["nosso"][0], "texto"
        frase = frase or pz["nosso"][2]
    elif texto_narrativo and prazo_tab:
        prazo_dias, origem_prazo = prazo_tab, "tabela"
    elif pz.get("legal") and prazo_tab:
        prazo_dias, origem_prazo = prazo_tab, "legal"  # "no prazo legal" → prazo do ato
        frase = frase or pz["legal"][1]
    elif prazo_tab and (origem_regra != "padrao"):
        prazo_dias, origem_prazo = prazo_tab, "tabela"
    prazo_outra = pz["outra"][0] if pz["outra"] else None
    if ato.startswith("Edital") and origem_prazo == "texto" and not (pz["nosso"][1] == "nos" and _RE_ORDEM.search(chave(pz["nosso"][2]))):
        prazo_dias, origem_prazo = None, None  # prazo do edital (dilação/ciência ficta) não é prazo da nossa parte
    # R8) piso: ordem dirigida a nós com verbo de providência → no mínimo ALTA; com "sob pena"/485 mesmo sem prazo
    if frase_nos is not None and urg in ("BAIXA", "MEDIA") and not ato.startswith(("Pauta", "Migração para o eproc", "Trânsito")):
        if prazo_dias or _RE_SOB_PENA.search(corpo_chave) or origem_regra in ("padrao", "template") or (eh_pen and ato.startswith(("Despacho de mero", "Decisão/despacho"))):
            urg = "ALTA"
            if origem_regra in ("padrao",) or ato.startswith(("Despacho de mero", "Decisão/diligência", "Publicação —", "Ciência —", "Distribuição")):
                ato = "Cumprir determinação: " + uma_linha(frase_nos)[:120]
                frase = frase or frase_nos

    # 4) urgência
    if prazo_dias and prazo_dias <= 5 and origem_prazo == "texto":
        urg = "CRITICA"
    elif prazo_dias and urg in ("BAIXA",):
        urg = "MEDIA"
    if not prazo_dias and pz["futuros"] and urg in ("CRITICA", "ALTA") and origem_regra in ("corpo", "padrao") and not ato.startswith(("Sentença", "Acórdão", "Decisão sobre ED", "Agravo")):
        ato, urg = ato + " — prazo futuro/condicionado (aguardar nova intimação)", "MEDIA"
    if not prazo_dias and prazo_outra and urg in ("CRITICA", "ALTA") and origem_regra == "corpo" and (r or {}).get("direcao") in ("indef", "generico") and ato.startswith(("Contestar", "Cumprimento", "Citação")):
        # ordem dirigida à outra parte (ex.: "cite-se o réu para contestar") lida por nós = ciência
        ato, urg, base = f"{ato} — ordem dirigida à parte contrária (ciência)", "MEDIA", base
    if urg == "BAIXA" and (pz["outra"] or re.search(r"cite-se|citem-se|cite\(m\)-se|intime-se a parte (executada|requerida|re)|expeca-se (carta|mandado)", chave(corpo))):
        ato, urg = "Ciência — providência/prazo da parte contrária (acompanhar)", "MEDIA"
    if not prazo_dias and pz["futuros"] and pz["futuros"][0][1] == "nos" and pz["futuros"][0][0] <= 5 and urg == "MEDIA":
        ato, urg = ato.replace(" — prazo futuro/condicionado (aguardar nova intimação)", "") + " — prazo condicionado a verificar (" + str(pz["futuros"][0][0]) + " dias se a condição se aplicar)", "ALTA"
    if eventos:
        try:
            prox = date.fromisoformat(eventos[0]["data"])
            if 0 <= (prox - (hoje or date.today())).days <= 7 and urg in ("ALTA", "MEDIA", "BAIXA") and eventos[0]["tipo"] != "sessão de julgamento":
                urg = "CRITICA"
        except ValueError:
            pass
    if item.get("cancelada"):
        urg = "CANCELADA"

    m_dobro = (penal.RE_DOBRO_PENAL if eh_pen else _RE_DOBRO).search(chave(corpo))
    dobro = bool(cfg_prazos.get("dobro"))
    prazo = None
    # penal: o recesso suspende o prazo (CPP 798-A), salvo réu preso, Lei Maria da Penha e urgência — nesses o prazo corre
    sem_recesso = bool(eh_pen and (penal.RE_SEM_RECESSO.search(chave(texto[:6000])) or penal.RE_SEM_RECESSO.search(chave(item.get("classe") or "")) or penal.RE_SEM_RECESSO.search(chave(item.get("orgao") or ""))))
    contar = (lambda d, n, dobro=False: prazos.contar_prazo_penal(d, n, dobro=dobro, suspende_recesso=not sem_recesso)) if eh_pen else prazos.contar_prazo
    if origem_regra == "pauta":
        prazo_dias, origem_prazo = None, None
        if data_sessao:
            limite = data_sessao - __import__("datetime").timedelta(days=2)
            prazo = {"disponibilizacao": item.get("data"), "publicacao": item.get("data"), "inicio": item.get("data"), "fim": limite.isoformat(), "dias": 2, "dias_contados": 2, "dobro": False,
                     "base_legal": "48h antes da sessão (Res. CNJ 591/24) — destaque/sustentação", "sessao": data_sessao.isoformat()}
            origem_prazo, prazo_dias = "sessao", 2
            if (data_sessao - (hoje or date.today())).days <= 7:
                urg = "CRITICA"
    elif prazo_dias and item.get("data"):
        try:
            prazo = contar(date.fromisoformat(item["data"]), prazo_dias, dobro=dobro)
        except ValueError:
            prazo = None
    # (b) prazo dirigido a nós com regra genérica → rótulo honesto
    if prazo_dias and origem_prazo == "texto" and (origem_regra == "padrao" or ato.startswith(("Despacho de mero", "Decisão/diligência", "Encerramento", "Ciência —", "Distribuição"))):
        ato = "Prazo fixado para a nossa parte — ver texto"
    return {
        "ato": ato, "urgencia": urg, "prazo_dias": prazo_dias, "origem_prazo": origem_prazo, "base_legal": base, "gera_prazo": bool(prazo_dias),
        "dobro_aplicado": dobro, "dobro_sugerido": bool(m_dobro) and not dobro, "motivo_dobro": cfg_prazos.get("motivo_dobro") or (m_dobro.group(0) if m_dobro else ""),
        "prazo": prazo, "prazo_outra_parte": prazo_outra, "prazo_futuro": pz["futuros"][0][0] if pz["futuros"] else None, "origem_regra": origem_regra, "frase": uma_linha(frase)[:200],
        "eventos": eventos,
        "perfil": "penal" if eh_pen else "civel", "penal_motivo": motivo_penal or "", "seeu": (penal.origem_seeu(item) if eh_pen else ""), "sem_recesso": sem_recesso,
        "execucao_penal": bool(eh_pen and penal.eh_execucao_penal(item)),
        "nossa_parte": parte, "formato_texto": formato, "corpo_chars": len(corpo), "corpo_resumo": uma_linha(corpo)[:400],
    }


def combinar_ia(triagem: dict, ia: Optional[dict], data: str, dobro: bool) -> dict:
    """Política IA × regras: (1) prazo só da IA → usa; (2) IA 'apenas ciência' + prazo só de tabela → rebaixa; (3) IA prazo ≠ regex → mantém regex, anota."""
    if not ia:
        return triagem
    t = dict(triagem)
    ia_prazo = ia.get("prazo_dias")
    acao = chave(ia.get("acao") or "")
    so_ciencia = bool(re.search(r"apenas ciencia|nenhuma acao|nada a fazer|sem acao|somente ciencia|aguardar", acao)) and not ia_prazo
    prazo_outra = t.get("prazo_outra_parte")
    so_ciencia_txt = bool(re.search(r"apenas ciencia|nenhuma acao|nada a fazer|sem acao|somente ciencia|aguardar|acompanhar", acao))
    blindado = str(t.get("ato", "")).startswith(("Sentença", "Acórdão", "Decisão sobre ED", "Agravo", "Indeferimento de diligência", "Cumprir determinação", "Pauta", "Julgamento virtual",
                                                 "HC ", "Pronúncia", "Impronúncia", "RESE", "Execução penal — regressão", "Execução penal — incidente", "Prisão", "Liberdade", "Medidas protetivas decididas", "REsp/RE inadmitido", "MS julgado", "Júri")) or t.get("origem_prazo") in ("texto", "legal", "sessao")
    corroborado = t.get("urgencia") in ("ALTA", "CRITICA") or t.get("origem_regra") in ("corpo", "classe", "evento")
    if so_ciencia and blindado:
        t["observacao_ia"] = "IA sugeriu apenas ciência; há sentença/decisão/ordem à nossa parte — urgência mantida"
        return t
    if ia_prazo and not t.get("prazo_dias") and not so_ciencia_txt and ia_prazo != prazo_outra and ia_prazo != t.get("prazo_futuro") and corroborado:
        t.update({"prazo_dias": int(ia_prazo), "origem_prazo": "ia", "gera_prazo": True})
        try:
            if t.get("perfil") == "penal":
                t["prazo"] = prazos.contar_prazo_penal(date.fromisoformat(data), int(ia_prazo), dobro=dobro, suspende_recesso=not t.get("sem_recesso"))
            else:
                t["prazo"] = prazos.contar_prazo(date.fromisoformat(data), int(ia_prazo), dobro=dobro)
        except (ValueError, TypeError):
            pass
        if t["urgencia"] in ("BAIXA", "MEDIA"):
            t["urgencia"] = "CRITICA" if int(ia_prazo) <= 5 else "ALTA"
    elif ia_prazo and not t.get("prazo_dias") and not so_ciencia_txt and (ia_prazo == prazo_outra or ia_prazo == t.get("prazo_futuro")):
        t["observacao_ia"] = "IA leu um prazo que é da parte contrária ou condicionado a evento futuro — não contado"
    elif so_ciencia and t.get("origem_prazo") == "tabela":
        t.update({"urgencia": "MEDIA", "observacao_ia": "IA: apenas ciência — prazo padrão da tabela não confirmado no texto"})
    elif so_ciencia and t.get("origem_prazo") == "texto" and t.get("urgencia") in ("CRITICA", "ALTA"):
        t["observacao_ia"] = "IA: apenas ciência — confira se o prazo do texto é da nossa parte"
    elif ia_prazo and t.get("prazo_dias") and int(ia_prazo) != int(t["prazo_dias"]):
        t["observacao_ia"] = f"IA leu prazo de {ia_prazo} dias (regras: {t['prazo_dias']}) — confira"
    return t


def ordem_urgencia(triagem: dict) -> tuple:
    """Chave de ordenação: mais urgente primeiro, depois prazo mais próximo."""
    fim = (triagem.get("prazo") or {}).get("fim") or "9999-12-31"
    return (_PESO.get(triagem.get("urgencia"), 3), fim)


def aprender_partes(itens: List[dict], oabs: Iterable[Tuple[str, str]]) -> Tuple[Dict[str, int], Dict[str, int]]:
    """A partir dos itens em que o cabeçalho identifica nossa parte: (clientes {nome: n}, adversários {nome: n})."""
    clientes: Dict[str, int] = {}
    adversarios: Dict[str, int] = {}
    for it in itens:
        r = nossa_parte_por_oab(it.get("texto") or "", oabs)
        if not r or r["polo"] not in ("ativo", "passivo"):
            continue
        if r.get("nome"):
            n = uma_linha(r["nome"])
            clientes[n] = clientes.get(n, 0) + 1
        nosso_api = "A" if r["polo"] == "ativo" else "P"
        for p in it.get("partes") or []:
            if p.get("nome") and p.get("polo") in ("A", "P") and p["polo"] != nosso_api:
                n = uma_linha(p["nome"])
                adversarios[n] = adversarios.get(n, 0) + 1
    return clientes, adversarios


def aprender_clientes(itens: List[dict], oabs: Iterable[Tuple[str, str]]) -> Dict[str, int]:
    return aprender_partes(itens, oabs)[0]
