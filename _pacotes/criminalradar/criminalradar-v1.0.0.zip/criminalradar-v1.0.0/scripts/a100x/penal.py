"""Perfil PENAL da triagem: detecção de publicação criminal, execução penal/SEEU, papéis (defesa × acusação),
tabela de atos com prazos em DIAS CORRIDOS (CPP 798) e resultado de sentença do ponto de vista da defesa.

Usado por `classificar.classificar` quando o perfil da carteira é "criminal" ou quando, no perfil "auto",
a publicação é reconhecida como penal pela classe, pelo órgão ou pelo texto.
"""
from __future__ import annotations

import re
from typing import Optional

from .texto import chave

# ----------------------------------------------------------------------------- detecção
RE_CLASSE_PENAL = re.compile(
    r"acao penal|inquerito|execucao da pena|execucao provisoria|execucao de medidas? alternativas?|execucao de pena de multa|execucao penal|"
    r"habeas corpus|apelacao criminal|recurso em sentido estrito|agravo de execucao|agravo em execucao|revisao criminal|medidas? protetivas?|"
    r"auto de prisao em flagrante|flagrante|lei antitoxicos|lei de drogas|entorpecentes|competencia do juri|tribunal do juri|termo circunstanciado|"
    r"juizado especial criminal|representacao criminal|noticia de crime|pedido de prisao|prisao (preventiva|temporaria)|busca e apreensao criminal|"
    r"liberdade provisoria|relaxamento de prisao|embargos infringentes e de nulidade|carta testemunhavel|recurso ordinario em habeas|"
    r"procedimento investigatorio|quebra de sigilo|interceptacao|incidente de insanidade|restituicao de coisas apreendidas|medida de seguranca|"
    r"producao antecipada de provas criminal|alienacao de bens do acusado|unificacao de penas|livramento condicional|remicao|progressao de regime|"
    r"saida temporaria|indulto|comutacao|reabilitacao|transacao penal|acordo de nao persecucao|suspensao condicional do processo|"
    r"peticao criminal|cautelar (inominada )?criminal|conflito de jurisdicao|excecao de (suspeicao|incompetencia|litispendencia|coisa julgada)|criminal\b|penal\b")
RE_ORGAO_PENAL = re.compile(
    r"criminal|crime\b|execuc(ao|oes) penal|execuc(ao|oes) criminal|\bvep\b|\bvec\b|juri\b|violencia domestica|jecrim|toxicos|entorpecentes|drogas|"
    r"garantias|custodia|inqueritos|auditoria militar|justica militar|corregedoria dos presidios|precatorias criminais|delitos|"
    r"turma criminal|secao criminal|camara criminal|grupo criminal|orgao especial criminal|penal\b")
RE_TEXTO_PENAL = re.compile(
    r"pretensao punitiva|denuncia (oferecida|recebida)|recebo a denuncia|\breu preso\b|\bacusad[oa]\b|\bdenunciad[oa]\b|\bapenad[oa]\b|\breeducand[oa]\b|"
    r"\bsentenciad[oa]\b|\bcondenad[oa]\b.{0,40}\bpena\b|pena privativa de liberdade|regime (fechado|semiaberto|aberto)|\bcpp\b|codigo de processo penal|"
    r"lei de execucao penal|\blep\b|\bseeu\b|alvara de soltura|mandado de prisao|prisao preventiva|liberdade provisoria|inquerito policial|"
    r"ministerio publico.{0,60}(denuncia|acusacao)|resposta a acusacao|alegacoes finais|memoriais.{0,40}(defesa|acusacao)|absolv|"
    r"agravo em execucao|progressao de regime|livramento condicional|remicao|falta grave|audiencia de custodia|audiencia admonitoria")
RE_EXECUCAO_PENAL = re.compile(r"execucao da pena|execucao provisoria|execucao de medidas? alternativas?|execucao de pena de multa|execucao penal|execucoes penais|execucoes criminais|\bvep\b|\bvec\b|livramento condicional|progressao de regime|remicao|saida temporaria|unificacao de penas|\bseeu\b")
RE_SEEU = re.compile(r"\bseeu\b|sistema eletronico de execucao unificado")

# tipos de execução penal que aparecem como classe/órgão de execução mas NÃO tramitam no SEEU (multa e alternativas em alguns tribunais tramitam no eproc/PJe)
_RE_EXEC_NAO_SEEU = re.compile(r"execucao fiscal|execucao de titulo|cumprimento de sentenca")


_RE_CLASSE_CIVEL = re.compile(r"civel|civil|familia|fazenda|trabalh|consumidor|execucao fiscal|cumprimento de sentenca|monitoria|usucapiao|inventario|alimentos|divorcio|despejo|cobranca|indeniza|alienacao fiduciaria|recuperacao judicial|falencia|tutela|empresarial|previdenciari|tributari|locacao|consignacao|imissao|reintegracao|desapropriacao|embargos (a execucao|de terceiro)|producao antecipada de provas(?! criminal)|procedimento comum(?! criminal)|juizado especial (civel|da fazenda)")


def eh_penal(item: dict) -> Optional[str]:
    """'classe' | 'orgao' | 'texto' | None — por que a publicação foi considerada penal.
    Classe manda: classe penal → penal; classe claramente cível → nunca penal (mesmo que o texto cite o CPP).
    Sem classe decisiva, vale o órgão; por último, o texto (dois ou mais marcadores penais)."""
    classe = chave(item.get("classe") or "")
    orgao = chave(item.get("orgao") or "")
    if classe and RE_CLASSE_PENAL.search(classe) and not _RE_EXEC_NAO_SEEU.search(classe):
        return "classe"
    if classe and _RE_CLASSE_CIVEL.search(classe):
        return None
    orgao_penal = bool(orgao and RE_ORGAO_PENAL.search(orgao))
    orgao_civel = bool(orgao and re.search(r"civel|familia|fazenda|empresarial|trabalho|consumidor|juizado especial civel", orgao))
    if orgao_penal and not orgao_civel:
        return "orgao"
    if orgao_civel and not orgao_penal:
        return None
    texto = chave((item.get("texto") or "")[:6000])
    if len(RE_TEXTO_PENAL.findall(texto)) >= 2:
        return "texto"
    return None


def eh_execucao_penal(item: dict) -> bool:
    """Classe de execução penal (1º grau ou agravo em execução), órgão de execução quando a classe não diz o contrário, ou texto que cita o SEEU.
    Ação penal/HC/apelação numa 'Vara Criminal e de Execuções Penais' (competência mista) NÃO é execução."""
    classe = chave(item.get("classe") or "")
    orgao = chave(item.get("orgao") or "")
    if _RE_EXEC_NAO_SEEU.search(classe):
        return False
    if RE_EXECUCAO_PENAL.search(classe) or "agravo de execucao" in classe or "agravo em execucao" in classe:
        return True
    if classe and _RE_CLASSE_CONHECIMENTO.search(classe):
        texto = chave((item.get("texto") or "")[:4000])
        return bool(RE_SEEU.search(texto))
    if RE_EXECUCAO_PENAL.search(orgao):
        return True
    texto = chave((item.get("texto") or "")[:4000])
    return bool(RE_SEEU.search(texto)) or (bool(re.search(r"execucao (da pena|penal)", texto)) and bool(RE_TEXTO_PENAL.search(texto)))


_RE_CLASSE_EXEC_1G = re.compile(r"execucao da pena|execucao provisoria|execucao de medidas? alternativas?|execucao de pena de multa|execucao penal|livramento condicional|remicao|progressao|saida temporaria|unificacao|indulto|comutacao")
_RE_CLASSE_CONHECIMENTO = re.compile(r"acao penal|inquerito|habeas corpus|apelacao|recurso em sentido estrito|medidas? protetivas?|flagrante|termo circunstanciado|representacao|revisao criminal|embargos|carta testemunhavel|producao antecipada|peticao criminal|juizado especial criminal|procedimento (ordinario|sumario|sumarissimo|especial)")


def origem_seeu(item: dict) -> str:
    """'texto' (o ato cita o SEEU) | 'seeu' (classe de execução penal de 1º grau — tramita no SEEU em 33 tribunais)
    | 'execucao' (agravo em execução / órgão de execução — ligado à execução, mas os autos do recurso ficam no sistema do tribunal) | ''."""
    texto = chave((item.get("texto") or "")[:6000])
    classe = chave(item.get("classe") or "")
    if RE_SEEU.search(texto) or RE_SEEU.search(chave(item.get("orgao") or "")):
        return "texto"
    if classe and _RE_CLASSE_EXEC_1G.search(classe) and not _RE_EXEC_NAO_SEEU.search(classe) and "agravo" not in classe and "recurso" not in classe:
        return "seeu"
    if eh_execucao_penal(item):
        return "execucao"
    return ""


# ----------------------------------------------------------------------------- papéis (defesa = passivo; acusação = ativo)
# entram no regex global de papéis do classificador (são termos exclusivamente penais, não confundem o cível)
ATIVO_PENAL = r"ministerio publico|promotor(a|ia)?( de justica)?|querelante|assistente (de|da) acusacao|acusacao|parquet|vitima|ofendid[oa]|representante|\bmp\b|\bmpf\b|\bmpe\b"
PASSIVO_PENAL = r"acusad[oa]s?|denunciad[oa]s?|indiciad[oa]s?|investigad[oa]s?|reeducand[oa]s?|apenad[oa]s?|sentenciad[oa]s?|condenad[oa]s?|paciente|querelad[oa]s?|autor(a)? do fato|representad[oa]s?|flagrante?ad[oa]s?|custodiad[oa]s?|averiguad[oa]s?|agravante em execucao|defesa|defensor(a|ia)?( publica)?|advogad[oa] de defesa|pres[oa]s?\b"
PAPEIS_PENAL = r"ACUSAD[OA]|DENUNCIAD[OA]|INDICIAD[OA]|INVESTIGAD[OA]|REEDUCAND[OA]|APENAD[OA]|SENTENCIAD[OA]|CONDENAD[OA]|PACIENTE|QUERELANTE|QUERELAD[OA]|AUTOR(A)? DO FATO|REPRESENTAD[OA]|REPRESENTANTE|FLAGRANTEAD[OA]|CUSTODIAD[OA]|V[ÍI]TIMA|OFENDID[OA]|ASSISTENTE DE ACUSA[ÇC][ÃA]O|MINIST[ÉE]RIO P[ÚU]BLICO|PROMOTOR(IA)?|IMPETRANTE|IMPETRAD[OA]|COATOR"

# situações em que o recesso NÃO suspende o prazo penal (CPP 798-A I-III): réu preso, Lei Maria da Penha, urgência declarada
RE_SEM_RECESSO = re.compile(
    r"reu preso|re presa|reus presos|acusad[oa]s? pres[oa]s?|paciente pres[oa]|apenad[oa] pres[oa]|presos?\b.{0,20}(preventiv|cautelar)|prisao preventiva|prisao temporaria|"
    r"\b(reu|re|reus|acusad[oa]s?|denunciad[oa]s?|paciente|apenad[oa]|sentenciad[oa]|reeducand[oa]|condenad[oa]|investigad[oa]|indiciad[oa])\b[^.;]{0,60}\b(pres[oa]s?|recolhid[oa]s?|segregad[oa]s?|custodiad[oa]s?|encarcerad[oa]s?)\b|"
    r"(encontra-se|encontram-se|esta|estao|permanece|permanecem|mantem-se|segue|seguem)\s+(pres[oa]s?|recolhid[oa]s?|segregad[oa]s?|custodiad[oa]s?|encarcerad[oa]s?)|"
    r"custodiad[oa]|segregad[oa]|encarcerad[oa]|recolhid[oa] (ao|a|no|na) (carcere|presidio|unidade|penitenciaria|cadeia|cdp|cpp)|em regime fechado|cumprindo pena|"
    r"violencia domestica|maria da penha|lei (n\.? ?)?11\.?340|medidas? protetivas?|\burgente\b|\burgencia\b|plantao")
RE_DOBRO_PENAL = re.compile(r"prazo em dobro|defensoria publica|nucleo de pratica juridica|assistencia judiciaria|lc ?80|lei complementar (n\.? ?)?80|art\.? ?(44|89|128)\b.{0,20}(lc|lei complementar)|art\.? ?5.?,? ?§ ?5.? da lei (n\.? ?)?1\.?060")

# ----------------------------------------------------------------------------- tabela de atos (prazos em dias corridos — CPP 798)
# (regex sobre frase canônica, ato, prazo padrão, urgência, base legal, polos, exige_ordem)
BASE_CONTAGEM = "CPP 798 (dias corridos; prorroga ao 1º dia útil — §3º; Súm. 310 STF); Lei 11.419/06 art. 4º §§3º-4º"
TODOS = ("ativo", "passivo", "indeterminado", "outro")
DEF = ("passivo", "indeterminado", "outro")
ATOS_PENAL = [
    # ---- ordens dirigidas às partes (exigem verbo de ordem)
    (r"contrarraz\w*.{0,80}(sentido estrito|\brese\b)|(sentido estrito|\brese\b).{0,80}contrarraz|contrarraz\w* .{0,30}art\.? ?588", "Contrarrazões ao recurso em sentido estrito", 2, "CRITICA", "CPP 588", TODOS, True),
    (r"contrarraz\w*.{0,60}embargos infringentes|embargos infringentes.{0,60}(contrarraz|manifest|impugn)", "Manifestar sobre embargos infringentes e de nulidade", 10, "CRITICA", "CPP 609 p.ú.", TODOS, True),
    (r"contrarraz\w*.{0,60}(agravo em execucao|agravo de execucao)|(agravo em execucao|agravo de execucao).{0,60}contrarraz", "Contrarrazões ao agravo em execução", 2, "CRITICA", "CPP 588 (rito do RESE — Súm. 700 STF); confira prazo fixado", TODOS, True),
    (r"contrarraz\w*.{0,60}(recurso especial|recurso extraordinario|\bresp\b)|(recurso especial|recurso extraordinario).{0,60}contrarraz", "Contrarrazões ao REsp/RE", 15, "CRITICA", "CPC 1.030 (15 dias, corridos no penal — CPP 798)", TODOS, True),
    (r"contrarraz\w*.{0,60}(agravo em recurso especial|agravo em recurso extraordinario|\baresp\b|\bare\b)|(\baresp\b|\bare\b).{0,60}contrarraz", "Contrarrazões ao AREsp/ARE", 15, "CRITICA", "CPC 1.042 §3º (15 dias)", TODOS, True),
    (r"contrarraz|contraminuta|contra-?razoes", "Apresentar contrarrazões de apelação", 8, "CRITICA", "CPP 600 (8 dias; JECrim: 10 dias — Lei 9.099 art. 82 §2º)", TODOS, True),
    (r"embargos de declaracao.{0,80}(manifest|impugn|contrarraz|vista|resposta)|(manifest|impugn|vista|resposta).{0,80}embargos de declaracao", "Manifestar sobre embargos de declaração da parte contrária", 5, "CRITICA", "prazo judicial; CPC 1.023 §2º por analogia (CPP 3º) — sem prazo legal no CPP", TODOS, True),
    (r"art\.? ?514|funcionario publico.{0,80}(resposta|defesa preliminar|notifica)|(resposta|defesa preliminar).{0,80}art\.? ?514", "Defesa preliminar — crime de funcionário público (CPP 514)", 15, "CRITICA", "CPP 514 (15 dias da notificação)", DEF, True),
    (r"acao penal originaria|art\.? ?4.? da lei (n\.? ?)?8\.?038|lei 8\.?038.{0,40}art\.? ?4\b", "Resposta em ação penal originária (Lei 8.038 art. 4º)", 15, "CRITICA", "Lei 8.038/90 art. 4º (15 dias)", DEF, True),
    (r"resposta (escrita )?a acusacao|resposta a denuncia|art\.? ?396|defesa preliminar|defesa previa|art\.? ?55 da lei", "Resposta à acusação / defesa prévia (preliminares, teses, rol de testemunhas)", 10, "CRITICA", "CPP 396/396-A (10 dias); Lei 11.343/06 art. 55 (10 dias)", DEF, True),
    (r"alegacoes (escritas|finais).{0,60}art\.? ?11 da lei|art\.? ?11 da lei (n\.? ?)?8\.?038", "Alegações escritas em ação penal originária (Lei 8.038 art. 11)", 15, "CRITICA", "Lei 8.038/90 art. 11 (15 dias, sucessivos)", TODOS, True),
    (r"memoriais|alegacoes finais|razoes finais|art\.? ?403|art\.? ?404", "Alegações finais / memoriais", 5, "CRITICA", "CPP 403 §3º / 404 p.ú. (5 dias, sucessivos); no júri as alegações são orais (CPP 411 §4º) — se convertidas em memoriais, vale o prazo do despacho", TODOS, True),
    (r"art\.? ?422|para o plenario.{0,80}(testemunhas|diligencias|documentos)|(testemunhas|diligencias|documentos).{0,80}(para o |em )plenario|rol de testemunhas.{0,60}juri", "Júri — art. 422 CPP: rol de testemunhas (até 5), diligências e documentos para o plenário", 5, "CRITICA", "CPP 422 (5 dias)", TODOS, True),
    (r"razoes (de |do |da )?(apelacao|recurso)|apresent\w* (as )?razoes|arrazoar|art\.? ?600", "Apresentar razões de apelação", 8, "CRITICA", "CPP 600 (8 dias; RESE: 2 dias — CPP 588)", TODOS, True),
    (r"agravo em execucao|agravo de execucao|art\.? ?197 da lep", "Agravo em execução — 5 dias", 5, "CRITICA", "LEP 197; Súm. 700 STF", TODOS, True),
    (r"carta testemunhavel", "Carta testemunhável — 48 horas", 2, "CRITICA", "CPP 640", TODOS, False),
    (r"agravo regimental|agravo interno", "Agravo regimental/interno — 5 dias", 5, "CRITICA", "Lei 8.038/90 art. 39; RISTJ 258; RISTF 317", TODOS, False),
    (r"nomea\w* (como |para (atuar como )?)?(defensor|advogad)|defensor(a)? dativ|nomeio (o|a) (dr|dra|advogad|defensor)", "Nomeação como defensor(a) dativo(a) — aceitar/recusar, verificar fase e prazos em curso", None, "ALTA", "CPP 263-265; Lei 1.060/50", TODOS, False),
    # ---- decisões que abrem prazo recursal (resultado refinado depois pelo lado defesa × acusação)
    (r"\bpronuncio\b|pronuncia(do|da)? o (reu|acusado)|decisao de pronuncia", "Pronúncia — RESE em 5 dias (júri)", 5, "CRITICA", "CPP 413 / 581 IV / 586", DEF, False),
    (r"\bimpronuncio\b|absolv\w* sumariamente|desclassific\w* (o|a) (crime|conduta|infracao)", "Impronúncia / absolvição sumária / desclassificação — avaliar recurso (5 dias)", 5, "CRITICA", "CPP 414-419; 581 IV; 593", TODOS, False),
    (r"\babsolvo\b|julgo improcedente a (pretensao punitiva|denuncia|acao penal|acusacao)|rejeito a denuncia|extin(go|ta) a punibilidade|declaro extinta a punibilidade|reconheco a prescricao|pronuncio a prescricao", "Sentença ABSOLUTÓRIA/extintiva — conferir dispositivo; ED 2 dias; acompanhar apelação do MP (5 dias)", 5, "ALTA", "CPP 386 / 382 / 593 / 107 CP", TODOS, False),
    (r"\bcondeno\b|julgo (parcialmente )?procedente (a|em parte a) (pretensao punitiva|denuncia|acao penal|acusacao)|fixo a pena|pena definitiva|torno definitiva a pena", "Sentença CONDENATÓRIA — apelação em 5 dias (ED em 2 dias)", 5, "CRITICA", "CPP 593 / 382 / 600", TODOS, False),
    (r"denego a ordem|ordem denegada|nao conheco (do|da) (habeas|ordem|writ|impetracao)|nao conhecimento (do|da) (habeas|impetracao|writ)|concedo a ordem|ordem concedida|habeas corpus (concedido|denegado)", "HC julgado — avaliar RHC (5 dias) / REsp-RE (15 dias)", 5, "CRITICA", "Lei 8.038/90 art. 30 (RHC); CPC 1.003 §5º (REsp/RE)", TODOS, False),
    (r"denego a seguranca|seguranca denegada|concedo a seguranca|seguranca concedida|mandado de seguranca.{0,60}(denegad|concedid|julgad)", "MS julgado — recurso ordinário (RMS) em 15 dias", 15, "CRITICA", "Lei 8.038/90 art. 33; CPC 1.027-1.028", TODOS, False),
    (r"rejeito os embargos de declaracao|acolho os embargos de declaracao|embargos de declaracao (rejeitad|acolhid|conhecid|nao conhecid|providos|improvidos)", "Decisão sobre ED — prazo recursal reaberto (apelação 5 / REsp-RE 15 / RESE 5)", 5, "CRITICA", "CPP 382/619; CPP 593; CPC 1.026 (interrupção) e 1.003 §5º", TODOS, False),
    (r"\bacordam\b|nego provimento|dou provimento|nego seguimento|nao conheco do (recurso|agravo)|recurso (nao )?(conhecido|provido)|agravo (nao )?provido|desprovido|provimento negado|acordao (publicado|proferido)|ementa", "Acórdão criminal — ED em 2 dias (CPP 619); REsp/RE em 15 dias", 2, "CRITICA", "CPP 619; CPC 1.003 §5º e 1.029 (corridos — CPP 798)", TODOS, False),
    (r"inadmit\w* (o )?(recurso especial|recurso extraordinario)|nao admito (o )?(recurso especial|recurso extraordinario)|nego seguimento ao (recurso especial|recurso extraordinario)|juizo (negativo )?de admissibilidade", "REsp/RE inadmitido — agravo (AREsp/ARE) em 15 dias", 15, "CRITICA", "CPC 1.042 c/c 1.003 §5º (Súm. 699 STF superada pelo CPC/2015 — STF)", TODOS, False),
    (r"recebo a denuncia|denuncia (foi )?recebida|recebimento da denuncia|cite-se o (reu|acusado|denunciado)", "Denúncia recebida — resposta à acusação em 10 dias da citação (CPP 396); acompanhar citação", None, "ALTA", "CPP 396/396-A", DEF, False),
    # ---- execução penal
    (r"calculo (de |da )?(pena|liquidacao)|atestado de pena|liquidacao de pena|guia de (execucao|recolhimento)|planilha de pena", "Execução penal — manifestar sobre cálculo/atestado de pena", 3, "ALTA", "LEP 196 (3 dias, salvo prazo fixado no despacho); agravo em execução — LEP 197", TODOS, True),
    (r"\bregrid|regress\w* (de|do|cautelar de) regime|(reconhec|homolog|declar)\w* a (pratica de )?falta grave|apura\w* (de |da )?falta grave|audiencia de justificacao|procedimento (administrativo )?disciplinar", "Execução penal — regressão/falta grave: preparar defesa (agravo em 5 dias se decidido)", 5, "CRITICA", "LEP 118/59; LEP 197; Súm. 700 STF", TODOS, False),
    (r"progress\w* (de|do) regime|livramento condicional|remicao|saida temporaria|indulto|comutacao|unificacao (de|das) penas|prisao domiciliar|monitora\w* eletronic|regime (aberto|semiaberto|fechado)|sursis", "Execução penal — incidente/benefício: conferir decisão; agravo em execução em 5 dias", 5, "ALTA", "LEP 112/126/131/122; LEP 197; Súm. 700 STF", TODOS, False),
    # ---- prisão e liberdade
    (r"decreto a prisao|decreto a custodia|mandado de prisao|convert\w* (a prisao )?em preventiva|mantenho a (prisao|custodia)|manutencao da (prisao|custodia|segregacao)|mantida a (prisao|custodia)|indefiro (o pedido de )?(liberdade|revogacao|relaxamento)|nego a liberdade|preventiva (decretada|mantida)|permanec\w* (pres[oa]|custodiad|segregad)|prisao preventiva", "Prisão decretada/mantida — avaliar HC, revogação ou cautelares (CPP 319); RESE se cabível (5 dias)", None, "CRITICA", "CPP 312-316 / 319; CPP 581 V; CF 5º LXVIII (HC sem prazo)", DEF, False),
    (r"recebo (o|a) (recurso|apelacao)|receb\w* (a|o) (apelacao|recurso) (de|da|do|interposto)|processe-se o recurso", "Recurso recebido — conferir se as razões já foram apresentadas (apelação: 8 dias — CPP 600) e acompanhar a remessa", None, "ALTA", "CPP 600 / 601", TODOS, False),
    (r"revogo a prisao|concedo (a )?liberdade|alvara de soltura|relaxo a prisao|liberdade provisoria (concedida|deferida)|expeca-se alvara", "Liberdade concedida — acompanhar cumprimento do alvará e condições", None, "ALTA", "CPP 310 / 321", DEF, False),
    # ---- demais ordens e ciências
    (r"acordo de nao persecucao|\banpp\b|suspensao condicional do processo|sursis processual|transacao penal|proposta (do ministerio publico|de acordo)|art\.? ?28-?a|art\.? ?89 da lei", "Justiça negocial — orientar o cliente sobre ANPP/suspensão condicional/transação; cumprir o determinado", None, "ALTA", "CPP 28-A; Lei 9.099/95 arts. 76 e 89 (prazo judicial)", DEF, True),
    (r"rol de testemunhas|arrolar testemunhas|indicar testemunhas|substitui\w* (de |da )?testemunha", "Testemunhas — arrolar/substituir", 10, "ALTA", "CPP 396-A (com a resposta); CPP 405 (prazo judicial)", TODOS, True),
    (r"diligencias.{0,40}art\.? ?402|art\.? ?402|requer\w* (as )?diligencias", "Requerer diligências (CPP 402)", None, "ALTA", "CPP 402 (prazo judicial)", TODOS, True),
    (r"pena de multa|prestacao pecuniaria|pagar a multa|pagamento da multa|parcelamento da multa", "Pena de multa — pagar/parcelar em 10 dias do trânsito; ou impugnar", 10, "ALTA", "CP 50; LEP 164-170", DEF, True),
    (r"custas|taxa judiciaria|preparo", "Recolher custas (se condenado; isento se gratuidade)", 5, "MEDIA", "prazo judicial", TODOS, True),
    (r"quesitos|assistente tecnico|laudo|pericia|exame (de corpo de delito|pericial|toxicologico|de insanidade)", "Manifestar sobre laudo/perícia — quesitos e assistente técnico", None, "ALTA", "CPP 159 §§3º-5º (prazo judicial)", TODOS, True),
    (r"medidas? protetivas?.{0,120}(defir|defer|indefir|indefer|conced|reconhec|mantenh|revog|prorrog)|(defir|defer|indefir|indefer|conced|mantenh|revog|prorrog)\w*.{0,120}medidas? protetivas?", "Medidas protetivas decididas — avaliar recurso em 5 dias (cabimento divergente: apelação × agravo)", 5, "CRITICA", "Lei 11.340/06 arts. 19-24 (Lei 14.550/23); recurso divergente — 5 dias conservador; sem suspensão no recesso (CPP 798-A II)", TODOS, False),
    (r"audiencia|sessao plenaria|plenario do juri", "Audiência/sessão designada — preparar", None, "ALTA", "CPP 399-400 / 411 / 453", TODOS, False),
    (r"medidas? protetivas?", "Medidas protetivas — ciência/cumprimento", None, "ALTA", "Lei 11.340/06 arts. 19-24", TODOS, False),
    (r"\bagravo\b", "Agravo — avaliar ou contraminutar (5 dias — regimental/execução)", 5, "CRITICA", "Lei 8.038/90 art. 39; RISTJ 258; LEP 197", TODOS, True),
    (r"prazo", "Providência determinada pelo juízo — ver texto", None, "ALTA", "prazo judicial (dias corridos — CPP 798)", TODOS, True),
    (r"intime-se (o|a) (reu|acusad[oa]|apenad[oa]|sentenciad[oa]) pessoalmente|intimacao pessoal do (reu|acusado|apenado)|expeca-se mandado de intimacao", "Intimação pessoal do réu determinada — acompanhar (prazo corre da intimação pessoal ou do defensor, o que ocorrer por último)", None, "MEDIA", "CPP 392; Súm. 710 STF", DEF, False),
    (r"retir\w* (o feito |os autos )?de pauta|retirado de pauta|cancel\w* a (audiencia|sessao)|audiencia cancelada|adiad[oa]", "Retirado de pauta / adiado — aguardar nova designação", None, "BAIXA", "—", TODOS, False),
    (r"indefiro|defiro|determino|autorizo|concedo|nao conheco|acolho|rejeito|decido|reconsidero|mantenho|torno sem efeito|declaro|reconheco|suspendo|converto|libero|expeca-se|oficie-se|proceda-se|homologo|designo|redesigno|arquive-se", "Decisão/despacho — ciência e acompanhamento", None, "MEDIA", "CPP 581 (se houver gravame — RESE)", TODOS, False),
    (r"\bedital\b", "Edital — apenas ciência (salvo se for parte)", None, "MEDIA", "CPP 361-365", TODOS, False),
    (r"lista de distribuicao|distribuid[oa]", "Distribuição — ciência", None, "BAIXA", "CPP 75", TODOS, False),
    (r"juntada de (peticao|documento|oficio|certidao|requerimento)|requerimento de habilitacao|retornem (os autos )?conclusos?|voltem conclusos?|conclusos? (ao|para)|mero expediente|junte-se|aguarde-se|ciencia|cientifique-se|certifique-se|cumpra-se|\bint\b|intimem-se|desarquiv|anote-se|publique-se|registre-se|nada a (prover|decidir)|aguardem|sobreste-se|remetam-se|encaminhe-se|traslad|cadastr", "Despacho de mero expediente / ciência", None, "BAIXA", "CPP 800", TODOS, False),
]
FORTES_TIPO_PENAL = {
    "pauta": ("Pauta de julgamento criminal — conferir data da sessão; sustentação oral/memoriais", None, "ALTA", "CPP 610 p.ú.; RITJ"),
    "citacao": ("Citação — resposta à acusação em 10 dias", 10, "CRITICA", "CPP 396/396-A"),
    "sentenca": ("Sentença criminal — apelação em 5 dias (ED em 2 dias)", 5, "CRITICA", "CPP 593 / 382"),
    "acordao": ("Acórdão criminal — ED em 2 dias; REsp/RE em 15 dias", 2, "CRITICA", "CPP 619; CPC 1.003 §5º e 1.029"),
    "edital": ("Edital — apenas ciência (salvo se for parte)", None, "MEDIA", "CPP 361-365"),
    "lista de distribuicao": ("Distribuição — ciência", None, "BAIXA", "CPP 75"),
}

_RE_FAV_DEFESA = re.compile(r"\babsolvo\b|absolvic|julgo improcedente a (pretensao punitiva|denuncia|acao penal|acusacao)|rejeito a denuncia|extin(go|ta) a punibilidade|declaro extinta a punibilidade|reconheco a prescricao|pronuncio a prescricao|\bimpronuncio\b|concedo (parcialmente )?a ordem|ordem (parcialmente )?concedida|procedencia do (presente )?writ|julgo procedente (o pedido|o writ|a ordem|o habeas)|concedo o habeas|revogo a prisao|relaxo a prisao|\b(defiro|concedo|homologo) (o pedido de |o |a |os |as )?(progressao|livramento|remicao|saida|liberdade|prisao domiciliar|beneficio|indulto|comutacao|remicao)")
_RE_DESFAV_DEFESA = re.compile(r"\bcondeno\b|julgo (parcialmente )?procedente (a|em parte a) (pretensao punitiva|denuncia|acao penal|acusacao)|fixo a pena|\bpronuncio\b(?! a prescricao)|denego a ordem|ordem denegada|decreto a prisao|mantenho a (prisao|custodia)|\bregrid|regress\w* (de|do) regime|(reconhec|homolog)\w* a (pratica de )?falta grave|\b(indefiro|nego|nao concedo|rejeito) (o pedido de |o |a |os |as )?(progressao|livramento|remicao|saida|liberdade|revogacao|relaxamento|prisao domiciliar|beneficio|indulto|comutacao|unificacao)")


def resultado_sentenca_penal(corpo_chave: str, lado: str) -> Optional[str]:
    """favoravel | desfavoravel | parcial | None — do ponto de vista do nosso LADO (defesa × acusação)."""
    fav, desf = bool(_RE_FAV_DEFESA.search(corpo_chave)), bool(_RE_DESFAV_DEFESA.search(corpo_chave))
    if re.search(r"parcialmente procedente|procedente em parte|absolv\w*.{0,80}\bcondeno\b|\bcondeno\b.{0,120}absolv", corpo_chave):
        return "parcial"
    if not fav and not desf:
        return None
    if fav and desf:
        return "parcial"
    if lado == "defesa":
        return "favoravel" if fav else "desfavoravel"
    if lado == "acusacao":
        return "desfavoravel" if fav else "favoravel"
    return None


_RE_PROVIDO = re.compile(r"(?<!nego )(?<!negar )(?<!negaram )(?<!negou )(?<!negado )(?<!negam )(?<!nega )(?<!negou-se )(?<!nao )(dou provimento|dar provimento|deu provimento|provimento ao recurso|provimento parcial|(deram|dao) provimento|conhecido e provido|parcialmente provido|provido em parte)|(?<!des)(?<!im)(?<!nao )\b(recurso|agravo|apelacao) provid[oa]s?\b")
_RE_DESPROVIDO = re.compile(r"nego provimento|negar(am|-lhe|-se)? provimento|negaram provimento|desprovido|desprovimento|improvido|nao conhec\w* (do|da) (recurso|agravo|apelacao|impetracao|writ|habeas)|recurso nao conhecido|nego seguimento|extingo o (agravo|recurso)|julgo prejudicado")


def resultado_recurso(corpo_chave: str, parte: dict) -> Optional[str]:
    """favoravel | desfavoravel | None para acórdão/decisão em recurso, conforme quem recorreu (nós ou a outra parte)."""
    prov, desp = bool(_RE_PROVIDO.search(corpo_chave)), bool(_RE_DESPROVIDO.search(corpo_chave))
    if prov == desp:
        return None
    rec = nos_recorremos(parte)
    if rec is None:
        return None
    if prov:
        return "favoravel" if rec else "desfavoravel"
    return "desfavoravel" if rec else "favoravel"


_RE_ACUSACAO_NOME = re.compile(r"ministerio publico|promotor|promotoria|parquet|procuradoria(-geral)? (de justica|da republica)|\b(mp|mpe|mpf|mpm)\b(?![^|]{0,40}\b(ltda|s/?a|sa|eireli|me|epp|cia|companhia)\b)")
_RE_ACUSACAO_PAPEL = re.compile(r"querel[ae]nte|assistente (de|da) acusacao|vitima|ofendid|representante|autor(a)?(?! do fato)")
_RE_DEFESA_PAPEL = re.compile(r"\breus?\b|\bre\b|acusad|denunciad|indiciad|investigad|reeducand|apenad|sentenciad|condenad|paciente|querelad|executad|autor(a)? do fato|representad|flagrantead|custodiad|averiguad|requerid")


def lado_penal(parte: dict, papel_cfg: str = "") -> str:
    """'defesa' | 'acusacao' | 'indeterminado' — de que lado da mesa estamos, independentemente do polo do recurso.
    Advogado privado é defesa, salvo se representa o MP/querelante/assistente/vítima."""
    nome = chave(parte.get("nome") or ""); papel = chave(parte.get("papel") or "")
    if _RE_ACUSACAO_NOME.search(nome) or _RE_ACUSACAO_NOME.search(papel):
        return "acusacao"
    if papel and _RE_ACUSACAO_PAPEL.search(papel) and not _RE_DEFESA_PAPEL.search(papel):
        return "acusacao"
    if papel and _RE_DEFESA_PAPEL.search(papel):
        return "defesa"
    if parte.get("polo") in ("ativo", "passivo") and (nome or papel):
        return "defesa"  # parte privada identificada em processo penal → defesa (impetrante, agravante, apelante…)
    p = chave(papel_cfg or "")
    return "defesa" if p == "defesa" else ("acusacao" if p in ("acusacao", "assistente") else "indeterminado")


def nos_recorremos(parte: dict) -> Optional[bool]:
    """True se o nosso papel é de recorrente (agravante, apelante, recorrente, embargante, impetrante); False se recorrido; None se não dá para saber."""
    papel = chave(parte.get("papel") or "")
    if re.search(r"agravante|apelante|recorrente|embargante|impetrante|requerente|agte|apte|recte", papel):
        return True
    if re.search(r"agravad|apelad|recorrid|embargad|impetrad|requerid|agd|apd|recd", papel):
        return False
    return None


def polo_por_papel_config(papel: str) -> Optional[str]:
    """prazos.papel da configuração → polo padrão quando o texto não permite identificar."""
    p = chave(papel or "")
    if p == "defesa":
        return "passivo"
    if p in ("acusacao", "assistente"):
        return "ativo"
    return None


# ----------------------------------------------------------------------------- cobertura SEEU (verificação empírica de 11/09/2026)
# datajud: quantos processos de "Execução da Pena" (classe 386) o tribunal reporta à DataJud e se atualiza (60 dias).
# djen: de 25 execuções com movimento recente na DataJud, quantas tiveram comunicação publicada no DJEN em 120 dias
#       ("sim" ≥ 8/25; "parcial" 3–7; "fraca" 1–2; "nao" 0 — forte indício de que o tribunal não publica as intimações do SEEU no DJEN).
COBERTURA_SEEU = {
    "TJSP": {"datajud": "boa (2,8 mi; 369 mil atualizados/60d)", "djen": "sim"}, "TJMG": {"datajud": "boa (563 mil; 147 mil/60d)", "djen": "sim"},
    "TJGO": {"datajud": "boa (58 mil; 10 mil/60d)", "djen": "sim"}, "TJPA": {"datajud": "boa (70 mil; 17 mil/60d)", "djen": "sim"},
    "TJDFT": {"datajud": "fraca (41 processos)", "djen": "sim"}, "TJAL": {"datajud": "parcial (7 mil; 43/60d)", "djen": "sim"},
    "TJPI": {"datajud": "boa (1,8 mil; todos/60d)", "djen": "sim"}, "TJBA": {"datajud": "parcial (2,6 mil; 377/60d)", "djen": "parcial"},
    "TJSC": {"datajud": "parcial (69 mil; 1,7 mil/60d)", "djen": "parcial"}, "TJRJ": {"datajud": "boa (6,5 mil; 3,7 mil/60d)", "djen": "parcial"},
    "TJRR": {"datajud": "boa (14,6 mil; todos/60d)", "djen": "parcial"}, "TJAM": {"datajud": "boa (16,7 mil; 14,4 mil/60d)", "djen": "parcial"},
    "TJTO": {"datajud": "boa (21 mil; 1,2 mil/60d)", "djen": "fraca"}, "TJCE": {"datajud": "parcial (2,8 mil; 92/60d)", "djen": "fraca"},
    "TJRO": {"datajud": "boa (62 mil; 5,7 mil/60d)", "djen": "fraca"}, "TJAC": {"datajud": "fraca (41 mil; 22/60d)", "djen": "fraca"},
    "TJMS": {"datajud": "fraca (36 mil; 190/60d)", "djen": "fraca"}, "TJRN": {"datajud": "fraca (1,4 mil; 1/60d)", "djen": "sem dados"},
    "TJPE": {"datajud": "fraca (8 mil; 29/60d)", "djen": "nao"}, "TJMT": {"datajud": "boa (37 mil; todos/60d)", "djen": "nao"},
    "TJSE": {"datajud": "boa (33 mil; 5 mil/60d)", "djen": "nao"}, "TJAP": {"datajud": "boa (1,8 mil; todos/60d)", "djen": "nao"},
    "TJPR": {"datajud": "nenhuma (não reporta a classe Execução da Pena)", "djen": "sem dados"}, "TJRS": {"datajud": "nenhuma (não reporta a classe Execução da Pena)", "djen": "sem dados"},
    "TJPB": {"datajud": "nenhuma (8 processos)", "djen": "sem dados"}, "TJMA": {"datajud": "nenhuma (1 processo)", "djen": "sem dados"},
    "TJES": {"datajud": "fraca (791; 0/60d)", "djen": "sem dados"},
    "TRF2": {"datajud": "boa (6,2 mil; 333/60d)", "djen": "sim"}, "TRF6": {"datajud": "parcial (643; 33/60d)", "djen": "sim"},
    "TRF5": {"datajud": "boa (440; 376/60d)", "djen": "fraca"}, "TRF3": {"datajud": "fraca (13 mil; 20/60d)", "djen": "nao"},
    "TRF1": {"datajud": "fraca (86; 2/60d)", "djen": "sem dados"}, "TRF4": {"datajud": "fraca (39 mil; 0/60d)", "djen": "sem dados"},
    "STM": {"datajud": "parcial (2,4 mil; 22/60d)", "djen": "sem dados"}, "TJMMG": {"datajud": "boa (650; todos/60d)", "djen": "sem dados"}, "TJMRS": {"datajud": "boa (241; todos/60d)", "djen": "sem dados"},
}


def aviso_cobertura_seeu(tribunais) -> list:
    """Avisos para os tribunais da carteira em que a verificação mostrou que as intimações do SEEU NÃO chegam pelo DJEN."""
    avisos = []
    for t in sorted({str(x).upper() for x in tribunais if x}):
        c = COBERTURA_SEEU.get(t)
        if c and c["djen"] == "nao":
            avisos.append(f"{t}: na verificação de 11/09/2026, nenhuma das 25 execuções penais (SEEU) com movimento recente teve intimação publicada no DJEN em 120 dias — as intimações do SEEU deste tribunal provavelmente NÃO chegam pelo Diário; confira o painel do SEEU (seeu.pje.jus.br) e o Domicílio Judicial Eletrônico. DataJud: {c['datajud']}.")
        elif c and c["djen"] in ("fraca", "parcial"):
            avisos.append(f"{t}: cobertura {c['djen']} das intimações do SEEU no DJEN (verificação de 11/09/2026); DataJud: {c['datajud']}. Mantenha a conferência no painel do SEEU para a execução penal.")
    return avisos
