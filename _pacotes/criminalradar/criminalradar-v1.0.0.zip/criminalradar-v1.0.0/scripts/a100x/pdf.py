"""Escritor de PDF mínimo, sem dependências: fontes-padrão Helvetica (WinAnsiEncoding), FlateDecode,
texto com quebra de linha por métricas reais, retângulos (com cantos arredondados), linhas e links.

Coordenadas: origem no topo esquerdo, em pontos (A4 = 595,28 × 841,89). `y` é o topo do elemento
(para texto, a linha de base).
"""
from __future__ import annotations

import re
import unicodedata
import zlib
from datetime import datetime
from typing import List, Optional, Sequence, Tuple

A4 = (595.28, 841.89)
Cor = Tuple[float, float, float]

# Larguras Helvetica / Helvetica-Bold para os caracteres 32..126 (AFM Adobe, por 1000 unidades)
_REG = [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556,
        278, 278, 584, 584, 584, 556, 1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667,
        611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556, 333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833,
        556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584]
_BOLD = [278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556,
         333, 333, 584, 584, 584, 611, 975, 722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778, 667, 778, 722, 667,
         611, 722, 667, 944, 667, 667, 611, 333, 278, 333, 584, 556, 333, 556, 611, 556, 611, 556, 333, 611, 611, 278, 278, 556, 278, 889,
         611, 611, 611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500, 389, 280, 389, 584]
_EXTRAS = {"ª": 370, "º": 365, "§": 556, "°": 400, "–": 556, "—": 1000, "•": 350, "…": 1000, "“": 333, "”": 333, "‘": 222,
           "’": 222, "€": 556, "«": 556, "»": 556, "·": 278, "®": 737, "©": 737, "™": 1000, "¿": 611, "¡": 333, "×": 584, "÷": 584}
_SUBST = {"→": "->", "←": "<-", "≥": ">=", "≤": "<=", "✓": "v", "✔": "v", "✗": "x", "☐": "[ ]", "■": "-", "▪": "-", "\u00a0": " ",
          "\u2009": " ", "\u202f": " ", "\u200b": "", "\ufeff": "", "＜": "<", "＞": ">"}
from .marca import M as _MARCA
PRODUTOR = f"{_MARCA['nome']} Radar (PDF nativo)"
_RE_URI_ESC = re.compile(r"[^A-Za-z0-9\-._~:/?#\[\]@!$&'()*+,;=%]")


def _base(c: str) -> str:
    d = unicodedata.normalize("NFKD", c)
    return d[0] if d else c


def largura_char(c: str, bold: bool = False) -> float:
    tab = _BOLD if bold else _REG
    o = ord(c)
    if 32 <= o <= 126:
        return tab[o - 32]
    if c in _EXTRAS:
        return _EXTRAS[c]
    b = _base(c)
    ob = ord(b) if b else 0
    if 32 <= ob <= 126:
        return tab[ob - 32]
    return 556


def largura_texto(s: str, tam: float, bold: bool = False) -> float:
    s = unicodedata.normalize("NFC", s or "")
    s = "".join(_SUBST.get(c, c) for c in s if not unicodedata.combining(c))
    return sum(largura_char(c, bold) for c in s) * tam / 1000.0


def quebrar(s: str, largura: float, tam: float, bold: bool = False) -> List[str]:
    """Quebra `s` em linhas que cabem em `largura` (respeita \\n; parte palavras enormes)."""
    linhas: List[str] = []
    for paragrafo in (s or "").split("\n"):
        palavras = paragrafo.split(" ")
        atual = ""
        for p in palavras:
            if not p:
                continue
            teste = (atual + " " + p).strip()
            if largura_texto(teste, tam, bold) <= largura:
                atual = teste
                continue
            if atual:
                linhas.append(atual)
            # palavra sozinha maior que a largura: quebra por caracteres
            while largura_texto(p, tam, bold) > largura and len(p) > 1:
                n = len(p)
                while n > 1 and largura_texto(p[:n], tam, bold) > largura:
                    n -= 1
                linhas.append(p[:n])
                p = p[n:]
            atual = p
        linhas.append(atual)
    return linhas or [""]


def _codificar(s: str) -> bytes:
    s = unicodedata.normalize("NFC", s or "")
    s = "".join(_SUBST.get(c, c) for c in s if not unicodedata.combining(c))
    b = s.encode("cp1252", "replace")
    return b.replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)").replace(b"\r", b"\\r").replace(b"\n", b"\\n")


def _texto_info(s: str) -> bytes:
    b = b"\xfe\xff" + (s or "").encode("utf-16-be")
    return b"(" + b.replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)") + b")"


def _rgb(c: Cor) -> bytes:
    return ("%.3f %.3f %.3f" % tuple(max(0.0, min(1.0, float(v))) for v in c)).encode()


def hexcor(h: str) -> Cor:
    h = h.lstrip("#")
    return (int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255)


class Pagina:
    def __init__(self):
        self.ops: List[bytes] = []
        self.links: List[Tuple[float, float, float, float, str]] = []  # x1,y1,x2,y2 em coord. PDF


class PDF:
    def __init__(self, titulo: str = "", autor: str = "", assunto: str = "", tamanho: Tuple[float, float] = A4):
        self.largura, self.altura = tamanho
        self.titulo, self.autor, self.assunto = titulo, autor, assunto
        self.paginas: List[Pagina] = []
        self.pag: Optional[Pagina] = None

    # --- páginas ---------------------------------------------------------
    def nova_pagina(self) -> Pagina:
        self.pag = Pagina()
        self.paginas.append(self.pag)
        return self.pag

    @property
    def numero_pagina(self) -> int:
        return len(self.paginas)

    def _op(self, b: bytes) -> None:
        if self.pag is None:
            self.nova_pagina()
        self.pag.ops.append(b)

    # --- texto ------------------------------------------------------------
    def texto(self, x: float, y: float, s: str, tam: float = 10, bold: bool = False, italico: bool = False, cor: Cor = (0, 0, 0)) -> float:
        fonte = b"F2" if bold else (b"F3" if italico else b"F1")
        self._op(b"BT /%s %.2f Tf %s rg %.2f %.2f Td (%s) Tj ET\n" % (fonte, tam, _rgb(cor), x, self.altura - y, _codificar(s)))
        return largura_texto(s, tam, bold)

    def texto_direita(self, x_dir: float, y: float, s: str, tam: float = 10, bold: bool = False, italico: bool = False, cor: Cor = (0, 0, 0)) -> None:
        self.texto(x_dir - largura_texto(s, tam, bold), y, s, tam, bold, italico, cor)

    def texto_centro(self, x_c: float, y: float, s: str, tam: float = 10, bold: bool = False, italico: bool = False, cor: Cor = (0, 0, 0)) -> None:
        self.texto(x_c - largura_texto(s, tam, bold) / 2, y, s, tam, bold, italico, cor)

    def paragrafo(self, x: float, y: float, s: str, largura: float, tam: float = 10, bold: bool = False, italico: bool = False,
                  cor: Cor = (0, 0, 0), entrelinha: float = 1.3, max_linhas: Optional[int] = None) -> float:
        """Escreve texto com quebra; devolve o y da linha de base seguinte."""
        linhas = quebrar(s, largura, tam, bold)
        if max_linhas and len(linhas) > max_linhas:
            linhas = linhas[:max_linhas]
            linhas[-1] = linhas[-1].rstrip(" ,;:.") + "…"
        for l in linhas:
            self.texto(x, y, l, tam, bold, italico, cor)
            y += tam * entrelinha
        return y

    # --- formas ------------------------------------------------------------
    def retangulo(self, x: float, y: float, w: float, h: float, preenchimento: Optional[Cor] = None, borda: Optional[Cor] = None,
                  espessura: float = 0.5, raio: float = 0.0) -> None:
        yp = self.altura - y - h
        modo = b"B" if (preenchimento and borda) else (b"f" if preenchimento else b"S")
        cab = b""
        if preenchimento:
            cab += _rgb(preenchimento) + b" rg "
        if borda:
            cab += _rgb(borda) + b" RG %.2f w " % espessura
        if raio <= 0:
            self._op(cab + b"%.2f %.2f %.2f %.2f re %s\n" % (x, yp, w, h, modo))
            return
        r = min(raio, w / 2, h / 2)
        k = 0.5523 * r
        x1, y1, x2, y2 = x, yp, x + w, yp + h
        caminho = (b"%.2f %.2f m " % (x1 + r, y1)
                   + b"%.2f %.2f l %.2f %.2f %.2f %.2f %.2f %.2f c " % (x2 - r, y1, x2 - r + k, y1, x2, y1 + r - k, x2, y1 + r)
                   + b"%.2f %.2f l %.2f %.2f %.2f %.2f %.2f %.2f c " % (x2, y2 - r, x2, y2 - r + k, x2 - r + k, y2, x2 - r, y2)
                   + b"%.2f %.2f l %.2f %.2f %.2f %.2f %.2f %.2f c " % (x1 + r, y2, x1 + r - k, y2, x1, y2 - r + k, x1, y2 - r)
                   + b"%.2f %.2f l %.2f %.2f %.2f %.2f %.2f %.2f c h " % (x1, y1 + r, x1, y1 + r - k, x1 + r - k, y1, x1 + r, y1))
        self._op(cab + caminho + modo + b"\n")

    def linha(self, x1: float, y1: float, x2: float, y2: float, cor: Cor = (0, 0, 0), espessura: float = 0.5) -> None:
        self._op(b"%s RG %.2f w %.2f %.2f m %.2f %.2f l S\n" % (_rgb(cor), espessura, x1, self.altura - y1, x2, self.altura - y2))

    def poligono(self, pontos: Sequence[Tuple[float, float]], preenchimento: Optional[Cor] = None, borda: Optional[Cor] = None, espessura: float = 0.5) -> None:
        if len(pontos) < 3:
            return
        cab = b""
        if preenchimento:
            cab += _rgb(preenchimento) + b" rg "
        if borda:
            cab += _rgb(borda) + b" RG %.2f w " % espessura
        modo = b"B" if (preenchimento and borda) else (b"f" if preenchimento else b"S")
        ops = b"%.2f %.2f m " % (pontos[0][0], self.altura - pontos[0][1])
        for (x, y) in pontos[1:]:
            ops += b"%.2f %.2f l " % (x, self.altura - y)
        self._op(cab + ops + b"h " + modo + b"\n")

    def seta(self, x1: float, y1: float, x2: float, y2: float, cor: Cor = (0, 0, 0), espessura: float = 0.8, cabeca: float = 4.0) -> None:
        """Linha com ponta de seta em (x2, y2)."""
        import math
        self.linha(x1, y1, x2, y2, cor, espessura)
        ang = math.atan2(y2 - y1, x2 - x1)
        p1 = (x2 - cabeca * math.cos(ang - 0.45), y2 - cabeca * math.sin(ang - 0.45))
        p2 = (x2 - cabeca * math.cos(ang + 0.45), y2 - cabeca * math.sin(ang + 0.45))
        self.poligono([(x2, y2), p1, p2], preenchimento=cor)

    def link(self, x: float, y: float, w: float, h: float, url: str) -> None:
        if self.pag is None:
            self.nova_pagina()
        from urllib.parse import quote
        url = quote(url, safe="-._~:/?#[]@!$&'()*+,;=%")
        self.pag.links.append((x, self.altura - y - h, x + w, self.altura - y, url))

    # --- saída -------------------------------------------------------------
    def bytes(self) -> bytes:
        objetos: List[bytes] = []

        def add(corpo: bytes) -> int:
            objetos.append(corpo)
            return len(objetos)

        n_pag = len(self.paginas)
        # reserva: 1 catálogo, 2 pages, 3-5 fontes, 6 info; páginas e conteúdos vêm depois
        add(b"<< /Type /Catalog /Pages 2 0 R >>")
        add(b"")  # placeholder /Pages
        add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")
        add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>")
        add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique /Encoding /WinAnsiEncoding >>")
        data = datetime.now().strftime("D:%Y%m%d%H%M%S")
        add(b"<< /Title " + _texto_info(self.titulo) + b" /Author " + _texto_info(self.autor) + b" /Subject " + _texto_info(self.assunto)
            + b" /Producer " + _texto_info(PRODUTOR) + b" /CreationDate (" + data.encode() + b") >>")
        kids = []
        for p in self.paginas:
            conteudo = zlib.compress(b"".join(p.ops))
            n_cont = add(b"<< /Length %d /Filter /FlateDecode >>\nstream\n" % len(conteudo) + conteudo + b"\nendstream")
            annots = b""
            if p.links:
                partes = []
                for (x1, y1, x2, y2, url) in p.links:
                    partes.append(b"<< /Type /Annot /Subtype /Link /Rect [%.2f %.2f %.2f %.2f] /Border [0 0 0] /A << /S /URI /URI (%s) >> >>"
                                  % (x1, y1, x2, y2, url.encode("ascii", "ignore").replace(b"(", b"\\(").replace(b")", b"\\)")))
                annots = b" /Annots [" + b" ".join(partes) + b"]"
            n_pag_obj = add(b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2f %.2f] /Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R >> >> /Contents %d 0 R%s >>"
                            % (self.largura, self.altura, n_cont, annots))
            kids.append(b"%d 0 R" % n_pag_obj)
        objetos[1] = b"<< /Type /Pages /Kids [" + b" ".join(kids) + b"] /Count %d >>" % n_pag

        saida = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
        offsets = []
        for i, corpo in enumerate(objetos, 1):
            offsets.append(len(saida))
            saida += b"%d 0 obj\n" % i + corpo + b"\nendobj\n"
        xref = len(saida)
        saida += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objetos) + 1)
        for o in offsets:
            saida += b"%010d 00000 n \n" % o
        saida += b"trailer\n<< /Size %d /Root 1 0 R /Info 6 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(objetos) + 1, xref)
        return bytes(saida)

    def salvar(self, caminho) -> None:
        with open(caminho, "wb") as f:
            f.write(self.bytes())
