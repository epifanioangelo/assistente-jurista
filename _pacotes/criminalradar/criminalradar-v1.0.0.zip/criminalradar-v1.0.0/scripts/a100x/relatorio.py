"""Orquestrador do Radar: coleta (DJEN + DataJud) → triagem → IA → PDF/HTML → e-mail → estado."""
from __future__ import annotations

import html as _html
import json
import re
import shutil
import sys
import time
import traceback
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import List, Optional, Tuple

from . import NOME, PRODUTO, ROTULO, VERSAO, classificar, cnj, config, datajud, djen, estado, ia, penal, prazos
from .marca import M as MARCA, skill as _skill
from .email_conector import ErroConector, copiar_para_drive, criar_doc_no_drive, enviar_por_conector, publicar_no_drive
from .email_envio import ErroEmail, enviar
from .http import ErroHTTP
from .pdf_radar import gerar_pdf
from .texto import chave as chave_txt, corrigir_texto_tribunal, plural, titulo_classe, truncar, uma_linha

DIAS_SEMANA = ["segunda-feira", "terça-feira", "quarta-feira", "quinta-feira", "sexta-feira", "sábado", "domingo"]
MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"]


def data_extenso(d: date) -> str:
    return f"{DIAS_SEMANA[d.weekday()]}, {d.day} de {MESES[d.month - 1]} de {d.year}"


class Log:
    """Log em arquivo mensal (logs/radar-AAAA-MM.log) e, se verbose, no stderr."""

    def __init__(self, verbose: bool = False, nome: str = "radar"):
        self.verbose = verbose
        self.linhas: List[str] = []
        try:
            pasta = config.pasta_logs()
            pasta.mkdir(parents=True, exist_ok=True)
            self.arquivo: Optional[Path] = pasta / f"{nome}-{date.today():%Y-%m}.log"
        except OSError:
            self.arquivo = None

    def __call__(self, msg: str) -> None:
        linha = f"{datetime.now():%Y-%m-%d %H:%M:%S} {msg}"
        self.linhas.append(linha)
        if self.arquivo:
            try:
                with open(self.arquivo, "a", encoding="utf-8") as f:
                    f.write(linha + "\n")
            except OSError:
                pass
        if self.verbose:
            print(linha, file=sys.stderr, flush=True)


# ------------------------------------------------------------------ coleta
def coletar_djen(cfg: dict, inicio: date, fim: date, log) -> Tuple[List[dict], List[dict], List[str]]:
    brutos: List[dict] = []
    consultas: List[dict] = []
    erros: List[str] = []
    tribunais = [t.upper() for t in (cfg.get("busca") or {}).get("tribunais") or []]

    def registrar(tipo, chave, fn):
        info: dict = {}
        try:
            r = fn(info)
            if tribunais:
                r = [x for x in r if (x.get("siglaTribunal") or "").upper() in tribunais]
            brutos.extend(r)
            consultas.append({"tipo": tipo, "chave": chave, "itens": len(r), "ok": True, "truncado": bool(info.get("truncado"))})
            log(f"  DJEN {tipo} {chave}: {len(r)} itens" + (" (TRUNCADO)" if info.get("truncado") else ""))
        except Exception as e:  # noqa: BLE001 — uma consulta ruim não pode derrubar as outras
            consultas.append({"tipo": tipo, "chave": chave, "itens": 0, "ok": False, "erro": f"{type(e).__name__}: {e}"})
            erros.append(f"DJEN {tipo} {chave}: {e}")
            log(f"  DJEN {tipo} {chave}: ERRO {type(e).__name__}: {e}")

    for o in cfg.get("oabs") or []:
        registrar("OAB", f"{o.get('numero')}/{str(o.get('uf', '')).upper()}", lambda info, o=o: djen.buscar_por_oab(o["numero"], o["uf"], inicio, fim, log=log, info=info))
    for p in cfg.get("processos") or []:
        registrar("processo", cnj.formatar(p.get("numero", "")), lambda info, p=p: djen.buscar_por_processo(p["numero"], inicio, fim, log=log, info=info))
    for pt in cfg.get("partes") or []:
        registrar("parte", pt.get("nome", ""), lambda info, pt=pt: djen.buscar_por_parte(pt["nome"], inicio, fim, pt.get("tribunal", ""), log=log, info=info))
    return brutos, consultas, erros


def coletar_datajud(cfg: dict, alvos: List[dict], log, hoje: date, paralelo: int = 4, max_falhas_seguidas: int = 6) -> Tuple[List[dict], List[str]]:
    """Consulta a DataJud em paralelo; se o serviço estiver fora (N falhas seguidas sem sucesso), interrompe e agrega um único aviso."""
    import threading
    from concurrent.futures import ThreadPoolExecutor
    chave = config.chave_datajud(cfg)
    cfg_and = cfg.get("andamento") or {}
    estado_srv = {"falhas": 0, "sucessos": 0, "aberto": False}
    trava = threading.Lock()

    def um(alvo):
        base = {"numero": cnj.formatar(alvo["numero"]) if cnj.normalizar(alvo["numero"]) else alvo["numero"], "encontrado": False, "erro": None,
                "apelido": alvo.get("apelido") or "", "cliente": alvo.get("cliente") or "", "origem": alvo.get("origem") or "cadastro", "tribunal": cnj.sigla_tribunal(cnj.normalizar(alvo["numero"]) or "")}
        with trava:
            if estado_srv["aberto"]:
                return {**base, "erro": "DataJud indisponível: consulta não realizada (serviço fora nesta execução)", "pulado": True}
        try:
            a = datajud.consultar(alvo["numero"], chave, log=None, hoje=hoje, cfg_andamento=cfg_and)
        except Exception as e:  # noqa: BLE001
            a = {**base, "erro": f"DataJud indisponível: {type(e).__name__}: {e}"}
        exec_dj = bool(a.get("encontrado") and re.search(r"execucao (da pena|provisoria|penal|de medidas|de pena de multa)|agravo (de|em) execucao", chave_txt(str(a.get("classe") or ""))))
        a.update({"apelido": base["apelido"], "cliente": base["cliente"], "origem": base["origem"], "execucao_penal": bool(alvo.get("execucao_penal")) or exec_dj, "seeu": alvo.get("seeu") or ("seeu" if exec_dj else "")})
        if a.get("execucao_penal") and not a.get("encontrado") and a.get("erro") and "não localizado" in a["erro"]:
            a["erro"] = "execução penal — não sincronizada na DataJud por este tribunal: consulte no SEEU (seeu.pje.jus.br)"
            a["link_consulta"] = "https://seeu.pje.jus.br/seeu/"
        with trava:
            if a.get("erro") and "indisponível" in a["erro"]:
                estado_srv["falhas"] += 1
                if estado_srv["sucessos"] == 0 and estado_srv["falhas"] >= max_falhas_seguidas:
                    estado_srv["aberto"] = True
            else:
                estado_srv["sucessos"] += 1
                estado_srv["falhas"] = 0
        return a

    with ThreadPoolExecutor(max_workers=max(1, paralelo)) as ex:
        saida = list(ex.map(um, alvos))
    erros = []
    indisponiveis = [a for a in saida if a.get("erro") and "indisponível" in a["erro"]]
    for a in saida:
        log(f"  DataJud {a['numero']}: {'ok — ' + (a.get('status') or '') if a.get('encontrado') else a.get('erro')}")
    if indisponiveis:
        if estado_srv["aberto"]:
            erros.append(f"DataJud indisponível nesta execução — {len(indisponiveis)} processos não consultados (serão tentados no próximo Radar)")
        else:
            for a in indisponiveis[:5]:
                erros.append(f"DataJud {a['numero']}: {a['erro']}")
            if len(indisponiveis) > 5:
                erros.append(f"DataJud: mais {len(indisponiveis) - 5} processos com falha de consulta")
    return saida, erros


# ------------------------------------------------------------------ modelo
def montar_modelo(cfg: dict, novas: List[dict], ja_vistas: int, andamentos: List[dict], fontes: dict, hoje: date,
                  inicio: date, fim: date, agora: datetime, erros: List[str]) -> dict:
    alerta_dias = int((cfg.get("prazos") or {}).get("alerta_dias_uteis") or 5)
    n_penal = n_seeu = n_exec = 0
    for it in novas:
        tr = it.get("triagem") or {}
        p = tr.get("prazo")
        # dias restantes: corridos no penal (CPP 798), úteis no cível — o nome do campo é histórico
        it["dias_uteis_restantes"] = prazos.dias_restantes(hoje, p) if p else None
        it["prazo_unidade"] = "corridos" if (p or {}).get("corrido") else "úteis"
        n_penal += tr.get("perfil") == "penal"
        n_seeu += bool(tr.get("seeu"))
        n_exec += bool(tr.get("execucao_penal"))
    novas.sort(key=lambda it: classificar.ordem_urgencia(it["triagem"]))
    prioridades = [it for it in novas if it["triagem"]["urgencia"] in ("CRITICA", "ALTA")][:8]
    criticas = sum(1 for it in novas if it["triagem"]["urgencia"] == "CRITICA")
    altas = sum(1 for it in novas if it["triagem"]["urgencia"] == "ALTA")
    prox = sum(1 for it in novas if it.get("dias_uteis_restantes") is not None and 0 <= it["dias_uteis_restantes"] <= alerta_dias)
    prox_corridos = sum(1 for it in novas if it.get("dias_uteis_restantes") is not None and 0 <= it["dias_uteis_restantes"] <= alerta_dias and it.get("prazo_unidade") == "corridos")
    vencidos = sum(1 for it in novas if it.get("dias_uteis_restantes") is not None and it["dias_uteis_restantes"] < 0)
    agenda = []
    for it in novas:
        for ev in (it.get("triagem") or {}).get("eventos") or []:
            try:
                dias = (date.fromisoformat(ev["data"]) - hoje).days
            except ValueError:
                continue
            if dias < -1:
                continue  # evento já passado (mais de 1 dia) — não polui a agenda
            agenda.append({**ev, "processo": it.get("processo"), "tribunal": it.get("tribunal"), "orgao": it.get("orgao"), "link_processo": it.get("link"),
                           "nossa_parte": ((it.get("triagem") or {}).get("nossa_parte") or {}).get("nome"), "em_dias": dias, "id": it.get("id")})
    agenda.sort(key=lambda e: (e["data"], e.get("hora") or "99"))
    eventos_7d = sum(1 for e in agenda if 0 <= e["em_dias"] <= 7)
    gargalos = [a for a in andamentos if (a.get("alerta") or {}).get("nivel") == "GARGALO"]
    atencao = [a for a in andamentos if (a.get("alerta") or {}).get("nivel") == "ATENCAO"]
    verificar = [a for a in andamentos if ((a.get("alerta") or {}).get("nivel") == "VERIFICAR" or not a.get("encontrado")) and not (a.get("execucao_penal") and not a.get("encontrado"))]
    dobro_sug = sum(1 for it in novas if it["triagem"].get("dobro_sugerido"))

    oabs = [f"{o.get('numero')}/{str(o.get('uf', '')).upper()}" for o in cfg.get("oabs") or []]
    n_proc = len(cfg.get("processos") or [])
    escopo = []
    if oabs:
        escopo.append("OAB " + ", ".join(oabs))
    if n_proc:
        escopo.append(plural(n_proc, "processo cadastrado", "processos cadastrados"))
    if cfg.get("partes"):
        escopo.append(plural(len(cfg["partes"]), "parte monitorada", "partes monitoradas"))
    escopo_curto = "  ·  ".join(escopo) or "sem critérios cadastrados"

    partes_frase = []
    if novas:
        detalhe = []
        if criticas:
            detalhe.append(plural(criticas, "crítica", "críticas"))
        if altas:
            detalhe.append(plural(altas, "alta", "altas"))
        partes_frase.append(f"O Radar encontrou {plural(len(novas), 'publicação nova', 'publicações novas')} para {escopo_curto.replace('  ·  ', ' e ')}" + (f" ({', '.join(detalhe)})" if detalhe else "") + ".")
    else:
        partes_frase.append(f"Nenhuma publicação nova para {escopo_curto.replace('  ·  ', ' e ')} nesta janela.")
    if prox:
        un_ = " úteis." if prox_corridos == 0 else (" corridos (CPP 798)." if prox_corridos == prox else f" ({prox - prox_corridos} em dias úteis, {prox_corridos} em dias corridos).")
        partes_frase.append(f"{plural(prox, 'prazo vence', 'prazos vencem')} nos próximos {alerta_dias} dias" + un_)
    if vencidos:
        partes_frase.append(f"ATENÇÃO: {plural(vencidos, 'prazo estimado já vencido', 'prazos estimados já vencidos')} — confira imediatamente.")
    if agenda:
        partes_frase.append(f"{plural(len(agenda), 'evento marcado', 'eventos marcados')} (audiências, perícias, sessões)" + (f", {eventos_7d} nos próximos 7 dias" if eventos_7d else "") + ".")
    if n_exec:
        partes_frase.append(f"{plural(n_exec, 'publicação de execução penal', 'publicações de execução penal')} (SEEU)" + (f", {n_seeu} com origem no SEEU confirmada no texto" if n_seeu and n_seeu != n_exec else "") + ".")
    elif n_penal:
        partes_frase.append(f"{plural(n_penal, 'publicação penal', 'publicações penais')} com prazos estimados em dias corridos (CPP 798).")
    seeu_sem_datajud = [a for a in andamentos if a.get("execucao_penal") and not a.get("encontrado")]
    if andamentos:
        ands_ok = sum(1 for a in andamentos if a.get("encontrado"))
        frase = f"{plural(ands_ok, 'processo consultado', 'processos consultados')} na DataJud"
        if gargalos:
            frase += f": {plural(len(gargalos), 'parado', 'parados')} há mais de {(cfg.get('andamento') or {}).get('dias_gargalo', 60)} dias"
        elif atencao:
            frase += f": {len(atencao)} em atenção (> {(cfg.get('andamento') or {}).get('dias_atencao', 30)} dias)"
        partes_frase.append(frase + ".")
    if erros:
        partes_frase.append("Houve falhas de coleta — veja os avisos ao final.")

    checklist = []
    if criticas or altas:
        checklist.append(f"Ler na íntegra as {plural(criticas + altas, 'publicação crítica/alta', 'publicações críticas/altas')} e confirmar cada prazo no sistema do tribunal.")
    if novas:
        checklist.append("Lançar todos os prazos no controle do escritório (agenda/CRM) com lembrete D-3 e D-1.")
    if dobro_sug:
        checklist.append(f"Verificar prazo em dobro em {plural(dobro_sug, 'publicação sinalizada', 'publicações sinalizadas')} (" + ("Defensoria Pública — LC 80/94; o MP não tem prazo em dobro no penal" if n_penal == len(novas) else "Fazenda, Defensoria, MP ou litisconsortes — CPC 180/183/186/229; no penal só a Defensoria — LC 80/94") + ").")
    if prox or vencidos:
        checklist.append("Conferir feriados locais/forenses nas datas estimadas — a data real pode ser posterior, nunca anterior.")
    if agenda:
        checklist.append(f"Lançar na agenda do escritório {plural(len(agenda), 'evento marcado', 'eventos marcados')} (audiência/perícia/sessão) com preparação D-3: partes, testemunhas, preposto, documentos, link de acesso.")
    if gargalos:
        checklist.append(f"Peticionar/cobrar andamento em {plural(len(gargalos), 'processo parado', 'processos parados')} (CPC 226) ou confirmar no sistema do tribunal.")
    if seeu_sem_datajud:
        checklist.append(f"Abrir no SEEU (seeu.pje.jus.br → Consulta pública / login) {plural(len(seeu_sem_datajud), 'processo de execução penal', 'processos de execução penal')} que a DataJud não sincroniza neste tribunal.")
    if verificar:
        checklist.append(f"Verificar manualmente {plural(len(verificar), 'processo', 'processos')} que a DataJud não localizou ou marcou como suspenso.")
    if n_penal and (cfg.get("prazos") or {}).get("intimacao_pessoal"):
        checklist.append("Intimação pessoal (CPP 370 §4º; LC 80/94): as datas estimadas pelo DJEN são apenas informativas — o prazo conta da intimação pessoal ou do acesso no Domicílio Judicial Eletrônico (Res. CNJ 455/22 art. 20). Confira o portal.")
    if n_penal:
        checklist.append("Prazos penais: réu preso, Lei Maria da Penha e urgências correm no recesso (CPP 798-A) — confira a situação prisional; réu preso exige intimação pessoal da sentença (CPP 392); Defensoria/MP/dativo contam da intimação pessoal.")
    checklist.append("Comunicar os clientes das decisões relevantes do dia.")
    if not novas and not andamentos:
        checklist.insert(0, "Confirmar no painel do DJEN (pje.jus.br) que não há publicações não indexadas.")

    ia_f = fontes.get("ia") or {}
    notas = [
        f"Publicações: DJEN — Comunica API do CNJ (comunicaapi.pje.jus.br), consultada em {agora:%d/%m/%Y %H:%M}. "
        + "Consultas: " + "; ".join(f"{c['tipo']} {c['chave']} ({c['itens']} itens{'' if c['ok'] else ' — FALHOU'})" for c in fontes.get("djen", {}).get("consultas", [])) + ".",
        "Andamento: DataJud — API Pública do CNJ (Res. CNJ 331/2020). Cada tribunal sincroniza a base com defasagem; a marca 'sync' indica a última atualização do processo. Processos em segredo de justiça, físicos e do STF não aparecem."
        + (" Execução penal (SEEU): a cobertura da DataJud varia por tribunal — quando o processo não é localizado, o andamento deve ser consultado no SEEU (seeu.pje.jus.br; autos só com login/certificado)." if n_exec or seeu_sem_datajud else ""),
        "Prazos: estimativa em dias úteis (CPC 219) — publicação no 1º dia útil após a disponibilização e início no dia útil seguinte (CPC 224 §§2º-3º e 231 VII; Lei 11.419/06 art. 4º §§3º-4º), descontando fins de semana, feriados nacionais, Sexta-feira Santa e o recesso de 20/12 a 20/01 (CPC 220). Feriados estaduais, municipais e forenses locais NÃO são descontados: a data real pode ser posterior, nunca anterior. "
        + ("Prazo em dobro APLICADO a todos os prazos (" + ((cfg.get("prazos") or {}).get("motivo_dobro") or "configuração do escritório") + ")." if (cfg.get("prazos") or {}).get("dobro") else "Prazo em dobro (CPC 180/183/186/229) não aplicado; casos suspeitos vêm sinalizados."),
    ]
    if n_penal or MARCA.get("perfil") == "criminal":
        tribs_carteira = {f"TJ{str(o.get('uf', '')).upper()}" for o in (cfg.get("oabs") or []) if o.get("uf")} | {it.get("tribunal") for it in novas if (it.get("triagem") or {}).get("execucao_penal")} | {a.get("tribunal") for a in andamentos if a.get("execucao_penal")}
        for av in penal.aviso_cobertura_seeu(tribs_carteira):
            notas.append("SEEU — " + av)
    if n_penal:
        notas.append(f"Prazos PENAIS ({n_penal} de {len(novas)} publicações): estimativa em DIAS CORRIDOS (CPP 798) — publicação no 1º dia útil após a disponibilização e início no dia útil seguinte (Lei 11.419/06 art. 4º §§3º-4º; Súm. 310 STF); vencimento em sábado, domingo ou feriado prorroga-se ao 1º dia útil (CPP 798 §3º; Lei 1.408/51 art. 3º). O recesso de 20/12 a 20/01 SUSPENDE o prazo penal (CPP 798-A, Lei 14.365/22), salvo réu preso, Lei Maria da Penha e medidas urgentes — nesses casos o Radar não suspende e sinaliza. Feriados locais e portarias do tribunal NÃO são descontados: a data real pode ser posterior, nunca anterior. Prazo em dobro no penal só para a Defensoria Pública (LC 80/94) — o Ministério Público não o tem; quem tem intimação pessoal (MP, Defensoria, defensor dativo, núcleo de prática jurídica — CPP 370 §4º; LC 80) conta o prazo da intimação pessoal/Domicílio Eletrônico, e a publicação no DJEN é apenas informativa. Intimações do SEEU (execução penal) chegam pelo DJEN (integração CNJ desde 2021) e são triadas como as demais; a leitura dos autos do SEEU exige login.")
    notas += [
        "Triagem: o Radar identifica a NOSSA parte e o polo (pelo rótulo processual junto à OAB no cabeçalho, pela parte única da comunicação ou por clientes/adversários habituais aprendidos), isola o corpo do ato e só conta prazos dirigidos à nossa parte — prazos da parte contrária e ordens condicionadas a evento futuro ficam sinalizados, não contados. Urgência por regras determinísticas (tipo do ato + prazo escrito no texto); CANCELADA = comunicação cancelada pelo tribunal.",
        (f"Resumos e ações em linguagem clara gerados por IA (Claude, modelo {ia_f.get('modelo')}) a partir do texto oficial — {ia_f.get('resumidas', 0)} de {len(novas)} publicações. Sempre confira o texto integral."
         if ia_f.get("resumidas") else "Resumo por IA " + ("desativado" if not ia_f.get("ativa") else "indisponível nesta execução") + " — os resumos exibidos são trechos do texto oficial."),
    ]
    for e in erros:
        notas.append(f"AVISO — {e}. A lista pode estar incompleta; o Radar tentará novamente na próxima execução.")
    if fontes.get("djen", {}).get("truncado"):
        notas.append("AVISO — a consulta ao DJEN foi truncada (muitos itens); reduza a janela ou filtre tribunais.")
    notas.append(f"{NOME} · {PRODUTO} v{VERSAO} — gerado automaticamente. Não substitui a leitura integral das intimações nem o controle de prazos do escritório (EAOAB art. 32).")

    return {
        "versao": VERSAO,
        "data": hoje.isoformat(),
        "data_br": hoje.strftime("%d/%m/%Y"),
        "data_extenso": data_extenso(hoje),
        "hora_geracao": agora.strftime("%H:%M"),
        "gerado_em": agora.strftime("%d/%m/%Y %H:%M"),
        "escritorio": cfg.get("escritorio") or {},
        "oabs": oabs,
        "escopo_curto": escopo_curto,
        "janela": {"inicio": inicio.isoformat(), "fim": fim.isoformat()},
        "janela_br": f"{inicio:%d/%m} a {fim:%d/%m/%Y}",
        "kpis": {"novas": len(novas), "criticas": criticas, "altas": altas, "prazos_proximos": prox, "vencidos": vencidos,
                 "gargalos": len(gargalos), "atencao": len(atencao), "processos_consultados": len(andamentos), "alerta_dias": alerta_dias, "dobro_sugerido": dobro_sug,
                 "eventos": len(agenda), "eventos_7d": eventos_7d, "penal_total": n_penal, "execucao_penal": n_exec, "seeu": n_seeu},
        "agenda": agenda,
        "linha_resumo": " ".join(partes_frase),
        "prioridades": prioridades,
        "publicacoes": novas,
        "ja_vistas": ja_vistas,
        "andamentos": sorted(andamentos, key=lambda a: ({"GARGALO": 0, "ATENCAO": 1, "VERIFICAR": 2, "NORMAL": 3}.get((a.get("alerta") or {}).get("nivel", "VERIFICAR"), 2), -(a.get("dias_parado") or 0))),
        "fontes": fontes,
        "erros": erros,
        "checklist": checklist,
        "notas": notas,
    }


# ------------------------------------------------------------------ e-mail
def caminho_exibicao(p) -> str:
    """Caminho do PDF como aparece no e-mail: '~/…' em vez de '/Users/<nome>/…' (o e-mail vai a todos os destinatários)."""
    try:
        from pathlib import Path as _P
        p = _P(str(p)); home = _P.home()
        return "~/" + str(p.relative_to(home)) if str(p).startswith(str(home) + "/") else str(p)
    except Exception:  # noqa: BLE001
        return str(p)


def encarte_ativo(rel: dict) -> bool:
    """relatorios.encarte (novo) ou relatorios.encarte_acelerador (nome antigo) — ambos aceitos."""
    if "encarte" in rel:
        return bool(rel.get("encarte"))
    return bool(rel.get("encarte_acelerador", True))


def assunto_email(m: dict) -> str:
    k = m["kpis"]
    if k["novas"]:
        det = f" ({k['criticas']} críticas)" if k["criticas"] else ""
        corpo = f"{plural(k['novas'], 'publicação nova', 'publicações novas')}{det}"
    else:
        corpo = "sem publicações novas"
    if k["gargalos"]:
        corpo += f" · {plural(k['gargalos'], 'processo parado', 'processos parados')}"
    pref = "[ATENÇÃO] " if m.get("erros") else ""
    return f"{pref}{ROTULO} · {m['data_br']} · {corpo}"


def _e(s) -> str:
    return _html.escape(str(s or ""), quote=True)


_CORP = MARCA["cores"]["primaria"]  # cor primária da marca nos títulos do e-mail


def html_email(m: dict) -> str:
    k = m["kpis"]
    cor = {"CRITICA": "#C62828", "ALTA": "#E65100", "MEDIA": "#B8860B", "BAIXA": "#2E7D32", "CANCELADA": "#757575"}
    rot = {"CRITICA": "CRÍTICA", "ALTA": "ALTA", "MEDIA": "MÉDIA", "BAIXA": "BAIXA", "CANCELADA": "CANCELADA"}

    def kpi(rotulo, valor, c):
        return (f'<td style="padding:0 4px"><table role="presentation" width="100%" cellspacing="0" cellpadding="0" bgcolor="#F3F5F9" style="background-color:#F3F5F9;border-radius:8px;border-left:4px solid {c}">'
                f'<tr><td style="padding:10px 12px;font-family:Helvetica,Arial,sans-serif"><div style="font-size:10px;color:#5F6B7A;font-weight:bold;letter-spacing:.4px">{_e(rotulo)}</div>'
                f'<div style="font-size:24px;color:{c};font-weight:bold;line-height:1.2">{_e(valor)}</div></td></tr></table></td>')

    linhas = []
    for n, it in enumerate(m["prioridades"], 1):
        tr = it["triagem"]
        p = tr.get("prazo")
        ia_ = it.get("ia") or {}
        acao = ia_.get("acao") or tr["ato"]
        resumo = ia_.get("resumo") or truncar(tr.get("corpo_resumo") or uma_linha(it.get("texto") or ""), 260)
        restam = it.get("dias_uteis_restantes")
        if p:
            un = "corridos" if p.get("corrido") else "úteis"
            prazo_txt = f"{prazos.formatar_br(p['fim'])} (estimado, {p['dias']} dias {un}" + (", em dobro" if p.get("dobro") else "") + (f", restam {restam} dias {un}" if restam is not None and restam >= 0 else (", VENCIDO?" if restam is not None else "")) + ")"
        elif tr.get("prazo_outra_parte"):
            prazo_txt = f"sem prazo para a nossa parte (o texto fixa {tr['prazo_outra_parte']} dias para a parte contrária)"
        elif tr.get("prazo_futuro"):
            prazo_txt = f"sem prazo corrente ({tr['prazo_futuro']} dias condicionados a evento futuro)"
        else:
            prazo_txt = "sem prazo identificado"
        np_ = tr.get("nossa_parte") or {}
        parte_html = f' · <span style="color:#5F6B7A">nossa parte: {_e(truncar(np_.get("nome") or "?", 40))} ({_e(np_.get("polo"))})</span>' if np_.get("polo") in ("ativo", "passivo") else ""
        proc = _e(it.get("processo") or "(sem número)")
        if it.get("link"):
            proc = f'<a href="{_e(it["link"])}" style="color:{_CORP};text-decoration:none">{proc}</a>'
        linhas.append(
            f'<tr><td style="padding:12px 0;border-bottom:1px solid #E6EAF0;font-family:Helvetica,Arial,sans-serif;font-size:13px;color:#111418">'
            f'<span bgcolor="{cor.get(tr["urgencia"], "#B8860B")}" style="display:inline-block;background-color:{cor.get(tr["urgencia"], "#B8860B")};color:#fff;font-size:10px;font-weight:bold;padding:2px 7px;border-radius:4px;margin-right:6px">{rot.get(tr["urgencia"], tr["urgencia"])}</span>'
            f'<strong>{proc}</strong> <span style="color:#5F6B7A;font-size:11px">· {_e(it.get("tribunal"))} · {_e(prazos.formatar_br(it["data"]))}</span>'
            f'<div style="color:#5F6B7A;font-size:11px;margin-top:2px">{_e(truncar(corrigir_texto_tribunal(it.get("orgao", "")), 90))} · {_e(titulo_classe(it.get("classe", "")))}{parte_html}</div>'
            f'<div style="margin-top:5px"><strong style="color:{_CORP}">Ação:</strong> {_e(acao)}</div>'
            f'<div><strong style="color:{_CORP}">Prazo:</strong> <span style="color:{"#C62828" if (restam is not None and restam <= k["alerta_dias"]) else "#111418"}">{_e(prazo_txt)}</span></div>'
            f'<div style="margin-top:4px;color:#333">{_e(resumo)}</div></td></tr>')
    if not linhas:
        linhas.append('<tr><td style="padding:10px 0;font-family:Helvetica,Arial,sans-serif;font-size:13px;color:#5F6B7A;font-style:italic">Nenhuma publicação crítica ou alta nesta janela.</td></tr>')

    bloco_agenda = ""
    if m.get("agenda"):
        its = []
        for ev in m["agenda"][:12]:
            quando = prazos.formatar_br(ev["data"]) + (f" às {ev['hora']}" if ev.get("hora") else "")
            em = "HOJE" if ev["em_dias"] == 0 else ("amanhã" if ev["em_dias"] == 1 else (f"em {ev['em_dias']} dias" if ev["em_dias"] > 1 else "ontem"))
            cor_ev = "#C62828" if 0 <= ev["em_dias"] <= 3 else ("#E65100" if ev["em_dias"] <= 7 else _CORP)
            mod = f" · {_e(ev['modalidade'])}" if ev.get("modalidade") else ""
            lk = f' · <a href="{_e(ev["link"])}" style="color:#2E6BFF">acessar</a>' if ev.get("link") else ""
            its.append(f'<li style="margin:5px 0"><strong style="color:{cor_ev}">{_e(quando)}</strong> <span style="color:#5F6B7A">({_e(em)})</span> — {_e(ev["tipo"])}{mod} · <strong>{_e(ev.get("processo") or "")}</strong> {_e(ev.get("tribunal") or "")}{lk}<div style="color:#5F6B7A;font-size:11px">{_e(truncar(ev.get("orgao") or "", 80))}</div></li>')
        bloco_agenda = (f'<h3 style="font-family:Helvetica,Arial,sans-serif;color:{_CORP};font-size:15px;margin:22px 0 6px">Agenda: audiências, perícias e sessões ({len(m["agenda"])})</h3>'
                        f'<ul style="font-family:Helvetica,Arial,sans-serif;font-size:13px;color:#111418;padding-left:18px;margin:0">{"".join(its)}</ul>')
    alertas = [a for a in m["andamentos"] if (a.get("alerta") or {}).get("nivel") in ("GARGALO", "ATENCAO")]
    bloco_and = ""
    if alertas:
        its = "".join(f'<li style="margin:4px 0"><strong>{_e(a["numero"])}</strong> — {_e(a.get("status"))}: {_e((a.get("alerta") or {}).get("mensagem"))}</li>' for a in alertas[:10])
        bloco_and = (f'<h3 style="font-family:Helvetica,Arial,sans-serif;color:{_CORP};font-size:15px;margin:22px 0 6px">Processos que pedem atenção (DataJud)</h3>'
                     f'<ul style="font-family:Helvetica,Arial,sans-serif;font-size:13px;color:#111418;padding-left:18px;margin:0">{its}</ul>')
    bloco_erros = ""
    if m.get("erros"):
        bloco_erros = ('<div style="margin-top:18px;padding:10px 12px;background-color:#FFF4E5;border-left:4px solid #E65100;font-family:Helvetica,Arial,sans-serif;font-size:12px;color:#5A3300">'
                       + "<strong>Avisos de coleta:</strong><br>" + "<br>".join(_e(e) for e in m["erros"]) + "</div>")

    CORP, CORCL = MARCA["cores"]["primaria"], MARCA["cores"]["clara"]
    return f"""<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><title>{_e(assunto_email(m))}</title></head>
<body bgcolor="#EEF1F5" style="margin:0;padding:0;background-color:#EEF1F5">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" bgcolor="#EEF1F5" style="background-color:#EEF1F5"><tr><td align="center" style="padding:20px 10px">
<table role="presentation" width="640" cellspacing="0" cellpadding="0" bgcolor="#ffffff" style="max-width:640px;width:100%;background-color:#fff;border-radius:10px;overflow:hidden">
<tr><td bgcolor="{CORP}" style="background-color:{CORP};padding:22px 26px;font-family:Helvetica,Arial,sans-serif">
  <div style="color:#fff;font-size:20px;font-weight:bold;letter-spacing:.5px">{_e(MARCA["cabecalho"])}</div>
  <div style="color:{CORCL};font-size:11px;margin-top:2px;letter-spacing:.6px">{_e(MARCA["subtitulo"])}</div>
  <div style="color:#fff;font-size:14px;margin-top:12px;font-weight:bold">{_e(m["data_extenso"].capitalize())}</div>
  <div style="color:{CORCL};font-size:12px;margin-top:2px">{_e(m["escopo_curto"])}</div>
</td></tr>
<tr><td style="padding:22px 26px 6px;font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:1.5;color:#111418">{_e(m["linha_resumo"])}</td></tr>
<tr><td style="padding:10px 22px 4px"><table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr>
{kpi("PUBLICAÇÕES NOVAS", k["novas"], CORP)}{kpi("CRÍTICAS", k["criticas"], "#C62828" if k["criticas"] else "#2E7D32")}{kpi(f"PRAZOS ≤ {k['alerta_dias']} DIAS" + ("" if k.get("penal_total") and k["penal_total"] != k["novas"] else (" CORRIDOS" if k.get("penal_total") else " ÚTEIS")), k["prazos_proximos"], "#E65100" if k["prazos_proximos"] else "#2E7D32")}{kpi("PROCESSOS PARADOS", k["gargalos"], "#C62828" if k["gargalos"] else "#2E7D32")}
</tr></table></td></tr>
<tr><td style="padding:14px 26px 6px">
  <h3 style="font-family:Helvetica,Arial,sans-serif;color:{CORP};font-size:15px;margin:8px 0 4px">Prioridades do dia</h3>
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0">{"".join(linhas)}</table>
  {bloco_agenda}{bloco_and}{bloco_erros}
</td></tr>
<tr><td style="padding:18px 26px 24px;font-family:Helvetica,Arial,sans-serif;font-size:13px;color:#111418">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr><td bgcolor="#F3F5F9" style="padding:12px 14px;background-color:#F3F5F9;border-radius:8px"><strong>O PDF completo está em anexo</strong> — com todas as {k["novas"]} publicações classificadas, o andamento de {k["processos_consultados"]} processos, o checklist do dia e a metodologia de contagem dos prazos.</td></tr></table>
  <p style="font-size:11px;color:#5F6B7A;line-height:1.5;margin:16px 0 0">Prazos são estimativas — dias úteis no cível (CPC 219/224/231), dias corridos no penal (CPP 798) — sem feriados locais: a data real pode ser posterior, nunca anterior. Este e-mail não substitui a leitura integral das intimações nem o controle de prazos do escritório.<br>
  {_e(NOME)} · {_e(PRODUTO)} v{_e(VERSAO)} · gerado automaticamente às {_e(m["hora_geracao"])}. Para ajustar o monitoramento, use <code>{_e(_skill("configurar"))}</code> no Claude Code.</p>
  <table role="presentation" cellspacing="0" cellpadding="0" style="margin-top:14px"><tr><td bgcolor="#25D366" style="background-color:#25D366;border-radius:22px;padding:10px 18px;font-family:Helvetica,Arial,sans-serif;font-size:13px;font-weight:bold"><a href="{_e(MARCA["whatsapp_url"])}" style="color:#fff;text-decoration:none">{_e(MARCA["cta_email"])} · WhatsApp {_e(MARCA["whatsapp_fmt"])}</a></td></tr></table>
</td></tr>
</table></td></tr></table></body></html>"""


def texto_email(m: dict) -> str:
    k = m["kpis"]
    out = [f"{NOME} — {PRODUTO} — {m['data_extenso']}", m["escopo_curto"], "", m["linha_resumo"], "",
           f"Publicações novas: {k['novas']} | Críticas: {k['criticas']} | Prazos em até {k['alerta_dias']} dias: {k['prazos_proximos']} | Processos parados: {k['gargalos']}", "", "PRIORIDADES DO DIA"]
    for n, it in enumerate(m["prioridades"], 1):
        tr = it["triagem"]
        p = tr.get("prazo")
        ia_ = it.get("ia") or {}
        out.append(f"{n}. [{tr['urgencia']}] {it.get('processo')} — {it.get('tribunal')} — {prazos.formatar_br(it['data'])}")
        out.append(f"   Ação: {ia_.get('acao') or tr['ato']}")
        out.append(f"   Prazo: {prazos.formatar_br(p['fim']) + ' (estimado)' if p else 'sem prazo identificado'}")
        out.append(f"   {ia_.get('resumo') or truncar(tr.get('corpo_resumo') or uma_linha(it.get('texto') or ''), 200)}")
    if not m["prioridades"]:
        out.append("Nenhuma publicação crítica ou alta.")
    if m.get("agenda"):
        out.append("")
        out.append("AGENDA (audiências, perícias, sessões)")
        for ev in m["agenda"][:12]:
            out.append(f"- {prazos.formatar_br(ev['data'])}{' às ' + ev['hora'] if ev.get('hora') else ''} — {ev['tipo']}{' · ' + ev['modalidade'] if ev.get('modalidade') else ''} — {ev.get('processo')} {ev.get('tribunal')}{' — ' + ev['link'] if ev.get('link') else ''}")
    for e in m.get("erros") or []:
        out.append(f"AVISO: {e}")
    out += ["", "O PDF completo está em anexo.", "Prazos são estimativas (dias úteis no cível, corridos no penal; sem feriados locais). Não substitui a leitura integral das intimações."]
    return "\n".join(out)


# ------------------------------------------------------------------ execução
def _limpar_antigos(cfg: dict, log) -> None:
    manter = int((cfg.get("relatorios") or {}).get("manter_dias") or 0)
    if manter <= 0:
        return
    limite = (date.today() - timedelta(days=manter)).isoformat()
    raiz = config.pasta_relatorios(cfg)
    if not raiz.exists():
        return
    for ano in raiz.iterdir():
        if not ano.is_dir() or not ano.name.isdigit():
            continue
        for dia in ano.iterdir():
            if dia.is_dir() and len(dia.name) == 10 and dia.name < limite:
                shutil.rmtree(dia, ignore_errors=True)
                log(f"  relatórios antigos removidos: {dia}")


def rodar(cfg: dict, opts: dict, log) -> dict:
    t0 = time.time()
    agora = datetime.now()
    hoje: date = opts.get("hoje") or agora.date()
    resumo: dict = {"ok": False, "quando": agora.isoformat(timespec="seconds"), "agendado": bool(opts.get("agendado")), "erros": []}
    problemas = config.validar(cfg)
    if not cfg.get("oabs") and not cfg.get("processos") and not cfg.get("partes"):
        raise RuntimeError("Nada para monitorar: cadastre uma OAB (`oab add`), um processo (`processos add`) ou uma parte.")
    invalidos = [p for p in problemas if p.startswith(("OAB inválida", "Processo inválido", "Parte inválida"))]
    if invalidos:
        raise RuntimeError("Cadastro inválido — corrija antes de rodar: " + " | ".join(invalidos))
    if not opts.get("sem_email"):
        graves = [p for p in problemas if "e-mail" in p.lower() or "smtp" in p.lower() or "destinat" in p.lower()]
        if graves:
            log("  aviso: e-mail não configurado — o Radar será gerado sem envio: " + " | ".join(graves))
            opts["sem_email"] = True
            resumo["erros"].append("E-mail não configurado: " + " | ".join(graves))

    est = estado.carregar()
    primeira = not est.get("ultimo_ok")
    busca = cfg.get("busca") or {}
    dias = int(opts.get("dias") or (busca.get("primeira_vez_dias") if primeira else busca.get("dias_retroativos")) or 3)
    janela_ampliada = ""
    if not opts.get("dias") and not primeira:
        # cobre o intervalo desde a última execução OK (Mac desligado, férias…), com teto de 30 dias
        try:
            ultimo_ok = datetime.fromisoformat(est["ultimo_ok"]).date()
            lacuna = (hoje - ultimo_ok).days + 1
            if lacuna > dias:
                dias = min(lacuna, 30)
                janela_ampliada = f" — janela ampliada para cobrir {lacuna} dias desde a última execução OK ({ultimo_ok:%d/%m})"
        except (KeyError, ValueError, TypeError):
            pass
    inicio, fim = hoje - timedelta(days=dias), hoje
    log(f"{ROTULO} v{VERSAO} — {hoje:%d/%m/%Y} — janela {inicio} a {fim} ({'primeira execução' if primeira else f'{dias} dias'}){janela_ampliada}")
    if janela_ampliada:
        resumo["erros"].append("Janela de busca ampliada" + janela_ampliada.split(" — janela ampliada")[1])

    with estado.Lock():
        # 1. DJEN
        brutos, consultas, erros = coletar_djen(cfg, inicio, fim, log)
        itens = [djen.normalizar_item(x) for x in djen.deduplicar(brutos)]
        if busca.get("ignorar_editais"):
            itens = [i for i in itens if i.get("meio") != "E"]
        if opts.get("tudo"):
            novas, antigas = itens, []
        else:
            novas, antigas = estado.filtrar_novas(est, itens)
        log(f"  DJEN: {len(itens)} publicações na janela, {len(novas)} novas, {len(antigas)} já relatadas")
        fontes = {"djen": {"ok": any(c["ok"] for c in consultas) or not consultas, "consultas": consultas, "total_janela": len(itens), "truncado": any(c.get("truncado") for c in consultas)},
                  "datajud": {"ok": False, "consultados": 0, "nao_encontrados": 0}, "ia": {"ativa": bool((cfg.get("ia") or {}).get("ativa")) and not opts.get("sem_ia"), "resumidas": 0, "modelo": (cfg.get("ia") or {}).get("modelo")}}

        # 2. triagem determinística (ciente da nossa parte/polo)
        oabs = [(str(o.get("numero")), str(o.get("uf", "")).upper()) for o in cfg.get("oabs") or []]
        clientes = {c for o in cfg.get("oabs") or [] for c in (o.get("clientes") or [])} | set((est.get("clientes_aprendidos") or {}).keys())
        cl_novos, adv_novos = classificar.aprender_partes(itens, oabs)
        ca, aa = est.setdefault("clientes_aprendidos", {}), est.setdefault("adversarios_aprendidos", {})
        for n, k in cl_novos.items():
            ca[n] = ca.get(n, 0) + k
        for n, k in adv_novos.items():
            aa[n] = aa.get(n, 0) + k
        clientes |= set(cl_novos)
        adversarios = {c for o in cfg.get("oabs") or [] for c in (o.get("adversarios") or [])} | {n for n, k in aa.items() if k >= 2}
        for it in novas:
            it["triagem"] = classificar.classificar(it, cfg.get("prazos") or {}, hoje, oabs, clientes, adversarios)

        # 3. IA (opcional)
        if fontes["ia"]["ativa"] and novas:
            log(f"  IA: resumindo {len(novas)} publicações…")
            res = ia.resumir(novas, cfg, log=log)
            dobro = bool((cfg.get("prazos") or {}).get("dobro"))
            for it in novas:
                r = res.get(int(it["id"])) if it.get("id") is not None else None
                it["ia"] = r
                it["triagem"] = classificar.combinar_ia(it["triagem"], r, it["data"], dobro)
            fontes["ia"]["resumidas"] = sum(1 for it in novas if it.get("ia"))

        # 4. DataJud
        andamentos: List[dict] = []
        if busca.get("consultar_datajud", True) and not opts.get("sem_datajud"):
            flags_pub = {}
            for it in novas:
                tr_ = it.get("triagem") or {}
                if it.get("processo_digits") and tr_.get("execucao_penal"):
                    flags_pub[it["processo_digits"]] = tr_.get("seeu") or "execucao"
            alvos = [{"numero": p["numero"], "apelido": p.get("apelido"), "cliente": p.get("cliente"), "origem": "cadastro",
                      "execucao_penal": cnj.normalizar(p["numero"]) in flags_pub, "seeu": flags_pub.get(cnj.normalizar(p["numero"]), "")}
                     for p in cfg.get("processos") or [] if cnj.normalizar(p.get("numero", ""))]
            if busca.get("datajud_processos_das_publicacoes", True):
                vistos = {cnj.normalizar(a["numero"]) for a in alvos}
                for it in novas:
                    d = it.get("processo_digits")
                    if d and d not in vistos:
                        vistos.add(d)
                        tr_ = it.get("triagem") or {}
                        alvos.append({"numero": d, "apelido": "", "origem": "publicação", "execucao_penal": bool(tr_.get("execucao_penal")), "seeu": tr_.get("seeu") or ""})
            limite = int(busca.get("max_processos_datajud") or 120)
            if len(alvos) > limite:
                log(f"  DataJud: limitando a {limite} de {len(alvos)} processos")
                erros.append(f"DataJud: {len(alvos) - limite} processos não consultados (limite {limite} por execução)")
                alvos = alvos[:limite]
            if alvos:
                log(f"  DataJud: consultando {len(alvos)} processos…")
                andamentos, erros_dj = coletar_datajud(cfg, alvos, log, hoje)
                erros.extend(erros_dj)
                fontes["datajud"] = {"ok": any(a.get("encontrado") for a in andamentos) or not erros_dj, "consultados": len(andamentos),
                                     "nao_encontrados": sum(1 for a in andamentos if not a.get("encontrado"))}

        # 5. modelo + arquivos
        erros = list(resumo["erros"]) + erros
        modelo = montar_modelo(cfg, novas, len(antigas), andamentos, fontes, hoje, inicio, fim, agora, erros)
        pasta = config.pasta_relatorios(cfg) / f"{hoje:%Y}" / hoje.isoformat()
        pasta.mkdir(parents=True, exist_ok=True)
        base = pasta / f"{MARCA['prefixo_arquivo']}-{hoje.isoformat()}_{agora:%H%M}"
        rel = cfg.get("relatorios") or {}
        versao_cfg = str(opts.get("encarte_versao") or rel.get("encarte_versao") or "auto")
        if versao_cfg.isdigit():
            versao_enc = int(versao_cfg)
        else:  # auto: escada de consciência — 1, 2, 3, 1, 2, 3… a cada Radar gerado
            est["encarte_contador"] = int(est.get("encarte_contador") or 0) + 1
            versao_enc = ((est["encarte_contador"] - 1) % 3) + 1
        modelo["encarte_versao"] = versao_enc
        pdf_path = gerar_pdf(modelo, base.with_suffix(".pdf"), encarte=encarte_ativo(rel), versao_encarte=versao_enc)
        html = html_email(modelo)
        base.with_suffix(".html").write_text(html, encoding="utf-8")
        json_path = base.with_suffix(".json")
        json_path.write_text(json.dumps(modelo, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
        log(f"  PDF: {pdf_path}")
        resumo.update({"pdf": str(pdf_path), "html": str(base.with_suffix('.html')), "json": str(json_path), "kpis": modelo["kpis"], "assunto": assunto_email(modelo),
                       "n_novas": len(novas), "n_criticas": modelo["kpis"]["criticas"], "n_andamentos": len(andamentos), "janela": modelo["janela"]})

        # 6. e-mail
        enviar_ok = False
        email_esperado = False
        if opts.get("sem_email"):
            log("  e-mail: envio desativado nesta execução (--sem-email)")
        elif not novas and not (cfg.get("email") or {}).get("enviar_quando_vazio", True) and not modelo["kpis"]["gargalos"] and not erros:
            log("  e-mail: nada novo e enviar_quando_vazio=false — não enviado")
        else:
            email_esperado = True
            provedor = ((cfg.get("email") or {}).get("provedor") or "smtp").lower()
            try:
                if provedor == "gmail-conector":
                    dest = list(opts.get("destinatarios") or (cfg.get("email") or {}).get("destinatarios") or [])
                    nuvem = str((cfg.get("relatorios") or {}).get("nuvem") or "nenhum").lower()
                    if (cfg.get("email") or {}).get("pdf_via") == "drive":
                        nuvem = "drive-sync"  # compatibilidade com a configuração antiga
                    link_nuvem = None
                    try:
                        if nuvem == "drive-doc" and not opts.get("sem_nuvem"):
                            html_doc = html_email_completo(modelo, caminho_exibicao(pdf_path), "", max_bytes=65000)
                            link_nuvem = criar_doc_no_drive(cfg, f"{ROTULO} — {hoje:%d/%m/%Y}", html_doc, dest, log=log)
                        elif nuvem == "drive-sync" and not opts.get("sem_nuvem"):
                            if copiar_para_drive(cfg, pdf_path, log=log):
                                link_nuvem = publicar_no_drive(cfg, pdf_path.name, dest, log=log)
                            if not link_nuvem:
                                erros.append("PDF não publicado no Google Drive (pasta sincronizada ausente ou arquivo ainda não sincronizado)")
                    except ErroConector as e:
                        erros.append(f"Versão na nuvem não criada: {e}")
                        log(f"  nuvem: FALHA — {e}")
                    resumo["link_nuvem"] = link_nuvem
                    html_c = html_email_completo(modelo, caminho_exibicao(pdf_path), link_nuvem or "", versao_encarte=int(modelo.get("encarte_versao") or 0) if encarte_ativo(cfg.get("relatorios") or {}) else 0)
                    txt_c = texto_email(modelo).replace("O PDF completo está em anexo.", f"PDF completo (no seu computador): {caminho_exibicao(pdf_path)}" + (f"\nNa nuvem (Google Drive, só para os destinatários): {link_nuvem}" if link_nuvem else ""))
                    r = enviar_por_conector(cfg, assunto_email(modelo), html_c, txt_c, dest, log=log)
                else:
                    r = enviar(cfg, assunto_email(modelo), html, texto_email(modelo), [pdf_path], opts.get("destinatarios"), log=log)
                enviar_ok = True
                resumo["destinatarios"] = r["destinatarios"]
            except (ErroEmail, ErroConector) as e:
                log(f"  e-mail: FALHA — {e}")
                erros.append(f"E-mail não enviado: {e}")
        resumo["email_enviado"] = enviar_ok
        resumo["email_pendente"] = email_esperado and not enviar_ok

        # 7. estado — se o e-mail era esperado e falhou, NÃO marca as publicações como vistas: elas voltam no próximo Radar
        if resumo["email_pendente"]:
            log("  publicações mantidas como não relatadas (e-mail falhou) — voltam na próxima execução")
        else:
            estado.marcar_vistas(est, novas, hoje)
        estado.podar(est)
        resumo["ok"] = True
        resumo["parcial"] = bool(erros)
        resumo["erros"] = erros
        resumo["duracao_s"] = round(time.time() - t0, 1)
        estado.registrar_run(est, resumo)
        estado.salvar(est)
        try:
            _limpar_antigos(cfg, log)
        except OSError as e:
            log(f"  aviso: limpeza de relatórios antigos falhou: {e}")
    log(f"Concluído em {resumo['duracao_s']}s — {len(novas)} novas, {modelo['kpis']['criticas']} críticas, e-mail {'enviado' if enviar_ok else 'não enviado'}"
        + (f", {len(erros)} aviso(s)" if erros else ""))
    return resumo


def registrar_falha(cfg: dict, exc: BaseException, log, opts: dict) -> None:
    """Grava a falha no estado e, se configurado, avisa por e-mail (sem PDF)."""
    try:
        est = estado.carregar()
        estado.registrar_run(est, {"ok": False, "agendado": bool(opts.get("agendado")), "erro": f"{type(exc).__name__}: {exc}", "traceback": traceback.format_exc()[-2000:]})
        estado.salvar(est)
    except Exception:
        pass
    if opts.get("sem_email") or not (cfg.get("email") or {}).get("avisar_falhas", True) or not opts.get("agendado"):
        return
    try:
        txt = f"O {ROTULO} falhou em {datetime.now():%d/%m/%Y %H:%M}.\n\nErro: {type(exc).__name__}: {exc}\n\nAbra o Claude Code e rode {_skill("status")} para diagnosticar. O Radar tentará novamente na próxima execução agendada."
        enviar(cfg, f"[FALHA] {ROTULO} · {date.today():%d/%m/%Y} · o relatório de hoje não foi gerado",
               "<pre style='font-family:Helvetica,Arial,sans-serif;white-space:pre-wrap'>" + _html.escape(txt) + "</pre>", txt, [], None, log=log)
    except Exception as e:  # noqa: BLE001
        log(f"  aviso de falha por e-mail também falhou: {e}")


# ------------------------------------------------------------------ e-mail HTML COMPLETO (modo conector: o e-mail é o relatório)
_C = {"CRITICA": "#C62828", "ALTA": "#E65100", "MEDIA": "#B8860B", "BAIXA": "#2E7D32", "CANCELADA": "#757575"}
_R = {"CRITICA": "CRÍTICA", "ALTA": "ALTA", "MEDIA": "MÉDIA", "BAIXA": "BAIXA", "CANCELADA": "CANCEL."}
_TD = 'style="padding:6px 0;border-bottom:1px solid #E6EAF0;font-family:Helvetica,Arial,sans-serif;font-size:11px;color:#111418;line-height:1.35"'


def _linha_pub(it: dict, k: dict) -> str:
    """Uma célula por publicação, marcação mínima (o e-mail inteiro precisa caber em ~60 KB)."""
    tr = it["triagem"]; ia_ = it.get("ia") or {}
    p = tr.get("prazo"); restam = it.get("dias_uteis_restantes")
    if p:
        vermelho = restam is not None and restam <= k["alerta_dias"]
        prazo = f"prazo {prazos.formatar_br(p['fim'])}" + (f" ({tr.get('prazo_dias')}d" + ("×2" if p.get("dobro") else "") + (" corridos" if p.get("corrido") else "") + ")")
        prazo = f'<b style="color:#C62828">{prazo}</b>' if vermelho else prazo
    elif tr.get("prazo_outra_parte"):
        prazo = f"prazo da outra parte ({tr['prazo_outra_parte']}d)"
    elif tr.get("prazo_futuro"):
        prazo = f"condicionado ({tr['prazo_futuro']}d)"
    else:
        prazo = "sem prazo"
    proc = _e(it.get("processo") or "—")
    if it.get("link"):
        proc = f'<a href="{_e(it["link"])}" style="color:{_CORP}">{proc}</a>'
    np_ = tr.get("nossa_parte") or {}
    parte = f" · {_e(truncar(np_.get('nome') or '', 28))} ({np_.get('polo')})" if np_.get("polo") in ("ativo", "passivo") else ""
    curto = tr["urgencia"] in ("MEDIA", "BAIXA", "CANCELADA")
    resumo = "" if curto else _e(truncar(ia_.get("resumo") or tr.get("corpo_resumo") or uma_linha(it.get("texto") or ""), 160))
    cor_tag = MARCA["cores"]["secundaria"]
    tag = (f' <span style="color:{cor_tag};font-weight:bold">[SEEU]</span>' if tr.get("execucao_penal") else (f' <span style="color:{cor_tag}">[penal]</span>' if tr.get("perfil") == "penal" and MARCA.get("perfil") != "criminal" else ""))
    parte = parte + tag
    return (f'<tr><td {_TD}><b style="color:{_C.get(tr["urgencia"], "#B8860B")}">{_R.get(tr["urgencia"], tr["urgencia"])}</b> · {_e(prazos.formatar_br(it["data"])[:5])} · <b>{proc}</b> <span style="color:#5F6B7A">{_e(it.get("tribunal",""))} · {_e(truncar(corrigir_texto_tribunal(it.get("orgao","")), 40))}{parte}</span>'
            f'<br><b>{_e(truncar(ia_.get("acao") or tr["ato"], 70))}</b> — {prazo}' + (f'<br><span style="color:#333">{resumo}</span>' if resumo else "") + "</td></tr>")


def html_email_completo(m: dict, caminho_pdf: str = "", link_nuvem: str = "", max_bytes: int = 60000, versao_encarte: int = 0) -> str:
    """O relatório inteiro em HTML compatível com Gmail. Reduz a tabela de publicações se passar de `max_bytes` (Gmail corta em ~102 KB)."""
    k = m["kpis"]
    base = html_email(m)  # cabeçalho, resumo, KPIs, prioridades, agenda, alertas, avisos, rodapé com CTA
    pubs = m["publicacoes"]; ands = m["andamentos"]
    onde = []
    if caminho_pdf:
        onde.append(f'<div><strong>PDF completo (no seu computador):</strong> <span style="font-family:Menlo,Consolas,monospace;font-size:11px">{_e(caminho_pdf)}</span></div>')
    if link_nuvem:
        onde.append(f'<div style="margin-top:4px"><strong>Na nuvem (Google Drive, só para os destinatários):</strong> <a href="{_e(link_nuvem)}" style="color:#2E6BFF">{_e(link_nuvem)}</a></div>')
    bloco_onde = ('<table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr><td bgcolor="#F3F5F9" style="padding:12px 14px;background-color:#F3F5F9;border-radius:8px;font-family:Helvetica,Arial,sans-serif;font-size:12px;color:#111418">'
                  + "".join(onde) + "</td></tr></table>") if onde else ""

    def tabela_pubs(lista):
        return '<table role="presentation" width="100%" cellspacing="0" cellpadding="0">' + "".join(_linha_pub(it, k) for it in lista) + "</table>"

    def tabela_ands(lista):
        linhas = []
        for a in lista:
            um = a.get("ultimo_movimento") or {}; al = a.get("alerta") or {}
            cor = {"GARGALO": "#C62828", "ATENCAO": "#E65100", "VERIFICAR": "#B8860B"}.get(al.get("nivel"), "#2E7D32")
            dias = (str(a["dias_parado"]) + "d parado") if a.get("dias_parado") is not None else ""
            linhas.append(f'<tr><td {_TD}><b style="color:{cor}">{_e(a.get("status") or "VERIFICAR")}</b> · <b>{_e(a["numero"])}</b> <span style="color:#5F6B7A">{_e(a.get("tribunal",""))} {_e(a.get("grau",""))} · {_e(truncar(titulo_classe(a.get("classe","")), 34))}</span>'
                          f'<br>{_e(truncar(um.get("nome") or (a.get("erro") or "—"), 60))}' + (f' ({_e(prazos.formatar_br(um["data"]))})' if um.get("data") else "") + (f' · <b style="color:{cor}">{dias}</b>' if dias else "")
                          + (f'<br><span style="color:#5F6B7A">{_e(truncar(al.get("mensagem",""), 90))}</span>' if al.get("mensagem") and al.get("nivel") != "NORMAL" else "") + "</td></tr>")
        return '<table role="presentation" width="100%" cellspacing="0" cellpadding="0">' + "".join(linhas) + "</table>"

    checklist = "".join(f'<li style="margin:4px 0">{_e(c)}</li>' for c in m["checklist"])
    notas = "".join(f'<li style="margin:3px 0">{_e(n)}</li>' for n in m["notas"])

    def montar(n_pubs, n_ands, n_exec=12):
        aviso_p = f'<div style="font-size:11px;color:#5F6B7A;margin:4px 0 8px">Mostrando {n_pubs} de {len(pubs)} publicações (as mais urgentes) — a lista completa está no PDF.</div>' if n_pubs < len(pubs) else ""
        aviso_a = f'<div style="font-size:11px;color:#5F6B7A;margin:4px 0 8px">Mostrando {n_ands} de {len(ands)} processos (os que pedem atenção primeiro) — o restante está no PDF.</div>' if n_ands < len(ands) else ""
        exec_pen = [it for it in pubs if (it.get("triagem") or {}).get("execucao_penal")]
        bloco_exec = (f'<h3 style="font-family:Helvetica,Arial,sans-serif;color:{_CORP};font-size:15px;margin:22px 0 6px">Execução penal · SEEU ({len(exec_pen)})</h3>'
                      f'<div style="font-family:Helvetica,Arial,sans-serif;font-size:11px;color:#5F6B7A;margin:0 0 6px">Intimações do SEEU chegam pelo DJEN. Agravo em execução: 5 dias corridos (LEP 197; Súm. 700 STF). Autos e andamento: <a href="https://seeu.pje.jus.br/seeu/" style="color:{_CORP}">seeu.pje.jus.br</a> quando a DataJud não sincroniza.</div>'
                      + tabela_pubs(exec_pen[:n_exec])) if exec_pen else ""
        secoes = (bloco_exec + f'<h3 style="font-family:Helvetica,Arial,sans-serif;color:{_CORP};font-size:15px;margin:22px 0 6px">Todas as publicações novas ({len(pubs)})</h3>{aviso_p}' + (tabela_pubs(pubs[:n_pubs]) if n_pubs else "")
                  + f'<h3 style="font-family:Helvetica,Arial,sans-serif;color:{_CORP};font-size:15px;margin:22px 0 6px">Andamento processual ({len(ands)})</h3>{aviso_a}' + (tabela_ands(ands[:n_ands]) if n_ands else "")
                  + f'<h3 style="font-family:Helvetica,Arial,sans-serif;color:{_CORP};font-size:15px;margin:22px 0 6px">Checklist de hoje</h3><ul style="font-family:Helvetica,Arial,sans-serif;font-size:13px;color:#111418;padding-left:18px;margin:0">{checklist}</ul>'
                  + f'<h3 style="font-family:Helvetica,Arial,sans-serif;color:{_CORP};font-size:13px;margin:22px 0 6px">Fontes, metodologia e avisos</h3><ul style="font-family:Helvetica,Arial,sans-serif;font-size:11px;color:#5F6B7A;padding-left:18px;margin:0">{notas}</ul>')
        # injeta antes do bloco final (o bloco "PDF completo") e substitui o bloco do anexo pelo "onde está"
        h = base.replace('<tr><td style="padding:18px 26px 24px;font-family:Helvetica,Arial,sans-serif;font-size:13px;color:#111418">',
                         f'<tr><td style="padding:4px 26px 0">{secoes}</td></tr>\n<tr><td style="padding:18px 26px 24px;font-family:Helvetica,Arial,sans-serif;font-size:13px;color:#111418">', 1)
        import re as _re
        h = _re.sub(r'<table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr><td bgcolor="#F3F5F9" style="padding:12px 14px;background-color:#F3F5F9;border-radius:8px"><strong>O PDF completo está em anexo</strong>.*?</td></tr></table>', bloco_onde, h, count=1, flags=_re.S)
        if versao_encarte:
            try:
                if MARCA.get("encarte") == "criminal":
                    from .email_encarte_criminal import html_encarte
                else:
                    from .email_encarte import html_encarte
            except ImportError:
                html_encarte = lambda v: ""  # noqa: E731 — sem encarte, o e-mail sai mesmo assim
            # remove o botão simples do rodapé (o encarte traz o CTA completo) e insere o encarte antes do fechamento da tabela principal
            h = _re.sub(r'<table role="presentation" cellspacing="0" cellpadding="0" style="margin-top:14px"><tr><td bgcolor="#25D366".*?</td></tr></table>', "", h, count=1, flags=_re.S)
            h = h.replace("</table></td></tr></table></body></html>", html_encarte(versao_enc_local) + "\n</table></td></tr></table></body></html>", 1)
        return h

    versao_enc_local = versao_encarte or int(m.get("encarte_versao") or 0)
    n_p, n_a, n_x = len(pubs), len(ands), 12
    h = montar(n_p, n_a, n_x)
    while len(h.encode("utf-8")) > max_bytes and (n_p > 8 or n_a > 5 or n_x > 4):
        if n_a > 5:
            n_a = max(5, int(n_a * 0.6))
        elif n_p > 8:
            n_p = max(8, int(n_p * 0.7))
        else:
            n_x = max(4, int(n_x * 0.6))
        h = montar(n_p, n_a, n_x)
    return h
