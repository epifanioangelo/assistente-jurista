"""Envio pelo conector Gmail do claude.ai (sem senha de app), via `claude -p` com a ferramenta liberada.

Limite medido: o modelo precisa reproduzir o conteúdo na chamada da ferramenta. Texto/HTML curto
copia com fidelidade; base64 de um PDF (100 KB+) NÃO — por isso neste modo o e-mail leva o corpo HTML
completo e o PDF fica salvo localmente (o caminho vai no e-mail).
"""
from __future__ import annotations

import json
import os
import re
import subprocess
from typing import List, Optional

from .ia import _ambiente, encontrar_claude
from .marca import M as MARCA

FERRAMENTA_PADRAO = "mcp__claude_ai_Gmail__send_message"
DRIVE_TOOLS = ["mcp__claude_ai_Google_Drive__search_files", "mcp__claude_ai_Google_Drive__share_file", "mcp__claude_ai_Google_Drive__get_file_metadata"]


class ErroConector(Exception):
    pass


def enviar_por_conector(cfg: dict, assunto: str, html: str, texto: str, destinatarios: List[str], log=None, timeout: int = 300) -> dict:
    log = log or (lambda s: None)
    binario = encontrar_claude(cfg)
    if not binario:
        raise ErroConector("`claude` não encontrado — o modo conector precisa do Claude Code instalado e logado.")
    ferramenta = ((cfg.get("email") or {}).get("conector_tool") or FERRAMENTA_PADRAO).strip()
    modelo = ((cfg.get("ia") or {}).get("modelo") or "haiku").strip()
    if len(html) > 70000:
        raise ErroConector(f"HTML do e-mail grande demais para o modo conector ({len(html)//1024} KB > 70 KB)")
    prompt = (
        "Você é um transmissor. Chame UMA vez a ferramenta `" + ferramenta + "` com EXATAMENTE os campos abaixo, sem alterar, resumir, traduzir ou "
        "acrescentar nada ao conteúdo. Não escreva nada além do JSON final.\n\n"
        "to: " + json.dumps(destinatarios, ensure_ascii=False) + "\n"
        "subject: " + json.dumps(assunto, ensure_ascii=False) + "\n"
        "body (texto simples, copiar literalmente):\n<<<TEXTO>>>\n" + texto + "\n<<<FIM TEXTO>>>\n\n"
        "htmlBody (copiar literalmente, byte a byte):\n<<<HTML>>>\n" + html + "\n<<<FIM HTML>>>\n\n"
        "Depois da chamada, responda somente com um JSON: {\"enviado\": true|false, \"id\": \"<id da mensagem ou vazio>\", \"erro\": \"<mensagem ou vazio>\"}."
    )
    schema = json.dumps({"type": "object", "properties": {"enviado": {"type": "boolean"}, "id": {"type": "string"}, "erro": {"type": "string"}}, "required": ["enviado", "id", "erro"]})
    cmd = [binario, "-p", "--no-session-persistence", "--model", modelo, "--output-format", "json", "--json-schema", schema,
           "--allowedTools", ferramenta, "--tools", "ToolSearch", "--setting-sources", ""]  # ToolSearch carrega só o esquema do conector (sem ele, todos os conectores entram no contexto e estoura o limite)
    try:
        r = subprocess.run(cmd, input=prompt, capture_output=True, text=True, timeout=max(timeout, 900), env=_ambiente())
    except subprocess.TimeoutExpired as e:
        raise ErroConector(f"o envio pelo conector estourou {max(timeout, 900)}s") from e
    saida = r.stdout or ""
    try:  # diagnóstico: última resposta crua do claude
        from .config import pasta_logs
        pasta_logs().mkdir(parents=True, exist_ok=True)
        (pasta_logs() / "conector-ultimo.json").write_text(saida + "\n--- stderr ---\n" + (r.stderr or ""), encoding="utf-8")
    except OSError:
        pass
    m = re.search(r"\{.*\}", saida, re.S)
    if not m:
        raise ErroConector(f"claude não devolveu JSON (código {r.returncode}): {(r.stderr or saida)[:300]}")
    try:
        d = json.JSONDecoder().raw_decode(saida[m.start():])[0]
    except json.JSONDecodeError as e:
        raise ErroConector(f"saída inválida do claude: {saida[:300]}") from e
    if d.get("is_error"):
        raise ErroConector(f"claude: {d.get('result')}")
    so = d.get("structured_output") or {}
    if not so:
        try:
            so = json.loads(d.get("result") or "{}")
        except json.JSONDecodeError:
            so = {}
    if not so.get("enviado"):
        raise ErroConector("o conector não confirmou o envio: " + (so.get("erro") or str(d.get("result"))[:300] or "sem detalhe") +
                           " — confira se o conector do Gmail está conectado em claude.ai e se a ferramenta se chama " + ferramenta)
    log(f"  e-mail enviado pelo conector Gmail (id {so.get('id') or '?'}) para {', '.join(destinatarios)}")
    return {"ok": True, "destinatarios": destinatarios, "id": so.get("id"), "custo_usd": d.get("total_cost_usd")}


# ----------------------------------------------------------------------------- PDF via Google Drive (pasta sincronizada + conector)
def pasta_drive(cfg: dict) -> Optional["Path"]:
    """Pasta local sincronizada pelo Google Drive para desktop (config `relatorios.pasta_drive` ou detecção automática)."""
    from pathlib import Path
    import glob
    cfg_p = ((cfg.get("relatorios") or {}).get("pasta_drive") or "").strip()
    cands = [Path(cfg_p).expanduser()] if cfg_p else []
    home = Path.home()
    cands += [Path(x) for x in sorted(glob.glob(str(home / "Library/CloudStorage/GoogleDrive-*/My Drive")))]
    cands += [Path(x) for x in sorted(glob.glob(str(home / "Library/CloudStorage/GoogleDrive-*/Meu Drive")))]
    cands += [home / "Google Drive" / "My Drive", home / "Google Drive" / "Meu Drive", home / "Google Drive", Path("G:/My Drive"), Path("G:/Meu Drive")]
    for c in cands:
        if c.is_dir():
            return c
    return None


def copiar_para_drive(cfg: dict, pdf_path, log=None) -> Optional["Path"]:
    """Copia o PDF para <Drive>/<marca>/Radar/<AAAA>/ — o cliente do Drive sincroniza; devolve o caminho ou None."""
    import shutil
    from datetime import date
    from pathlib import Path
    base = pasta_drive(cfg)
    if not base:
        if log:
            log("  Drive: pasta sincronizada não encontrada (instale o Google Drive para desktop ou defina relatorios.pasta_drive)")
        return None
    destino = base / MARCA["nome"] / "Radar" / f"{date.today():%Y}"
    destino.mkdir(parents=True, exist_ok=True)
    alvo = destino / Path(pdf_path).name
    shutil.copy2(pdf_path, alvo)
    if log:
        log(f"  Drive: PDF copiado para {alvo} (aguardando sincronização)")
    return alvo


def publicar_no_drive(cfg: dict, titulo: str, destinatarios: List[str], log=None, tentativas: int = 5, espera_s: int = 60, espera_inicial_s: int = 45) -> Optional[str]:
    """Localiza o PDF no Drive (já sincronizado), compartilha com os destinatários (leitor) e devolve o viewUrl. None se não achou."""
    import time
    log = log or (lambda s: None)
    binario = encontrar_claude(cfg)
    if not binario:
        raise ErroConector("`claude` não encontrado — o modo conector precisa do Claude Code instalado e logado.")
    modelo = ((cfg.get("ia") or {}).get("modelo") or "haiku").strip()
    schema = json.dumps({"type": "object", "properties": {"encontrado": {"type": "boolean"}, "fileId": {"type": "string"}, "viewUrl": {"type": "string"},
                         "compartilhado_com": {"type": "array", "items": {"type": "string"}}, "erro": {"type": "string"}},
                        "required": ["encontrado", "fileId", "viewUrl", "compartilhado_com", "erro"]})
    titulo_q = titulo.replace("\\", "\\\\").replace("'", "\\'")
    prompt = (
        "Você é um operador do Google Drive. Use as ferramentas do conector Google Drive (carregue com ToolSearch: " + ", ".join(DRIVE_TOOLS) + "). Faça nesta ordem:\n"
        "1) search_files com query: title = '" + titulo_q + "' and owner = 'me' (excludeContentSnippets true). Se não encontrar nenhum arquivo, responda encontrado=false e PARE.\n"
        "2) Para CADA e-mail em " + json.dumps(destinatarios, ensure_ascii=False) + ", chame share_file com o fileId encontrado, emailAddress = o e-mail, role = \"reader\". Se um compartilhamento falhar, siga para o próximo e registre em erro.\n"
        "3) get_file_metadata do arquivo (excludeContentSnippets true) e copie o viewUrl.\n"
        "Não crie, edite nem apague arquivos. Responda somente com o JSON pedido."
    )
    cmd = [binario, "-p", "--no-session-persistence", "--model", modelo, "--output-format", "json", "--json-schema", schema,
           "--allowedTools", ",".join(DRIVE_TOOLS), "--tools", "ToolSearch", "--setting-sources", ""]
    time.sleep(espera_inicial_s)
    for n in range(1, tentativas + 1):
        try:
            r = subprocess.run(cmd, input=prompt, capture_output=True, text=True, timeout=240, env=_ambiente())
        except subprocess.TimeoutExpired:
            log(f"  Drive: tentativa {n} estourou o tempo")
            continue
        m = re.search(r"\{.*\}", r.stdout or "", re.S)
        so = {}
        if m:
            try:
                d = json.JSONDecoder().raw_decode((r.stdout or "")[m.start():])[0]
                so = d.get("structured_output") or {}
                if d.get("is_error"):
                    log(f"  Drive: {d.get('result')}")
            except json.JSONDecodeError:
                pass
        if so.get("encontrado") and so.get("viewUrl"):
            faltou = [e for e in destinatarios if e not in (so.get("compartilhado_com") or [])]
            log(f"  Drive: PDF compartilhado com {', '.join(so.get('compartilhado_com') or [])}" + (f" (falhou: {', '.join(faltou)})" if faltou else "") + f" — {so['viewUrl']}")
            return so["viewUrl"]
        log(f"  Drive: arquivo ainda não sincronizado (tentativa {n}/{tentativas})" + (f" — {so.get('erro')}" if so.get("erro") else ""))
        if n < tentativas:
            time.sleep(espera_s)
    return None


# ----------------------------------------------------------------------------- Relatório na nuvem: Google Docs criado pelo conector (sem app no computador)
DRIVE_TOOLS_DOC = ["mcp__claude_ai_Google_Drive__search_files", "mcp__claude_ai_Google_Drive__create_file", "mcp__claude_ai_Google_Drive__share_file"]
PASTA_DRIVE_NOME = f"{MARCA['nome']} - Radar"


def criar_doc_no_drive(cfg: dict, titulo: str, html: str, destinatarios: List[str], log=None, timeout: int = 900) -> Optional[str]:
    """Cria um Google Docs com o relatório (HTML → Docs) na pasta do Radar, compartilha com os destinatários e devolve o link."""
    log = log or (lambda s: None)
    binario = encontrar_claude(cfg)
    if not binario:
        raise ErroConector("`claude` não encontrado — o modo conector precisa do Claude Code instalado e logado.")
    if len(html) > 70000:
        raise ErroConector(f"HTML grande demais para criar o Google Docs ({len(html)//1024} KB > 70 KB)")
    modelo = ((cfg.get("ia") or {}).get("modelo") or "haiku").strip()
    schema = json.dumps({"type": "object", "properties": {"criado": {"type": "boolean"}, "fileId": {"type": "string"}, "viewUrl": {"type": "string"},
                         "compartilhado_com": {"type": "array", "items": {"type": "string"}}, "erro": {"type": "string"}},
                        "required": ["criado", "fileId", "viewUrl", "compartilhado_com", "erro"]})
    prompt = (
        "Você é um operador do Google Drive. Use as ferramentas do conector Google Drive (carregue com ToolSearch: " + ", ".join(DRIVE_TOOLS_DOC) + "). Faça nesta ordem:\n"
        "1) search_files com query: title = '" + PASTA_DRIVE_NOME + "' and mimeType = 'application/vnd.google-apps.folder' and owner = 'me' (excludeContentSnippets true). "
        "Se não existir, crie a pasta com create_file (title \"" + PASTA_DRIVE_NOME + "\", contentMimeType \"application/vnd.google-apps.folder\", sem conteúdo). Guarde o id da pasta.\n"
        "2) create_file com title " + json.dumps(titulo, ensure_ascii=False) + ", parentId = id da pasta, contentMimeType \"text/html\", disableConversionToGoogleType false (para virar Google Docs) "
        "e textContent = EXATAMENTE o HTML abaixo, copiado literalmente, sem resumir, sem alterar nada:\n<<<HTML>>>\n" + html + "\n<<<FIM HTML>>>\n"
        "3) Para CADA e-mail em " + json.dumps(destinatarios, ensure_ascii=False) + ", share_file com o fileId criado, emailAddress = o e-mail, role = \"reader\".\n"
        "4) Responda somente com o JSON pedido (viewUrl é o campo viewUrl devolvido pelo create_file)."
    )
    cmd = [binario, "-p", "--no-session-persistence", "--model", modelo, "--output-format", "json", "--json-schema", schema,
           "--allowedTools", ",".join(DRIVE_TOOLS_DOC), "--tools", "ToolSearch", "--setting-sources", ""]
    try:
        r = subprocess.run(cmd, input=prompt, capture_output=True, text=True, timeout=timeout, env=_ambiente())
    except subprocess.TimeoutExpired as e:
        raise ErroConector(f"criação do Google Docs estourou {timeout}s") from e
    try:
        from .config import pasta_logs
        pasta_logs().mkdir(parents=True, exist_ok=True)
        (pasta_logs() / "drive-doc-ultimo.json").write_text((r.stdout or "") + "\n--- stderr ---\n" + (r.stderr or ""), encoding="utf-8")
    except OSError:
        pass
    m = re.search(r"\{.*\}", r.stdout or "", re.S)
    so = {}
    if m:
        try:
            d = json.JSONDecoder().raw_decode((r.stdout or "")[m.start():])[0]
            so = d.get("structured_output") or {}
            if d.get("is_error"):
                raise ErroConector(f"claude: {d.get('result')}")
        except json.JSONDecodeError:
            pass
    if not so.get("criado") or not so.get("viewUrl"):
        raise ErroConector("o conector não confirmou a criação do Google Docs: " + (so.get("erro") or (r.stdout or r.stderr)[:200]))
    faltou = [e for e in destinatarios if e not in (so.get("compartilhado_com") or [])]
    log(f"  Drive: Google Docs criado e compartilhado com {', '.join(so.get('compartilhado_com') or [])}" + (f" (falhou: {', '.join(faltou)})" if faltou else "") + f" — {so['viewUrl']}")
    return so["viewUrl"]
