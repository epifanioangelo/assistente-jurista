"""Agendamento diário do Radar: launchd (macOS), cron (Linux) ou Agendador de Tarefas (Windows)."""
from __future__ import annotations

import os
import platform
import plistlib
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from .config import base_dir, pasta_logs
from .marca import M as MARCA

LABEL = MARCA["launchd_label"]
MARCADOR_CRON = MARCA["marcador_cron"]
NOME_TAREFA_WIN = MARCA["tarefa_windows"]
ENV_HOME = MARCA["env_home"]


def script_cli() -> Path:
    return Path(__file__).resolve().parent.parent / "a100x.py"


def raiz_plugin() -> Path:
    return script_cli().parent.parent


def interpretador() -> str:
    return sys.executable or "python3"


LAUNCHER_SH = """#!/bin/sh
# __NOME__ · __PRODUTO__ — lançador estável do job agendado.
# Localiza o motor do plugin em tempo de execução (sobrevive a atualizações do plugin e do Python).
PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"; export PATH
PY="$(command -v python3 || command -v python)"
if [ -z "$PY" ]; then echo "python3 não encontrado" >&2; exit 127; fi
MOTOR=""
if [ -f "$HOME/.claude/plugins/installed_plugins.json" ]; then
  MOTOR="$("$PY" - <<'EOF'
import json, os
try:
    d = json.load(open(os.path.expanduser("~/.claude/plugins/installed_plugins.json")))
    for chave, lista in (d.get("plugins") or {}).items():
        if chave.startswith("__ID__@"):
            for inst in lista:
                ip = inst.get("installPath") or ""
                if os.path.exists(os.path.join(ip, "scripts", "a100x.py")):
                    print(ip); raise SystemExit
except SystemExit:
    raise
except Exception:
    pass
EOF
)"
fi
if [ -z "$MOTOR" ] && [ -f "__RAIZ__/scripts/a100x.py" ]; then MOTOR="__RAIZ__"; fi
if [ -z "$MOTOR" ]; then echo "motor do __NOME__ não encontrado (plugin desinstalado?)" >&2; exit 1; fi
exec "$PY" "$MOTOR/scripts/a100x.py" rodar --agendado "$@"
"""


LAUNCHER_CMD = r"""@echo off
rem __NOME__ - __PRODUTO__ - lancador estavel do job agendado (Windows)
set "PY="
for %%P in (python3.exe python.exe py.exe) do if not defined PY for %%I in (%%P) do if not "%%~$PATH:I"=="" set "PY=%%~$PATH:I"
if not defined PY ( echo python3 nao encontrado >&2 & exit /b 127 )
set "MOTOR="
for /f "usebackq delims=" %%M in (`"%PY%" -c "import json,os;d=json.load(open(os.path.expanduser('~/.claude/plugins/installed_plugins.json')));print(next((i['installPath'] for k,l in (d.get('plugins') or {}).items() if k.startswith('__ID__@') for i in l if os.path.exists(os.path.join(i.get('installPath',''),'scripts','a100x.py'))),''))" 2^>nul`) do set "MOTOR=%%M"
if not defined MOTOR if exist "__RAIZ__\scripts\a100x.py" set "MOTOR=__RAIZ__"
if not defined MOTOR ( echo motor do __NOME__ nao encontrado >&2 & exit /b 1 )
"%PY%" "%MOTOR%\scripts\a100x.py" rodar --agendado %*
"""


def _preencher(modelo: str) -> str:
    return (modelo.replace("__RAIZ__", str(raiz_plugin())).replace("__ID__", MARCA["id"]).replace("__NOME__", MARCA["nome"]).replace("__PRODUTO__", MARCA["produto"]))


def escrever_launcher_windows() -> Path:
    pasta = base_dir() / "bin"
    pasta.mkdir(parents=True, exist_ok=True)
    arq = pasta / "radar-launcher.cmd"
    arq.write_text(_preencher(LAUNCHER_CMD), encoding="utf-8")
    return arq


def escrever_launcher() -> Path:
    """Grava ~/<pasta_home>/bin/radar-launcher.sh e devolve o caminho."""
    pasta = base_dir() / "bin"
    pasta.mkdir(parents=True, exist_ok=True)
    arq = pasta / "radar-launcher.sh"
    arq.write_text(_preencher(LAUNCHER_SH), encoding="utf-8")
    arq.chmod(0o700)
    return arq


def sistema() -> str:
    s = platform.system().lower()
    return "macos" if s == "darwin" else ("windows" if s == "windows" else "linux")


def plist_path() -> Path:
    return Path.home() / "Library" / "LaunchAgents" / f"{LABEL}.plist"


def _hora(hora: str):
    hh, mm = hora.split(":")
    return int(hh), int(mm)


def proxima_execucao(hora: str, dias: str = "uteis", agora: Optional[datetime] = None) -> datetime:
    agora = agora or datetime.now()
    hh, mm = _hora(hora)
    cand = agora.replace(hour=hh, minute=mm, second=0, microsecond=0)
    if cand <= agora:
        cand += timedelta(days=1)
    if dias == "uteis":
        while cand.weekday() >= 5:
            cand += timedelta(days=1)
    return cand


def _run(cmd, **kw):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, **kw)
    except FileNotFoundError as e:
        raise RuntimeError(f"comando não encontrado: {cmd[0]} — instale-o (Linux: `apt install cron`) ou agende por outro meio") from e


# ---------------------------------------------------------------- macOS
def _instalar_launchd(hora: str, dias: str, log) -> dict:
    hh, mm = _hora(hora)
    logs = pasta_logs()
    logs.mkdir(parents=True, exist_ok=True)
    if dias == "uteis":
        calendario = [{"Weekday": wd, "Hour": hh, "Minute": mm} for wd in range(1, 6)]
    else:
        calendario = {"Hour": hh, "Minute": mm}
    env = {"PATH": "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin", "HOME": str(Path.home()), "LANG": "pt_BR.UTF-8", "PYTHONIOENCODING": "utf-8"}
    if os.environ.get(ENV_HOME):
        env[ENV_HOME] = os.environ[ENV_HOME]
    plist = {
        "Label": LABEL,
        "ProgramArguments": ["/bin/sh", str(escrever_launcher())],
        "StartCalendarInterval": calendario,
        "EnvironmentVariables": env,
        "StandardOutPath": str(logs / "launchd.out.log"),
        "StandardErrorPath": str(logs / "launchd.err.log"),
        "RunAtLoad": False,
        "ProcessType": "Background",
        "Nice": 5,
    }
    p = plist_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "wb") as f:
        plistlib.dump(plist, f)
    uid = os.getuid()
    _run(["launchctl", "bootout", f"gui/{uid}/{LABEL}"])
    r = _run(["launchctl", "bootstrap", f"gui/{uid}", str(p)])
    if r.returncode != 0:
        r2 = _run(["launchctl", "load", "-w", str(p)])
        if r2.returncode != 0:
            raise RuntimeError(f"launchctl falhou: {r.stderr.strip() or r.stdout.strip()} / {r2.stderr.strip()}")
    r = _run(["launchctl", "print", f"gui/{uid}/{LABEL}"])
    if log:
        log(f"  launchd: {p} ({'carregado' if r.returncode == 0 else 'aviso: não confirmado'})")
    return {"plataforma": "macos", "arquivo": str(p), "carregado": r.returncode == 0}


def _remover_launchd(log) -> dict:
    uid = os.getuid()
    _run(["launchctl", "bootout", f"gui/{uid}/{LABEL}"])
    p = plist_path()
    existia = p.exists()
    if existia:
        p.unlink()
    return {"plataforma": "macos", "removido": existia}


def _status_launchd() -> dict:
    p = plist_path()
    inst = p.exists()
    carregado = False
    ultimo_exit = None
    if inst:
        r = _run(["launchctl", "print", f"gui/{os.getuid()}/{LABEL}"])
        carregado = r.returncode == 0
        for l in (r.stdout or "").splitlines():
            if "last exit code" in l:
                ultimo_exit = l.strip()
    return {"instalado": inst, "carregado": carregado, "arquivo": str(p), "ultimo_exit": ultimo_exit}


# ---------------------------------------------------------------- Linux (cron)
def _cron_atual() -> str:
    r = _run(["crontab", "-l"])
    return r.stdout if r.returncode == 0 else ""


def _instalar_cron(hora: str, dias: str, log) -> dict:
    hh, mm = _hora(hora)
    logs = pasta_logs()
    logs.mkdir(parents=True, exist_ok=True)
    dow = "1-5" if dias == "uteis" else "*"
    env_home = f'{ENV_HOME}="{os.environ[ENV_HOME]}" ' if os.environ.get(ENV_HOME) else ""
    linha = f'{mm} {hh} * * {dow} {env_home}/bin/sh "{escrever_launcher()}" >> "{logs / "cron.log"}" 2>&1 {MARCADOR_CRON}'
    linhas = [l for l in _cron_atual().splitlines() if MARCADOR_CRON not in l]
    linhas.append(linha)
    try:
        r = subprocess.run(["crontab", "-"], input="\n".join(linhas) + "\n", text=True, capture_output=True)
    except FileNotFoundError as e:
        raise RuntimeError("crontab não encontrado — instale o cron (ex.: `apt install cron`)") from e
    if r.returncode != 0:
        raise RuntimeError(f"crontab falhou: {r.stderr.strip()}")
    return {"plataforma": "linux", "linha": linha}


def _remover_cron(log) -> dict:
    atual = _cron_atual()
    linhas = [l for l in atual.splitlines() if MARCADOR_CRON not in l]
    try:
        subprocess.run(["crontab", "-"], input="\n".join(linhas) + ("\n" if linhas else ""), text=True, capture_output=True)
    except FileNotFoundError:
        pass
    return {"plataforma": "linux", "removido": MARCADOR_CRON in atual}


def _status_cron() -> dict:
    return {"instalado": MARCADOR_CRON in _cron_atual(), "carregado": MARCADOR_CRON in _cron_atual()}


# ---------------------------------------------------------------- Windows (schtasks)
def _instalar_schtasks(hora: str, dias: str, log) -> dict:
    tr = f'"{escrever_launcher_windows()}"'
    cmd = ["schtasks", "/Create", "/F", "/TN", NOME_TAREFA_WIN, "/TR", tr, "/ST", hora]
    cmd += ["/SC", "WEEKLY", "/D", "MON,TUE,WED,THU,FRI"] if dias == "uteis" else ["/SC", "DAILY"]
    r = _run(cmd)
    if r.returncode != 0:
        raise RuntimeError(f"schtasks falhou: {r.stderr.strip() or r.stdout.strip()}")
    return {"plataforma": "windows", "tarefa": NOME_TAREFA_WIN}


def _remover_schtasks(log) -> dict:
    r = _run(["schtasks", "/Delete", "/F", "/TN", NOME_TAREFA_WIN])
    return {"plataforma": "windows", "removido": r.returncode == 0}


def _status_schtasks() -> dict:
    r = _run(["schtasks", "/Query", "/TN", NOME_TAREFA_WIN])
    return {"instalado": r.returncode == 0, "carregado": r.returncode == 0}


# ---------------------------------------------------------------- API
def instalar(cfg: dict, hora: Optional[str] = None, dias: Optional[str] = None, log=None) -> dict:
    from .config import _hora_valida
    ag = cfg.get("agenda") or {}
    hora = hora or ag.get("hora") or "07:30"
    dias = dias or ag.get("dias") or "uteis"
    if not _hora_valida(hora):
        raise RuntimeError(f"hora inválida: {hora!r} (use HH:MM, ex.: 07:30)")
    if dias not in ("uteis", "todos"):
        raise RuntimeError(f"dias inválido: {dias!r} (use uteis ou todos)")
    s = sistema()
    if s == "macos":
        info = _instalar_launchd(hora, dias, log)
    elif s == "linux":
        info = _instalar_cron(hora, dias, log)
    else:
        info = _instalar_schtasks(hora, dias, log)
    info.update({"hora": hora, "dias": dias, "proxima": proxima_execucao(hora, dias).isoformat(timespec="minutes")})
    return info


def remover(log=None) -> dict:
    s = sistema()
    return _remover_launchd(log) if s == "macos" else (_remover_cron(log) if s == "linux" else _remover_schtasks(log))


def status(cfg: dict) -> dict:
    s = sistema()
    info = _status_launchd() if s == "macos" else (_status_cron() if s == "linux" else _status_schtasks())
    ag = cfg.get("agenda") or {}
    info.update({"plataforma": s, "hora": ag.get("hora"), "dias": ag.get("dias")})
    if info.get("instalado") and ag.get("hora"):
        info["proxima"] = proxima_execucao(ag["hora"], ag.get("dias", "uteis")).isoformat(timespec="minutes")
    return info


def executar_agora() -> dict:
    """Dispara o job agendado imediatamente (macOS: kickstart). Nas demais plataformas, roda em segundo plano."""
    if sistema() == "macos" and plist_path().exists():
        r = _run(["launchctl", "kickstart", "-k", f"gui/{os.getuid()}/{LABEL}"])
        return {"ok": r.returncode == 0, "detalhe": (r.stderr or r.stdout).strip()}
    p = subprocess.Popen(["/bin/sh", str(escrever_launcher())] if sistema() != "windows" else ["cmd", "/c", str(escrever_launcher_windows())],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    return {"ok": True, "detalhe": f"pid {p.pid}"}
