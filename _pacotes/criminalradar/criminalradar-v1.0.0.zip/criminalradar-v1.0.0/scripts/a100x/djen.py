"""Cliente do DJEN — Comunica API (CNJ). Pública, sem chave.

Documentação de campo (observada em produção): GET https://comunicaapi.pje.jus.br/api/v1/comunicacao
Filtros: numeroOab + ufOab · numeroProcesso (20 dígitos) · nomeParte · nomeAdvogado · siglaTribunal ·
meio (D = Diário, E = Plataforma Nacional de Editais) · dataDisponibilizacaoInicio/Fim (AAAA-MM-DD) ·
pagina · itensPorPagina (máx. 100). Resposta: {status, message, count, items[]}.
"""
from __future__ import annotations

import time
from datetime import date
from typing import Callable, List, Optional

from . import cnj
from .http import ErroHTTP, get_json
from .texto import limpar_html, uma_linha

URL = "https://comunicaapi.pje.jus.br/api/v1/comunicacao"
POR_PAGINA = 100
MAX_PAGINAS = 60  # 6.000 itens por consulta — muito acima de qualquer carteira diária


def buscar(params: dict, log: Optional[Callable] = None, max_paginas: int = MAX_PAGINAS, info: Optional[dict] = None) -> List[dict]:
    """Percorre todas as páginas de uma consulta e devolve os itens crus. `info` (opcional) recebe count/truncado."""
    itens: List[dict] = []
    pagina = 1
    total: Optional[int] = None
    truncado = False
    while True:
        d = get_json(URL, {**params, "pagina": pagina, "itensPorPagina": POR_PAGINA}, log=log)
        lote = d.get("items") or []
        if d.get("status") not in (None, "success") and not lote:
            raise ErroHTTP(f"DJEN respondeu {d.get('status')}: {d.get('message')}")
        if total is None:
            total = d.get("count")
        itens.extend(lote)
        if len(lote) < POR_PAGINA:  # `count` da API não é confiável (teto 10000) — o fim é o lote incompleto
            break
        if pagina >= max_paginas:
            truncado = True
            break
        pagina += 1
        time.sleep(0.25)
    if truncado and log:
        log(f"  aviso: consulta DJEN truncada em {len(itens)} itens (count informado: {total})")
    if info is not None:
        info.update({"count": total, "truncado": truncado, "paginas": pagina})
    return itens


def _janela(inicio: Optional[date], fim: Optional[date]) -> dict:
    p = {}
    if inicio:
        p["dataDisponibilizacaoInicio"] = inicio.isoformat()
    if fim:
        p["dataDisponibilizacaoFim"] = fim.isoformat()
    return p


def buscar_por_oab(numero: str, uf: str, inicio: date, fim: date, tribunal: str = "", log=None, info: Optional[dict] = None) -> List[dict]:
    params = {"numeroOab": str(numero).strip(), "ufOab": uf.strip().upper(), **_janela(inicio, fim)}
    if tribunal:
        params["siglaTribunal"] = tribunal
    return buscar(params, log, info=info)


def buscar_por_processo(numero: str, inicio: Optional[date] = None, fim: Optional[date] = None, log=None, info: Optional[dict] = None) -> List[dict]:
    d20 = cnj.normalizar(numero)
    if not d20:
        raise ValueError(f"número CNJ inválido: {numero}")
    return buscar({"numeroProcesso": d20, **_janela(inicio, fim)}, log, info=info)


def buscar_por_parte(nome: str, inicio: date, fim: date, tribunal: str = "", log=None, info: Optional[dict] = None) -> List[dict]:
    params = {"nomeParte": nome.strip(), **_janela(inicio, fim)}
    if tribunal:
        params["siglaTribunal"] = tribunal
    return buscar(params, log, info=info)


def normalizar_item(it: dict) -> dict:
    """Converte o item cru da API num registro estável e limpo para o Radar."""
    proc_digits = cnj.somente_digitos(str(it.get("numero_processo") or "")) or None
    proc = it.get("numeroprocessocommascara") or (cnj.formatar(proc_digits) if proc_digits else "")
    partes = [{"nome": uma_linha(p.get("nome") or ""), "polo": p.get("polo") or ""} for p in it.get("destinatarios") or []]
    advogados = []
    for da in it.get("destinatarioadvogados") or []:
        a = da.get("advogado") or {}
        advogados.append({"nome": uma_linha(a.get("nome") or ""), "oab": str(a.get("numero_oab") or ""), "uf": a.get("uf_oab") or ""})
    status = it.get("status") or ""
    cancelada = (it.get("ativo") is False) or status.upper().startswith("C") or bool(it.get("data_cancelamento"))
    return {
        "id": it.get("id"),
        "hash": it.get("hash") or "",
        "data": it.get("data_disponibilizacao") or "",
        "tribunal": it.get("siglaTribunal") or "",
        "orgao": uma_linha(it.get("nomeOrgao") or ""),
        "tipo": uma_linha(it.get("tipoComunicacao") or ""),
        "documento": uma_linha(it.get("tipoDocumento") or ""),
        "classe": uma_linha(it.get("nomeClasse") or ""),
        "processo": proc,
        "processo_digits": proc_digits,
        "meio": it.get("meio") or "",
        "meio_nome": it.get("meiocompleto") or "",
        "link": it.get("link") or "",
        "texto": limpar_html(it.get("texto") or ""),
        "partes": partes,
        "advogados": advogados,
        "ativo": it.get("ativo"),
        "status": status,
        "cancelada": cancelada,
        "motivo_cancelamento": it.get("motivo_cancelamento"),
    }


def deduplicar(itens: List[dict]) -> List[dict]:
    vistos = set()
    saida = []
    for it in itens:
        k = it.get("id") or it.get("hash")
        if k in vistos:
            continue
        vistos.add(k)
        saida.append(it)
    return saida
