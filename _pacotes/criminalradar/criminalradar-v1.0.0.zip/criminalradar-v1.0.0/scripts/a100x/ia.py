"""Resumo por IA das publicações — usa o Claude Code local (`claude -p`, saída estruturada).

Opcional e não bloqueante: qualquer falha (sem login, sem binário, timeout) só registra no log
e o Radar segue com a triagem determinística.
"""
from __future__ import annotations

import glob
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional

from .marca import M as MARCA
from .texto import truncar, uma_linha

SCHEMA = {
    "type": "object",
    "properties": {
        "itens": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "integer"},
                    "resumo": {"type": "string"},
                    "acao": {"type": "string"},
                    "prazo_dias": {"type": ["integer", "null"]},
                },
                "required": ["id", "resumo", "acao", "prazo_dias"],
            },
        }
    },
    "required": ["itens"],
}

INSTRUCOES = """Você é o assistente de triagem do Radar __NOME__. Vai ler publicações do Diário de Justiça Eletrônico Nacional (DJEN) dirigidas a um(a) __PUBLICO__.

Para CADA publicação abaixo (identificada por [id N]) devolva um objeto com:
- "id": o número N.
- "resumo": UMA frase (até 220 caracteres), em português claro e sem juridiquês, dizendo o que o juízo decidiu ou determinou.
- "acao": o que o advogado precisa fazer (até 120 caracteres). Se nada for exigido, escreva "Apenas ciência".
- "prazo_dias": o número inteiro de dias fixado NO TEXTO para a providência; null se o texto não fixa prazo. NUNCA invente prazo nem deduza de conhecimento geral.

Regras: não cite leis que não estejam no texto; se o texto for só cabeçalho ou estiver truncado, resuma o que há; não inclua nomes de partes no resumo. Responda somente com o JSON no formato pedido."""

_CAMINHOS_COMUNS = ["/opt/homebrew/bin/claude", "/usr/local/bin/claude", "~/.claude/local/claude", "~/.local/bin/claude", "~/.npm-global/bin/claude", "/usr/bin/claude"]
# O app do Claude para computador (aba Code) traz o Claude Code embutido, sem `claude` no PATH — o binário vale igual para `claude -p`.
_APP_DESKTOP = {
    "darwin": ["~/Library/Application Support/Claude/claude-code/*/claude.app/Contents/MacOS/claude"],
    "win32": ["~/AppData/Roaming/Claude/claude-code/*/claude.exe", "~/AppData/Roaming/Claude/claude-code/*/*/claude.exe",
              "~/AppData/Local/Claude/claude-code/*/claude.exe", "~/AppData/Local/Claude/claude-code/*/*/claude.exe"],
    "linux": ["~/.config/Claude/claude-code/*/claude", "~/.config/Claude/claude-code/*/*/claude"],
}


def _versao_pasta(caminho: Path) -> tuple:
    for parte in reversed(caminho.parts):
        if parte and parte[0].isdigit():
            return tuple(int(x) if x.isdigit() else 0 for x in parte.split("."))
    return ()


def claude_do_app_desktop() -> Optional[str]:
    """Binário do Claude Code embutido no app do Claude (a versão mais nova instalada), ou None."""
    plataforma = "linux" if sys.platform.startswith("linux") else sys.platform
    achados = [Path(c) for padrao in _APP_DESKTOP.get(plataforma, []) for c in glob.glob(os.path.expanduser(padrao))]
    achados = [p for p in achados if p.is_file() and os.access(p, os.X_OK)]
    return str(max(achados, key=_versao_pasta)) if achados else None


def encontrar_claude(cfg: Optional[dict] = None) -> Optional[str]:
    cand = [((cfg or {}).get("ia") or {}).get("claude_bin") or "", shutil.which("claude") or "",
            os.environ.get("CLAUDE_CODE_EXECPATH") or ""] + _CAMINHOS_COMUNS
    for c in cand:
        if not c:
            continue
        p = Path(c).expanduser()
        if p.is_file() and os.access(p, os.X_OK):
            return str(p)
    return claude_do_app_desktop()


def _lotes(itens: List[dict], max_itens: int = 20, max_chars: int = 40000):
    lote, tamanho = [], 0
    for it in itens:
        t = len(it.get("texto") or "")
        if lote and (len(lote) >= max_itens or tamanho + min(t, 1500) > max_chars):
            yield lote
            lote, tamanho = [], 0
        lote.append(it)
        tamanho += min(t, 1500)
    if lote:
        yield lote


def _ambiente() -> dict:
    env = dict(os.environ)
    extras = ["/opt/homebrew/bin", "/usr/local/bin", "/usr/bin", "/bin"]
    env["PATH"] = ":".join(dict.fromkeys([p for p in env.get("PATH", "").split(":") if p] + extras))
    return env


def _resumir_lote(binario: str, modelo: str, n: int, lote: List[dict], log) -> tuple:
    """Executa um lote; devolve (dict id->resumo, custo, erro_fatal)."""
    blocos = []
    for it in lote:
        cab = f"[id {it['id']}] {it.get('tipo', '')} — {it.get('documento', '')} — {it.get('tribunal', '')} {it.get('orgao', '')}"
        blocos.append(cab + "\n" + truncar(uma_linha(it.get("texto") or ""), 1500))
    prompt = INSTRUCOES.replace("__NOME__", MARCA["nome"]).replace("__PUBLICO__", MARCA["publico"]) + "\n\n" + "\n\n".join(blocos)
    cmd = [binario, "-p", "--no-session-persistence", "--tools", "", "--model", modelo, "--output-format", "json",
           "--json-schema", json.dumps(SCHEMA), "--setting-sources", ""]
    saida: Dict[int, dict] = {}
    try:
        r = subprocess.run(cmd, input=prompt, capture_output=True, text=True, timeout=240, env=_ambiente())
    except subprocess.TimeoutExpired:
        log(f"  IA: lote {n} estourou o tempo (240s) — pulando")
        return saida, 0.0, False
    except OSError as e:
        log(f"  IA: não consegui executar o claude ({e})")
        return saida, 0.0, True
    if r.returncode != 0 and not r.stdout.strip():
        log(f"  IA: claude saiu com código {r.returncode}: {(r.stderr or '')[:200]}")
        return saida, 0.0, False
    try:
        d = json.loads(r.stdout)
    except json.JSONDecodeError:
        log(f"  IA: resposta não é JSON (lote {n}): {r.stdout[:120]!r}")
        return saida, 0.0, False
    if d.get("is_error"):
        log(f"  IA: {d.get('result')}")
        return saida, 0.0, "login" in str(d.get("result", "")).lower()
    so = d.get("structured_output")
    if not so:
        try:
            so = json.loads(d.get("result") or "{}")
        except json.JSONDecodeError:
            so = {}
    for x in (so or {}).get("itens") or []:
        try:
            saida[int(x["id"])] = {"resumo": uma_linha(x.get("resumo") or ""), "acao": uma_linha(x.get("acao") or ""), "prazo_dias": x.get("prazo_dias")}
        except (KeyError, TypeError, ValueError):
            continue
    log(f"  IA: lote {n} ({len(lote)} publicações) resumido em {int(d.get('duration_ms', 0) / 1000)}s")
    return saida, float(d.get("total_cost_usd") or 0), False


def resumir(itens: List[dict], cfg: dict, log=None, limite: Optional[int] = None, paralelo: int = 3) -> Dict[int, dict]:
    """Devolve {id: {resumo, acao, prazo_dias}} para os itens que a IA conseguiu processar (lotes em paralelo)."""
    from concurrent.futures import ThreadPoolExecutor
    log = log or (lambda s: None)
    binario = encontrar_claude(cfg)
    if not binario:
        log("  IA: `claude` não encontrado — seguindo só com a triagem determinística")
        return {}
    modelo = ((cfg.get("ia") or {}).get("modelo") or "haiku").strip()
    limite = limite or int((cfg.get("ia") or {}).get("max_publicacoes") or 400)
    lotes = list(_lotes(itens[:limite]))
    saida: Dict[int, dict] = {}
    custo = 0.0
    with ThreadPoolExecutor(max_workers=max(1, paralelo)) as ex:
        resultados = list(ex.map(lambda par: _resumir_lote(binario, modelo, par[0], par[1], log), enumerate(lotes, 1)))
    for parcial, c, fatal in resultados:
        saida.update(parcial)
        custo += c
        if fatal:
            break
    if custo:
        log(f"  IA: custo estimado US$ {custo:.3f} (não se aplica a assinaturas)")
    return saida
