"""Motor do Radar (white-label): Advocacia 100X · Radar Processual, CriminalRadar.

Motor determinístico do plugin: coleta no DJEN (Comunica API do CNJ) e na
DataJud (API pública do CNJ), classifica publicações por urgência, estima
prazos (CPC 219/224/231 — cível; CPP 798 — penal), gera o PDF do Radar e envia por e-mail.
Nome, pastas, cores, oferta e perfil de triagem vêm de `marca.py` (marca.json na raiz do plugin).

Só biblioteca padrão do Python 3.9+. Sem dependências externas.
"""
from .marca import M as MARCA, raiz_plugin as _raiz  # noqa: F401

VERSAO_MOTOR = "1.4.0"


def _versao_produto() -> str:
    """Versão do produto = `version` do .claude-plugin/plugin.json (fonte única); sem manifesto, a do motor."""
    import json as _json
    try:
        return str(_json.loads((_raiz() / ".claude-plugin" / "plugin.json").read_text(encoding="utf-8")).get("version") or VERSAO_MOTOR)
    except (OSError, ValueError):
        return VERSAO_MOTOR


VERSAO = _versao_produto()
NOME = MARCA["nome"]
ROTULO = MARCA["rotulo"]  # "Radar Advocacia 100X" / "CriminalRadar"
PRODUTO = MARCA["produto"]
USER_AGENT = f"{MARCA['user_agent']}/{VERSAO} (+{MARCA['site']})"
