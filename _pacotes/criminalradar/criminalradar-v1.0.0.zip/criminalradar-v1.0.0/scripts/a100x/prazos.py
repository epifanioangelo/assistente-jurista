"""Contagem de prazos em dias úteis (CPC 219, 224 §§2-3, 231 VII; Lei 11.419/06 art. 4 §§3-4; recesso CPC 220).

Estimativa CONSERVADORA: só desconta fins de semana, feriados nacionais (Lei 662/49, 6.802/80,
10.607/02, 14.759/23), Sexta-feira Santa e o recesso forense de 20/12 a 20/01. Feriados
estaduais/municipais/forenses locais (Carnaval, Corpus Christi, Dia do Advogado, Dia da Justiça)
NÃO são descontados de propósito — assim a data estimada nunca fica DEPOIS da data real.
"""
from __future__ import annotations

from datetime import date, timedelta
from typing import Iterable, Optional, Set

BASE_LEGAL = "CPC 219, 224 §§2º-3º e 231 VII; Lei 11.419/06 art. 4º §§3º-4º; recesso CPC 220"


def pascoa(ano: int) -> date:
    """Domingo de Páscoa (algoritmo de Meeus/Jones/Butcher)."""
    a = ano % 19
    b, c = divmod(ano, 100)
    d, e = divmod(b, 4)
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = divmod(c, 4)
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    mes = (h + l - 7 * m + 114) // 31
    dia = ((h + l - 7 * m + 114) % 31) + 1
    return date(ano, mes, dia)


def feriados_nacionais(ano: int) -> Set[date]:
    fixos = [(1, 1), (4, 21), (5, 1), (9, 7), (10, 12), (11, 2), (11, 15), (12, 25)]
    if ano >= 2024:
        fixos.append((11, 20))  # Consciência Negra — Lei 14.759/2023
    fer = {date(ano, m, d) for m, d in fixos}
    fer.add(pascoa(ano) - timedelta(days=2))  # Sexta-feira Santa (sem expediente forense em todo o país)
    return fer


def em_recesso(d: date) -> bool:
    """Recesso forense CPC 220: prazos suspensos de 20/12 a 20/01 (inclusive)."""
    return (d.month == 12 and d.day >= 20) or (d.month == 1 and d.day <= 20)


def eh_dia_forense(d: date, extras: Iterable[date] = ()) -> bool:
    """Dia com expediente para PUBLICAÇÃO: não é fim de semana nem feriado (o recesso não impede a publicação)."""
    if d.weekday() >= 5 or d in feriados_nacionais(d.year):
        return False
    return d not in frozenset(extras)


def eh_dia_util(d: date, extras: Iterable[date] = ()) -> bool:
    """Dia em que o PRAZO corre: dia forense fora do recesso (CPC 220)."""
    return eh_dia_forense(d, extras) and not em_recesso(d)


def proximo_dia_util(d: date, extras: Iterable[date] = ()) -> date:
    """Primeiro dia útil ESTRITAMENTE posterior a `d`."""
    extras = frozenset(extras)
    x = d + timedelta(days=1)
    while not eh_dia_util(x, extras):
        x += timedelta(days=1)
    return x


def proximo_dia_forense(d: date, extras: Iterable[date] = ()) -> date:
    extras = frozenset(extras)
    x = d + timedelta(days=1)
    while not eh_dia_forense(x, extras):
        x += timedelta(days=1)
    return x


def dia_util_ou_proximo(d: date, extras: Iterable[date] = ()) -> date:
    return d if eh_dia_util(d, extras) else proximo_dia_util(d, extras)


def contar_prazo(disponibilizacao: date, dias: int, dobro: bool = False, extras: Iterable[date] = ()) -> dict:
    """Publicação = 1º dia útil após a disponibilização; início = 1º dia útil após a publicação;
    o prazo corre em dias úteis (o dia de início conta como o 1º)."""
    if dias <= 0:
        raise ValueError("dias deve ser > 0")
    extras = frozenset(extras)
    # a publicação ocorre no 1º dia forense seguinte (pode cair no recesso); o prazo só começa no 1º dia útil seguinte fora do recesso
    publicacao = proximo_dia_forense(disponibilizacao, extras)
    inicio = proximo_dia_util(publicacao, extras)
    n = dias * 2 if dobro else dias
    fim = inicio
    contados = 1
    while contados < n:
        fim = proximo_dia_util(fim, extras)
        contados += 1
    return {
        "disponibilizacao": disponibilizacao.isoformat(),
        "publicacao": publicacao.isoformat(),
        "inicio": inicio.isoformat(),
        "fim": fim.isoformat(),
        "dias": dias,
        "dias_contados": n,
        "dobro": bool(dobro),
        "base_legal": BASE_LEGAL,
    }


def dias_uteis_entre(inicio: date, fim: date, extras: Iterable[date] = ()) -> int:
    """Dias úteis em (inicio, fim] — positivo se fim > inicio, negativo se fim < inicio."""
    extras = frozenset(extras)
    if fim == inicio:
        return 0
    if fim > inicio:  # dias úteis em (inicio, fim]
        return sum(1 for i in range(1, (fim - inicio).days + 1) if eh_dia_util(inicio + timedelta(days=i), extras))
    # vencido: dias úteis em [fim, inicio) — inclui o dia do vencimento, exclui hoje
    return -sum(1 for i in range((inicio - fim).days) if eh_dia_util(fim + timedelta(days=i), extras))


def formatar_br(d) -> str:
    if not d:
        return "—"
    try:
        if isinstance(d, str):
            d = date.fromisoformat(d[:10])
        return d.strftime("%d/%m/%Y")
    except (ValueError, TypeError, AttributeError):
        return str(d)


# ----------------------------------------------------------------------------- prazos penais (dias corridos)
BASE_LEGAL_PENAL = "CPP 798 (dias corridos; não se computa o dia do começo; vence em sábado/domingo/feriado → 1º dia útil — §3º; Lei 1.408/51 art. 3º); Súm. 310 STF; Lei 11.419/06 art. 4º §§3º-4º"
BASE_RECESSO_PENAL = "recesso 20/12–20/01 suspende o prazo (CPP 798-A, Lei 14.365/22)"
BASE_SEM_RECESSO_PENAL = "recesso NÃO suspende: réu preso / Lei 11.340 / urgência (CPP 798-A I-III)"


def contar_prazo_penal(disponibilizacao: date, dias: int, dobro: bool = False, extras: Iterable[date] = (), suspende_recesso: bool = True) -> dict:
    """Prazo PENAL: publicação = 1º dia forense após a disponibilização; início = 1º dia forense seguinte (dia 1);
    corre em dias CORRIDOS (CPP 798). Recesso de 20/12 a 20/01: SUSPENDE o prazo (CPP 798-A, Lei 14.365/2022), salvo
    réu preso, Lei Maria da Penha e medidas urgentes (`suspende_recesso=False`) — aí o prazo corre também no recesso.
    Se o último dia cair em sábado, domingo ou feriado, prorroga-se ao 1º dia útil (CPP 798 §3º; Lei 1.408/51 art. 3º).
    Estimativa conservadora: a data real nunca é ANTERIOR à estimada (feriados locais não são descontados)."""
    if dias <= 0:
        raise ValueError("dias deve ser > 0")
    extras = frozenset(extras)
    publicacao = proximo_dia_forense(disponibilizacao, extras)
    inicio = proximo_dia_forense(publicacao, extras)
    if suspende_recesso:
        while em_recesso(inicio):  # o prazo só começa a correr fora do recesso
            inicio += timedelta(days=1)
        while not eh_dia_forense(inicio, extras):
            inicio += timedelta(days=1)
    n = dias * 2 if dobro else dias
    fim = inicio
    contados = 1
    while contados < n:
        fim += timedelta(days=1)
        if suspende_recesso and em_recesso(fim):
            continue  # dia de recesso não conta (CPP 798-A)
        contados += 1
    prorrogado = False
    while not eh_dia_forense(fim, extras) or (suspende_recesso and em_recesso(fim)):
        fim += timedelta(days=1)
        prorrogado = True
    return {
        "disponibilizacao": disponibilizacao.isoformat(),
        "publicacao": publicacao.isoformat(),
        "inicio": inicio.isoformat(),
        "fim": fim.isoformat(),
        "dias": dias,
        "dias_contados": n,
        "dobro": bool(dobro),
        "corrido": True,
        "prorrogado": prorrogado,
        "recesso_suspende": bool(suspende_recesso),
        "base_legal": BASE_LEGAL_PENAL + "; " + (BASE_RECESSO_PENAL if suspende_recesso else BASE_SEM_RECESSO_PENAL),
    }


def dias_corridos_entre(inicio: date, fim: date) -> int:
    """Dias de calendário de `inicio` até `fim` (negativo se vencido)."""
    return (fim - inicio).days


def dias_restantes(hoje: date, prazo: Optional[dict], extras: Iterable[date] = ()) -> Optional[int]:
    """Dias que faltam para o fim do prazo: corridos se o prazo é penal, úteis se cível."""
    if not prazo or not prazo.get("fim"):
        return None
    try:
        fim = date.fromisoformat(str(prazo["fim"])[:10])
    except ValueError:
        return None
    return dias_corridos_entre(hoje, fim) if prazo.get("corrido") else dias_uteis_entre(hoje, fim, extras)
