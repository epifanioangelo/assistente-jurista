"""Configuração do Radar: ~/<marca.pasta_home>/config.json (ou $<marca.env_home>)."""
from __future__ import annotations

import json
import os
import stat
from copy import deepcopy
from pathlib import Path

from .marca import M as MARCA
from typing import Any, List


PADRAO: dict = {
    "versao": 1,
    "escritorio": {"nome": "", "responsavel": ""},
    # [{"numero": "123456", "uf": "SP", "nome": "Dra. Fulana", "clientes": [...], "adversarios": [...]}]  (opcionais — ajudam a saber nosso polo quando o texto não traz a OAB; o Radar também aprende sozinho)
    "oabs": [],
    # [{"numero": "0000000-00.0000.0.00.0000", "apelido": "", "cliente": ""}]
    "processos": [],
    # [{"nome": "NOME DA PARTE", "tribunal": "TJSP"}]  (opcional — busca por nome de parte)
    "partes": [],
    "email": {
        # provedor: "gmail-conector" (padrão — conector do Gmail no claude.ai, sem senha; relatório completo no e-mail)
        # ou "smtp" (avançado: servidor próprio com senha de app; PDF anexado)
        "provedor": "gmail-conector",
        "conector_tool": "mcp__claude_ai_Gmail__send_message",
        # pdf_via (só no modo gmail-conector): "local" (caminho no e-mail) ou "drive" (PDF na pasta sincronizada do Google Drive
        # para desktop; o job compartilha só com os destinatários e manda o link)
        "pdf_via": "local",
        "destinatarios": [],
        "remetente": "",
        "nome_remetente": MARCA["rotulo"],
        "smtp": {"host": "", "porta": 587, "usuario": "", "senha": "", "seguranca": "starttls"},
        "enviar_quando_vazio": True,
        "avisar_falhas": True,
    },
    "agenda": {"hora": "07:30", "dias": "uteis"},
    "busca": {
        "dias_retroativos": 3,
        "primeira_vez_dias": 7,
        "tribunais": [],
        "consultar_datajud": True,
        "datajud_processos_das_publicacoes": True,
        "max_processos_datajud": 120,
        "ignorar_editais": False,
    },
    "prazos": {"dobro": False, "motivo_dobro": "", "alerta_dias_uteis": 5,
               # perfil: "auto" (detecta publicação penal e conta em dias corridos — CPP 798), "civel" (sempre dias úteis) ou "criminal" (sempre penal)
               # papel (só penal): "defesa" | "acusacao" | "misto" — desempata o polo quando o texto não diz de que lado estamos
               # intimacao_pessoal (penal): true para Defensoria, MP, dativo e núcleo de prática jurídica — o DJEN é só informativo; o prazo conta da intimação pessoal/Domicílio Eletrônico
               "perfil": "auto", "papel": "", "intimacao_pessoal": False},
    "andamento": {"dias_atencao": 30, "dias_gargalo": 60},
    "ia": {"ativa": True, "modelo": "haiku", "claude_bin": "", "max_publicacoes": 400},
    "datajud": {"api_key": ""},
    # nuvem: "nenhum" (padrão — PDF fica no computador; o e-mail traz o relatório completo) | "drive-doc" | "drive-sync" (opcionais)
    # encarte: oferta institucional da marca no fim do PDF/e-mail (alias antigo: encarte_acelerador)
    "relatorios": {"pasta": "", "manter_dias": 365, "encarte": True, "encarte_versao": "auto", "pasta_drive": "", "nuvem": "nenhum"},
    "catch_up_ao_abrir": True,
}


def _env(sufixo: str) -> str:
    """Variável de ambiente da marca (<PREFIXO>_<sufixo>), com A100X_<sufixo> como compatibilidade."""
    return os.environ.get(f"{MARCA.get('env_prefixo', 'A100X')}_{sufixo}") or os.environ.get(f"A100X_{sufixo}") or ""


def base_dir() -> Path:
    return Path(os.environ.get(MARCA["env_home"]) or (Path.home() / MARCA["pasta_home"])).expanduser()


def caminho_config() -> Path:
    return base_dir() / "config.json"


def pasta_relatorios(cfg: dict) -> Path:
    p = (cfg.get("relatorios") or {}).get("pasta") or ""
    return Path(p).expanduser() if p else base_dir() / "relatorios"


def pasta_logs() -> Path:
    return base_dir() / "logs"


def _mesclar(padrao: Any, valor: Any) -> Any:
    """Mescla recursivamente `valor` sobre `padrao` (dicts); listas/escalares substituem."""
    if isinstance(padrao, dict) and isinstance(valor, dict):
        saida = deepcopy(padrao)
        for k, v in valor.items():
            saida[k] = _mesclar(padrao.get(k), v) if k in padrao else deepcopy(v)
        return saida
    return deepcopy(valor) if valor is not None else deepcopy(padrao)


def carregar() -> dict:
    """Carrega a configuração mesclada com os padrões. `_existe` indica se o arquivo existe."""
    arq = caminho_config()
    if not arq.exists():
        cfg = deepcopy(PADRAO)
        cfg["_existe"] = False
        return cfg
    try:
        dados = json.loads(arq.read_text(encoding="utf-8") or "{}")
    except json.JSONDecodeError as e:
        raise ValueError(f"config.json inválido ({arq}): {e}") from e
    cfg = _mesclar(PADRAO, dados)
    cfg["_existe"] = True
    return cfg


def salvar(cfg: dict) -> Path:
    cfg = {k: v for k, v in cfg.items() if not k.startswith("_")}
    d = base_dir()
    d.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(d, stat.S_IRWXU)
    except OSError:
        pass
    arq = caminho_config()
    tmp = arq.with_suffix(".json.tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)  # já nasce 0600 (a senha SMTP pode estar aqui)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(json.dumps(cfg, ensure_ascii=False, indent=2) + "\n")
    os.replace(tmp, arq)
    try:
        os.chmod(arq, stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass
    return arq


def senha_smtp(cfg: dict) -> str:
    """Senha SMTP: variável <PREFIXO>_SMTP_SENHA > arquivo smtp_senha > config.json."""
    env = _env("SMTP_SENHA")
    if env:
        return env.strip()
    arq = base_dir() / "smtp_senha"
    if arq.exists():
        return arq.read_text(encoding="utf-8").strip()
    return ((cfg.get("email") or {}).get("smtp") or {}).get("senha") or ""


def chave_datajud(cfg: dict) -> str:
    from .datajud import CHAVE_PUBLICA
    return _env("DATAJUD_KEY") or (cfg.get("datajud") or {}).get("api_key") or CHAVE_PUBLICA


def _coagir(padrao: Any, valor: Any) -> Any:
    """Converte string vinda da CLI para o tipo do valor padrão."""
    if isinstance(valor, str):
        v = valor.strip()
        if isinstance(padrao, bool):
            if v.lower() in ("1", "true", "sim", "yes", "on", "verdadeiro"):
                return True
            if v.lower() in ("0", "false", "nao", "não", "no", "off", "falso", ""):
                return False
            raise ValueError(f"valor booleano inválido: {valor!r}")
        if isinstance(padrao, int) and not isinstance(padrao, bool):
            return int(v)
        if isinstance(padrao, list):
            if v.startswith("["):
                return json.loads(v)
            return [x.strip() for x in v.split(",") if x.strip()]
        if isinstance(padrao, dict):
            return json.loads(v)
    return valor


def definir(cfg: dict, caminho: str, valor: Any) -> dict:
    """Define `cfg[a][b][c] = valor` a partir de "a.b.c", coagindo o tipo pelo padrão."""
    partes = caminho.split(".")
    ref_padrao: Any = PADRAO
    ref: Any = cfg
    for p in partes[:-1]:
        if not isinstance(ref, dict):
            raise KeyError(caminho)
        ref = ref.setdefault(p, {})
        ref_padrao = ref_padrao.get(p, {}) if isinstance(ref_padrao, dict) else {}
    ultimo = partes[-1]
    if caminho in ("oabs", "processos", "partes"):
        raise ValueError(f"'{caminho}' não se edita com --set: use `{MARCA['cli']} {'oab' if caminho == 'oabs' else caminho} add …`")
    padrao = ref_padrao.get(ultimo) if isinstance(ref_padrao, dict) else None
    if padrao is None and ultimo not in (ref if isinstance(ref, dict) else {}):
        raise KeyError(f"chave desconhecida: {caminho}")
    ref[ultimo] = _coagir(padrao, valor)
    return cfg


def obter(cfg: dict, caminho: str, padrao: Any = None) -> Any:
    ref: Any = cfg
    for p in caminho.split("."):
        if not isinstance(ref, dict) or p not in ref:
            return padrao
        ref = ref[p]
    return ref


def mascarar(cfg: dict) -> dict:
    """Cópia para exibição, sem segredos."""
    c = deepcopy({k: v for k, v in cfg.items() if not k.startswith("_")})
    smtp = (c.get("email") or {}).get("smtp") or {}
    if smtp.get("senha"):
        smtp["senha"] = "••••••••"
    if (c.get("datajud") or {}).get("api_key"):
        c["datajud"]["api_key"] = "••••••••"
    return c


def validar(cfg: dict) -> List[str]:
    """Lista de problemas que impedem (ou degradam) a execução."""
    problemas: List[str] = []
    if not cfg.get("oabs") and not cfg.get("processos") and not cfg.get("partes"):
        problemas.append("Cadastre ao menos uma OAB, um processo ou uma parte para monitorar.")
    for o in cfg.get("oabs") or []:
        if not isinstance(o, dict) or not str(o.get("numero", "")).strip().isdigit() or len(str(o.get("uf", ""))) != 2:
            problemas.append(f"OAB inválida: {o!r} (use numero somente com dígitos e UF com 2 letras).")
    from . import cnj as _cnj
    for pr in cfg.get("processos") or []:
        if not isinstance(pr, dict) or not _cnj.normalizar(str(pr.get("numero", ""))):
            problemas.append(f"Processo inválido: {pr!r} (número CNJ NNNNNNN-DD.AAAA.J.TR.OOOO).")
    for pt in cfg.get("partes") or []:
        if not isinstance(pt, dict) or not str(pt.get("nome", "")).strip():
            problemas.append(f"Parte inválida: {pt!r} (informe o nome).")
    email = cfg.get("email") or {}
    dest = email.get("destinatarios")
    if isinstance(dest, str):
        dest = [d.strip() for d in dest.split(",") if d.strip()]
        email["destinatarios"] = dest
    if not dest or not isinstance(dest, list) or not all(isinstance(d, str) and "@" in d for d in dest):
        problemas.append("Destinatários de e-mail ausentes ou inválidos (email.destinatarios — lista de endereços).")
    smtp = email.get("smtp") or {}
    provedor = (email.get("provedor") or "smtp").lower()
    if provedor not in ("smtp", "gmail-conector"):
        problemas.append(f"email.provedor inválido: {provedor!r} (use smtp ou gmail-conector).")
    if provedor == "gmail-conector" and (email.get("pdf_via") or "local") == "drive" and str((cfg.get("relatorios") or {}).get("nuvem")) == "drive-sync":
        from .email_conector import pasta_drive
        if not pasta_drive(cfg):
            problemas.append("email.pdf_via=drive exige o Google Drive para desktop (pasta 'My Drive' não encontrada) ou relatorios.pasta_drive.")
    if provedor == "smtp":
        if not smtp.get("host"):
            problemas.append("Servidor SMTP não configurado (email.smtp.host) — ou use email.provedor=gmail-conector.")
        try:
            int(smtp.get("porta") or 0)
        except (TypeError, ValueError):
            problemas.append(f"email.smtp.porta inválida: {smtp.get('porta')!r}")
        if smtp.get("usuario") and not senha_smtp(cfg):
            problemas.append(f"Senha SMTP ausente (email.smtp.senha, arquivo smtp_senha ou variável {MARCA.get('env_prefixo', 'A100X')}_SMTP_SENHA).")
    if smtp.get("seguranca") not in ("starttls", "ssl", "nenhuma"):
        problemas.append("email.smtp.seguranca deve ser starttls, ssl ou nenhuma.")
    hora = (cfg.get("agenda") or {}).get("hora", "")
    if not _hora_valida(hora):
        problemas.append(f"agenda.hora inválida: {hora!r} (use HH:MM).")
    pz = cfg.get("prazos") or {}
    if str(pz.get("perfil") or "auto").lower() not in ("auto", "civel", "criminal"):
        problemas.append(f"prazos.perfil inválido: {pz.get('perfil')!r} (use auto, civel ou criminal).")
    if str(pz.get("papel") or "").lower() not in ("", "defesa", "acusacao", "misto"):
        problemas.append(f"prazos.papel inválido: {pz.get('papel')!r} (use defesa, acusacao ou misto).")
    return problemas


def _hora_valida(h: str) -> bool:
    try:
        hh, mm = h.split(":")
        return 0 <= int(hh) <= 23 and 0 <= int(mm) <= 59
    except Exception:
        return False
