"""Cliente da API Pública DataJud (CNJ — Res. 331/2020).

POST https://api-publica.datajud.cnj.jus.br/api_publica_<alias>/_search  (Elasticsearch)
Header: Authorization: APIKey <chave pública publicada em datajud-wiki.cnj.jus.br/api-publica/acesso>
Não há busca por OAB — só por número de processo (e outros campos do processo).
Cobertura: 91 índices (STJ, TST, TSE, STM, TRF1-6, TRT1-24, TRE-xx, TJxx, TJM). STF não está na DataJud.
"""
from __future__ import annotations

import re
from datetime import date, datetime
from typing import List, Optional

from . import cnj
from .http import ErroHTTP, post_json
from .texto import chave, uma_linha

URL = "https://api-publica.datajud.cnj.jus.br/api_publica_{alias}/_search"
# Chave PÚBLICA oficial (o CNJ a publica abertamente e pode trocá-la; sobrescreva em datajud.api_key).
CHAVE_PUBLICA = "cDZHYzlZa0JadVREZDJCendQbXY6SkJlTzNjLV9TRENyQk1RdnFKZGRQdw=="


def _data(s) -> Optional[date]:
    if not s:
        return None
    s = str(s)
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})", s) or re.match(r"^(\d{4})(\d{2})(\d{2})", s)
    if m:
        try:
            return date(int(m[1]), int(m[2]), int(m[3]))
        except ValueError:
            return None
    return None


def _ordem(s) -> str:
    """Chave de ordenação completa (data+hora) — a API não garante ordem dentro do mesmo dia."""
    s = re.sub(r"\D", "", str(s or ""))
    return s.ljust(14, "0")[:14]


def _datahora(s) -> str:
    d = _data(s)
    return d.isoformat() if d else ""


def consultar(numero: str, chave_api: str = CHAVE_PUBLICA, log=None, hoje: Optional[date] = None,
              cfg_andamento: Optional[dict] = None) -> dict:
    hoje = hoje or date.today()
    d20 = cnj.normalizar(numero)
    base = {"numero": cnj.formatar(d20) if d20 else numero, "numero_digits": d20, "encontrado": False,
            "alias": None, "tribunal": cnj.sigla_tribunal(d20) if d20 else "?", "erro": None}
    if not d20:
        base["erro"] = "número CNJ inválido"
        return base
    alias = cnj.alias_datajud(d20)
    base["alias"] = alias
    if not alias:
        base["erro"] = f"{base['tribunal']} não está na DataJud (consulte o portal do tribunal)"
        return base
    payload = {"query": {"match": {"numeroProcesso": d20}}, "size": 10}
    try:
        resp = post_json(URL.format(alias=alias), payload, {"Authorization": f"APIKey {chave_api}"}, log=log)
    except (ErroHTTP, ValueError) as e:
        base["erro"] = f"DataJud indisponível: {e}"
        return base
    hits = ((resp.get("hits") or {}).get("hits")) or []
    if not hits:
        base["erro"] = "processo não localizado na DataJud (sigilo, processo físico ou ainda não sincronizado)"
        return base

    instancias = []
    for h in hits:
        s = h.get("_source") or {}
        movs = []
        for m in s.get("movimentos") or []:
            compl = []
            for c in m.get("complementosTabelados") or []:
                if not isinstance(c, dict):
                    continue
                rotulo = uma_linha(str(c.get("descricao") or "").replace("_", " "))
                valor = uma_linha(str(c.get("nome") or ""))
                if valor:
                    compl.append(f"{rotulo}: {valor}" if rotulo else valor)
            movs.append({"data": _datahora(m.get("dataHora")), "_ordem": _ordem(m.get("dataHora")), "codigo": m.get("codigo"), "nome": uma_linha(m.get("nome") or ""), "complementos": compl})
        movs.sort(key=lambda x: x["_ordem"])
        instancias.append({
            "grau": s.get("grau") or "",
            "classe": uma_linha((s.get("classe") or {}).get("nome") or ""),
            "orgao": uma_linha((s.get("orgaoJulgador") or {}).get("nome") or ""),
            "sistema": uma_linha((s.get("sistema") or {}).get("nome") or ""),
            "formato": uma_linha((s.get("formato") or {}).get("nome") or ""),
            "assuntos": [uma_linha(a.get("nome") or "") for a in (s.get("assuntos") or []) if isinstance(a, dict) and a.get("nome")],
            "ajuizamento": _datahora(s.get("dataAjuizamento")),
            "atualizado_em": _datahora(s.get("dataHoraUltimaAtualizacao")),
            "nivel_sigilo": s.get("nivelSigilo"),
            "movimentos": movs,
        })

    # instância "principal" = a que tem o movimento mais recente
    def ult(i):
        return i["movimentos"][-1]["_ordem"] if i["movimentos"] else ""
    instancias.sort(key=ult, reverse=True)
    principal = instancias[0]
    todos = sorted((m for i in instancias for m in i["movimentos"]), key=lambda m: m["_ordem"])
    ultimo = todos[-1] if todos else None
    atualizado = max((i["atualizado_em"] for i in instancias if i["atualizado_em"]), default="")
    dias_parado = (hoje - date.fromisoformat(ultimo["data"])).days if ultimo and ultimo["data"] else None
    defasagem = (hoje - date.fromisoformat(atualizado)).days if atualizado else None
    status, proximo, alerta = classificar_andamento(todos, hoje, dias_parado, defasagem, cfg_andamento or {})
    base.update({
        "encontrado": True,
        "grau": principal["grau"],
        "classe": principal["classe"],
        "orgao": principal["orgao"],
        "sistema": principal["sistema"],
        "assuntos": principal["assuntos"],
        "ajuizamento": principal["ajuizamento"],
        "atualizado_em": atualizado,
        "defasagem_dias": defasagem,
        "instancias": [{k: v for k, v in i.items() if k != "movimentos"} | {"n_movimentos": len(i["movimentos"])} for i in instancias],
        "ultimo_movimento": ultimo,
        "ultimos_movimentos": todos[-8:][::-1],
        "n_movimentos": len(todos),
        "dias_parado": dias_parado,
        "status": status,
        "proximo_ato": proximo,
        "alerta": alerta,
        "link_consulta": f"https://www.cnj.jus.br/sgt/consulta_publica_movimentos.php",
    })
    return base


# ---------------------------------------------------------------------------
# Taxonomia de status (nomes da Tabela Processual Unificada — TPU/SGT do CNJ)
# ---------------------------------------------------------------------------
_REGRAS_STATUS = [
    # (regex sobre o nome canônico do movimento, status, próximo ato esperado)
    (r"baixa definitiva|arquivad[oa] definitiv|transit\w* em julgado|\bdefinitivo\b", "BAIXADO / ARQUIVADO", "Nenhum — verificar necessidade de desarquivamento ou cumprimento residual"),
    (r"arquivad[oa] provisori|arquivamento provisorio", "ARQUIVADO PROVISORIAMENTE", "Verificar motivo (suspensão art. 921, prescrição intercorrente) e prazo de retorno"),
    (r"suspens|sobrestad|sobrestamento", "SUSPENSO / SOBRESTADO", "Verificar motivo (tema repetitivo, convenção, CPC 313) e prazo de retorno"),
    (r"conclus.*(sentenca|julgamento)", "CONCLUSO PARA SENTENÇA", "Sentença — acompanhar; > 60 dias: cobrar (CPC 226 III)"),
    (r"conclus", "CONCLUSO PARA DESPACHO/DECISÃO", "Despacho ou decisão — acompanhar; > 60 dias: cobrar (CPC 226)"),
    (r"julgad[oa] procedente|julgad[oa] improcedente|procedencia|improcedencia|extincao|extinto|homologa|sentenca", "SENTENCIADO", "Verificar intimação e prazo recursal (15 dias úteis — CPC 1.003 §5º)"),
    (r"acordao|julgamento colegiado|provimento|desprovimento|nao conhecid", "JULGADO EM 2º GRAU", "Verificar publicação do acórdão e cabimento de ED/REsp/RE"),
    (r"remetid[oa]s? (ao|para).*(tribunal|turma|instancia|grau)|remessa.*(tribunal|turma|instancia|grau)|recurso|apelacao|agravo", "EM RECURSO", "Acompanhar distribuição/julgamento no tribunal"),
    (r"cumprimento de sentenca|execucao|penhora|bloqueio|sisbajud|bacenjud|renajud|infojud|leilao|hasta", "EM EXECUÇÃO", "Acompanhar constrição; > 30 dias parado: pedir novas pesquisas patrimoniais"),
    (r"audiencia", "EM AUDIÊNCIA", "Preparar audiência (partes, testemunhas, preposto) ou aguardar ata"),
    (r"citacao|citad[oa]|mandado", "AGUARDANDO CITAÇÃO/DILIGÊNCIA", "Aguardar retorno do AR/oficial; > 30 dias: cobrar nova diligência"),
    (r"contestacao|defesa apresentada", "AGUARDANDO RÉPLICA / SANEAMENTO", "Réplica em 15 dias úteis (CPC 350) e especificação de provas"),
    (r"distribui", "AGUARDANDO DESPACHO INICIAL", "Despacho inicial (cite-se / emende-se)"),
    (r"publicacao|disponibilizacao|intimacao", "PRAZO EM CURSO", "Verificar a intimação publicada e o prazo correspondente"),
    (r"peticao|juntada|documento|certidao", "EM ANDAMENTO", "Aguardar apreciação da última petição/juntada"),
]


def classificar_andamento(movs_ordenados: List[dict], hoje: date, dias_parado: Optional[int], defasagem: Optional[int], cfg: dict):
    dias_atencao = int(cfg.get("dias_atencao", 30) or 30)
    dias_gargalo = int(cfg.get("dias_gargalo", 60) or 60)
    status, proximo = "EM ANDAMENTO", "Verificar manualmente"
    # olha os últimos 5 movimentos, do mais recente ao mais antigo; regras de encerramento têm prioridade
    recentes = [chave((m.get("nome") or "") + " " + " ".join(m.get("complementos") or [])) for m in movs_ordenados[-5:][::-1]]
    if recentes:
        for regex, st, prox in _REGRAS_STATUS:
            if re.search(regex, recentes[0]):
                status, proximo = st, prox
                break
        else:
            for regex, st, prox in _REGRAS_STATUS[:2]:
                if any(re.search(regex, r) for r in recentes):
                    status, proximo = st, prox
                    break
    alerta = {"nivel": "NORMAL", "mensagem": ""}
    if status == "BAIXADO / ARQUIVADO":
        alerta = {"nivel": "NORMAL", "mensagem": "Encerrado/arquivado"}
    elif dias_parado is None:
        alerta = {"nivel": "VERIFICAR", "mensagem": "Sem movimentos na DataJud"}
    elif dias_parado > dias_gargalo:
        alerta = {"nivel": "GARGALO", "mensagem": f"Sem movimento há {dias_parado} dias (> {dias_gargalo})"}
    elif dias_parado > dias_atencao:
        alerta = {"nivel": "ATENCAO", "mensagem": f"Sem movimento há {dias_parado} dias (> {dias_atencao})"}
    if defasagem is not None and defasagem > dias_atencao and alerta["nivel"] in ("GARGALO", "ATENCAO"):
        alerta["mensagem"] += f" — DataJud sincronizada há {defasagem} dias: confirme no sistema do tribunal"
    if status == "SUSPENSO / SOBRESTADO" and alerta["nivel"] == "NORMAL":
        alerta = {"nivel": "VERIFICAR", "mensagem": "Suspenso — confirmar motivo e retorno"}
    return status, proximo, alerta
