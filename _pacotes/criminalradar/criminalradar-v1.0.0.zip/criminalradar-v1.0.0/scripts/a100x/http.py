"""HTTP com retry/backoff, só urllib (stdlib)."""
from __future__ import annotations

import http.client
import json
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Optional, Tuple

from . import USER_AGENT


class ErroHTTP(Exception):
    def __init__(self, msg: str, status: Optional[int] = None, corpo: str = ""):
        super().__init__(msg)
        self.status = status
        self.corpo = corpo


def _contexto_ssl() -> ssl.SSLContext:
    return ssl.create_default_context()


def requisicao(url: str, metodo: str = "GET", dados: Optional[bytes] = None, cabecalhos: Optional[dict] = None,
               timeout: int = 40, tentativas: int = 3, espera: float = 1.5, log=None) -> Tuple[int, bytes]:
    cab = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    cab.update(cabecalhos or {})
    ultimo: Optional[Exception] = None
    for i in range(1, tentativas + 1):
        req = urllib.request.Request(url, data=dados, headers=cab, method=metodo)
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=_contexto_ssl()) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e:
            corpo = ""
            try:
                corpo = e.read().decode("utf-8", "replace")[:500]
            except Exception:
                pass
            ultimo = ErroHTTP(f"HTTP {e.code} em {metodo} {url}: {corpo[:200]}", e.code, corpo)
            if e.code in (400, 401, 403, 404, 422):
                raise ultimo
        except (urllib.error.URLError, http.client.HTTPException, TimeoutError, ConnectionError, OSError) as e:
            ultimo = ErroHTTP(f"falha de rede em {metodo} {url}: {e}")
        if i < tentativas:
            pausa = espera * (2 ** (i - 1))
            if log:
                log(f"  tentativa {i}/{tentativas} falhou ({ultimo}); nova tentativa em {pausa:.0f}s")
            time.sleep(pausa)
    raise ultimo or ErroHTTP(f"falha desconhecida em {metodo} {url}")


def get_json(url: str, params: Optional[dict] = None, **kw) -> dict:
    if params:
        url = url + ("&" if "?" in url else "?") + urllib.parse.urlencode({k: v for k, v in params.items() if v not in (None, "")})
    _, corpo = requisicao(url, "GET", **kw)
    return _json(corpo, url)


def post_json(url: str, payload: dict, cabecalhos: Optional[dict] = None, **kw) -> dict:
    cab = {"Content-Type": "application/json"}
    cab.update(cabecalhos or {})
    _, corpo = requisicao(url, "POST", json.dumps(payload).encode("utf-8"), cab, **kw)
    return _json(corpo, url)


def _json(corpo: bytes, url: str) -> dict:
    txt = corpo.decode("utf-8", "replace") or "{}"
    try:
        d = json.loads(txt)
    except json.JSONDecodeError as e:
        raise ErroHTTP(f"resposta não é JSON em {url}: {txt[:120]!r}", None, txt[:500]) from e
    if not isinstance(d, dict):
        raise ErroHTTP(f"resposta JSON inesperada em {url} ({type(d).__name__})", None, txt[:500])
    return d
