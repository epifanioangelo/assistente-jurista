"""Número único CNJ (Res. CNJ 65/2008): NNNNNNN-DD.AAAA.J.TR.OOOO — parse, validação e alias DataJud."""
from __future__ import annotations

import re
from typing import Optional

UF_POR_TR = {
    "01": "ac", "02": "al", "03": "ap", "04": "am", "05": "ba", "06": "ce", "07": "df",
    "08": "es", "09": "go", "10": "ma", "11": "mt", "12": "ms", "13": "mg", "14": "pa",
    "15": "pb", "16": "pr", "17": "pe", "18": "pi", "19": "rj", "20": "rn", "21": "rs",
    "22": "ro", "23": "rr", "24": "sc", "25": "se", "26": "sp", "27": "to",
}
JUSTICA = {
    "1": "Supremo Tribunal Federal", "2": "Conselho Nacional de Justiça", "3": "Superior Tribunal de Justiça",
    "4": "Justiça Federal", "5": "Justiça do Trabalho", "6": "Justiça Eleitoral",
    "7": "Justiça Militar da União", "8": "Justiça Estadual", "9": "Justiça Militar Estadual",
}

_RE_PARTES = re.compile(r"^\s*(\d{1,7})\s*-?\s*(\d{2})\s*\.?\s*(\d{4})\s*\.?\s*(\d)\s*\.?\s*(\d{2})\s*\.?\s*(\d{4})\s*$")


def somente_digitos(s: str) -> str:
    return re.sub(r"\D", "", s or "")


def normalizar(numero: str) -> Optional[str]:
    """Devolve os 20 dígitos do número CNJ (ou None se não parecer um número CNJ)."""
    if not numero:
        return None
    m = _RE_PARTES.match(numero)
    if m:
        seq, dv, ano, j, tr, oo = m.groups()
        return f"{seq.zfill(7)}{dv}{ano}{j}{tr}{oo}"
    d = somente_digitos(numero)
    if len(d) == 20:
        return d
    if 14 <= len(d) < 20:  # sequencial sem zeros à esquerda, colado
        return d.zfill(20)
    return None


def formatar(d20: str) -> str:
    d = normalizar(d20) or somente_digitos(d20)
    if len(d) != 20:
        return d20
    return f"{d[0:7]}-{d[7:9]}.{d[9:13]}.{d[13]}.{d[14:16]}.{d[16:20]}"


def digito_valido(d20: str) -> bool:
    d = normalizar(d20)
    if not d:
        return False
    seq, dv, ano, j, tr, oo = d[0:7], d[7:9], d[9:13], d[13], d[14:16], d[16:20]
    calc = 98 - (int(f"{seq}{ano}{j}{tr}{oo}00") % 97)
    return calc == int(dv)


def componentes(d20: str) -> dict:
    d = normalizar(d20) or ""
    if len(d) != 20:
        return {}
    return {"sequencial": d[0:7], "dv": d[7:9], "ano": int(d[9:13]), "justica": d[13], "tribunal": d[14:16], "origem": d[16:20]}


def alias_datajud(d20: str) -> Optional[str]:
    """Alias do índice DataJud (api_publica_<alias>) a partir do número. None = fora da DataJud (ex.: STF)."""
    c = componentes(d20)
    if not c:
        return None
    j, tr = c["justica"], c["tribunal"]
    try:
        n = int(tr)
    except ValueError:
        return None
    if j == "3":
        return "stj"
    if j == "4":
        return f"trf{n}" if 1 <= n <= 6 else None
    if j == "5":
        if tr in ("00", "90"):  # 00 = TST (originário); 90 = CSJT — ambos atendidos pelo índice do TST
            return "tst"
        return f"trt{n}" if 1 <= n <= 24 else None
    if j == "6":
        if tr == "00":
            return "tse"
        uf = UF_POR_TR.get(tr)
        return ("tre-dft" if uf == "df" else f"tre-{uf}") if uf else None
    if j == "7":
        return "stm"
    if j == "8":
        uf = UF_POR_TR.get(tr)
        return ("tjdft" if uf == "df" else f"tj{uf}") if uf else None
    if j == "9":
        return {"13": "tjmmg", "21": "tjmrs", "26": "tjmsp"}.get(tr)
    return None  # STF (1) e CNJ (2) não estão na DataJud


def sigla_tribunal(d20: str) -> str:
    a = alias_datajud(d20)
    if a:
        return a.upper()
    c = componentes(d20)
    if c and c["justica"] == "1":
        return "STF"
    if c and c["justica"] == "2":
        return "CNJ"
    return "?"


def descrever(d20: str) -> str:
    c = componentes(d20)
    if not c:
        return "número inválido"
    return f"{JUSTICA.get(c['justica'], 'Justiça ?')} — {sigla_tribunal(d20)} — autuado em {c['ano']}"
