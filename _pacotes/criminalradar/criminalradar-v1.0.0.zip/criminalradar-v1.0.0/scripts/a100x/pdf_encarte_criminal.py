"""Encarte institucional (2 páginas) ao final do CriminalRadar: o Núcleo de Prática Criminal com o Claude (tecnologia Criminal Squad).

Mesma estrutura do `pdf_encarte.py` (Advocacia 100X), com a narrativa da masterclass "A era da orquestração criminal":
o operador criminal 10X, as quatro eras, Executor × Promptador × Orquestrador, os quatro níveis, a arquitetura do
Criminal Squad, os squads, as cinco leis e a oferta do Núcleo. Nenhum preço aparece aqui, por regra.
"""
from __future__ import annotations

from typing import List, Tuple
from urllib.parse import quote

from .marca import M as _MARCA
from .pdf import PDF, hexcor, largura_texto, quebrar

C = {
    "preto": hexcor("#111010"), "bordo": hexcor("#7E1F2D"), "dourado": hexcor("#C6A15B"), "areia": hexcor("#DED6CE"),
    "cinza": hexcor("#8D8580"), "creme": hexcor("#FBF8F3"), "vermelho": hexcor("#A32F42"), "verde": hexcor("#1E8E5A"),
    "whats": hexcor("#25D366"), "branco": (1.0, 1.0, 1.0), "caixa": (1.0, 1.0, 1.0),
    "gate": hexcor("#F6E9EB"), "gate_borda": hexcor("#D9AEB5"), "humano": hexcor("#E6F4EA"), "humano_borda": hexcor("#A9D8BC"),
    "reprova_fundo": hexcor("#FBE9EC"), "reprova_borda": hexcor("#E4B4BC"),
    "faixa_sub": hexcor("#E8E2DA"), "faixa_linha": hexcor("#B8B0A8"), "faixa_eyebrow": hexcor("#C6A15B"),
}
MARGEM = 40.0
WHATSAPP_NUM = str(_MARCA.get("whatsapp") or "5581988440860")  # número/URL vêm do marca.json
WHATSAPP_FMT = str(_MARCA.get("whatsapp_fmt") or "(81) 98844-0860")
WHATSAPP_MSG = "Olá, recebi o CriminalRadar e quero conhecer o Núcleo de Prática Criminal com o Claude."
WHATSAPP_URL = str(_MARCA.get("whatsapp_url") or f"https://wa.me/{WHATSAPP_NUM}")

_EYEBROW = "CRIMINALRADAR  ·  NÚCLEO DE PRÁTICA CRIMINAL COM O CLAUDE  ·  NÍVEL {n}"

VERSOES = {
    1: {  # consciente do problema — executa todas as etapas sozinho: autos, prova, prazos, audiência
        "eyebrow": _EYEBROW.format(n=1),
        "titulo": "O problema nunca foi competência. É tempo.",
        "sub1": "Um cérebro. Dez funções. E todas disputam",
        "sub2": "as mesmas horas do operador criminal.",
        "linha": "Quatro pressões comprimem a rotina: falta de tempo · prazos curtos · excesso de trabalho · falta de mão de obra.",
        "intro": "Localizar documentos, identificar a fase e o prazo, ler os autos, construir a cronologia, separar provas, pesquisar fontes, comparar versões, redigir, revisar, organizar a entrega. Enquanto você lê, não pesquisa; enquanto pesquisa, não redige; enquanto redige, não revisa o outro processo. Existe um jeito de tirar isso da sua mesa por mecanismo: orquestração de agentes jurídicos no Claude, sem conhecimento técnico, com pedidos em linguagem natural.",
        "cta_titulo": "Isto não é uma aula sobre prompts. É sobre capacidade operacional.",
        "cta_corpo": "A pergunta mudou: o que não precisa mais depender de você em todas as etapas? Preencha sua ficha de interesse e aplicação pelo WhatsApp e veja o Criminal Squad rodando na sua rotina.",
    },
    2: {  # consciente da solução — já usa IA de chat/cowork; precisa entender por que orquestração é outra natureza
        "eyebrow": _EYEBROW.format(n=2),
        "titulo": "Esqueça o prompt. Esqueça o cowork.",
        "sub1": "O melhor método de IA na advocacia criminal é a",
        "sub2": "orquestração de agentes jurídicos no Claude.",
        "linha": "Resultado eficiente · Velocidade · Segurança.   Sem limites, sem conhecimento técnico, pedidos em linguagem natural.",
        "intro": "Chat é coisa de 2022. Cowork é de 2024. A IA ficou rápida — e você continuou como gargalo: pergunta, resposta, nova pergunta, novo fragmento, montagem manual. Prompt é instrução. Pipeline é processo. Na orquestração de agentes jurídicos no Claude você pede em linguagem natural, o squad executa, os gates conferem, e só o que passa chega à sua mesa — sem conhecimento técnico nenhum.",
        "cta_titulo": "Chat é coisa de 2022. Cowork é de 2024.",
        "cta_corpo": "O melhor método de IA na advocacia criminal é a orquestração de agentes jurídicos no Claude — eficiência, velocidade, segurança, sem conhecimento técnico. Preencha sua ficha de interesse e aplicação pelo WhatsApp.",
    },
    3: {  # consciente do produto — o que recebe no Núcleo de Prática Criminal e como começa
        "eyebrow": _EYEBROW.format(n=3),
        "titulo": "Núcleo de Prática Criminal com o Claude, por dentro.",
        "sub1": "Criminal Squad é a tecnologia. O Núcleo é a",
        "sub2": "implementação — e este Radar é a primeira peça.",
        "linha": "Formar · Implementar · Operar, em 12 meses. CriminalSquad e FirmaOS instalados na sua máquina. Garantia de 15 dias.",
        "intro": "Você não sai apenas com conhecimento: sai com capacidade instalada. CriminalSquad na sua máquina, pronto para rodar, com setup orientado e primeiro uso guiado; FirmaOS, o segundo cérebro no Claude; trilha quinzenal de IA na prática jurídica; trilha quinzenal de atualização jurídica criminal; grupo exclusivo no WhatsApp. O Radar Criminal que você acabou de ler (DJEN + SEEU + DataJud) é a primeira peça instalada.",
        "cta_titulo": "O próximo passo não é o pagamento. É a ficha de interesse e aplicação.",
        "cta_corpo": "A implementação é individual: antes da matrícula, queremos entender como você atua, quais são seus gargalos e o que pretende implementar. Preencha sua ficha pelo WhatsApp — a equipe analisa e faz contato.",
    },
}

ERAS: List[Tuple[str, str, str]] = [
    ("ERA 1", "O operador artesanal", "Faz quase tudo pessoalmente. O crescimento depende de mais horas ou mais pessoas."),
    ("ERA 2", "O operador digital", "Usa software para armazenar, organizar e comunicar. As tarefas continuam majoritariamente humanas."),
    ("ERA 3", "O operador com IA de chat", "Recebe respostas e fragmentos mais rapidamente. Continua coordenando cada próxima etapa."),
    ("ERA 4", "O operador-orquestrador", "Define objetivos, critérios e checkpoints. Especialistas digitais executam o fluxo sob supervisão."),
]
IDENTIDADES: List[Tuple[str, str]] = [
    ("Executor", "Faz pessoalmente. Ler, pesquisar, escolher, redigir, revisar, entregar — uma etapa de cada vez, com um cérebro só."),
    ("Promptador", "Pede fragmentos e monta o resultado. Pergunta, resposta, nova pergunta, novo fragmento, montagem manual."),
    ("Orquestrador", "Dirige um processo com especialistas. Define objetivos, critérios e checkpoints; aprova; decide."),
]
NIVEIS: List[Tuple[str, str]] = [("1", "Prompt — recebe uma resposta"), ("2", "Agente — executa uma tarefa"), ("3", "Squad — reúne especialistas"), ("4", "Orquestração — conduz até a entrega")]
PIPELINE: List[Tuple[str, str, str]] = [
    ("01", "Você pede", "em linguagem natural"), ("02", "O sistema roteia", "o chefe escolhe o squad"), ("03", "O squad executa", "especialistas, em paralelo"),
    ("04", "Você aprova", "o sistema para e mostra"), ("05", "Os gates verificam", "fontes; reprova e devolve"), ("06", "A entrega é organizada", "com rastro de execução"),
]
ARQUITETURA: List[str] = ["Chefe-roteador", "Squad", "Pipeline", "Skills", "Checkpoints", "Gates de qualidade", "Rastro de execução"]
SQUADS: List[Tuple[str, str]] = [
    ("Análise processual", "Triagem · Leitor de autos · Cronologista · Analista de prova · Pesquisador · Revisor"),
    ("Audiência e prova oral", "Transcritor · Separador por depoente · Analista de contradições · Comparador com os autos · Estrategista de perguntas · Preparador"),
    ("Prova e multimídia", "Hash e integridade · Metadados · Cadeia de custódia · Leitura crítica de laudo · Análise de imagem · Relatório"),
    ("Gestão do escritório ou gabinete", "Gestor de demandas · Controlador de prazos · Organizador documental · Analista de capacidade · Redator de procedimentos · Supervisor"),
    ("Autoridade e conteúdo", "Estrategista editorial · Pesquisador · Roteirista · Redator · Designer · Editor · Revisor ético"),
    ("Palestras e aulas", "Curador jurídico · Arquiteto didático · Roteirista · Designer de slides · Criador de casos · Revisor"),
    ("Construção digital", "Estrategista · Arquiteto de informação · Redator · Designer · Desenvolvedor · Revisor jurídico · Testador"),
]
LEIS: List[str] = [
    "Sem fonte, não há autoridade.",
    "Sem aprovação, não há ato externo.",
    "Quem redige não revisa sozinho.",
    "Sem juízo humano, não há decisão final.",
    "Dados mínimos, acesso controlado e arquitetura local-first.",
]
OFERTA: List[Tuple[str, str]] = [
    ("Formar", "Aprender IA aplicada à rotina jurídica e à prática criminal."),
    ("Implementar", "Colocar CriminalSquad e FirmaOS para rodar na sua máquina."),
    ("Operar", "Usar a estrutura em casos, gestão, conteúdos, aulas e projetos."),
]


class Encarte:
    def __init__(self, pdf: PDF, versao: int = 2):
        self.pdf = pdf
        self.v = VERSOES.get(int(versao) if str(versao).isdigit() else 2, VERSOES[2])
        self.W, self.H = pdf.largura, pdf.altura
        self.L = self.W - 2 * MARGEM

    # ------------------------------------------------------------------ primitivas
    def faixa(self, y: float, h: float, cor) -> None:
        self.pdf.retangulo(0, y, self.W, h, preenchimento=cor)

    def eyebrow(self, x: float, y: float, txt: str, cor=None) -> None:
        self.pdf.texto(x, y, txt.upper(), 7.2, bold=True, cor=cor or C["dourado"])

    def caixa(self, x: float, y: float, w: float, h: float, titulo: str, sub: str = "", fundo=None, borda=None, tam: float = 8.2, cor_titulo=None, destaque=None) -> None:
        self.pdf.retangulo(x, y, w, h, preenchimento=fundo or C["caixa"], borda=borda or C["areia"], espessura=0.7, raio=4)
        if destaque:
            self.pdf.retangulo(x, y, 3, h, preenchimento=destaque)
        linhas_t = quebrar(titulo, w - 12, tam, True)
        linhas_s = quebrar(sub, w - 12, 6.6) if sub else []
        alt = len(linhas_t) * (tam + 2) + len(linhas_s) * 8.2
        yy = y + (h - alt) / 2 + tam
        for l in linhas_t:
            self.pdf.texto_centro(x + w / 2, yy, l, tam, bold=True, cor=cor_titulo or C["preto"])
            yy += tam + 2
        for l in linhas_s:
            self.pdf.texto_centro(x + w / 2, yy, l, 6.6, cor=C["cinza"])
            yy += 8.2

    def seta_h(self, x1: float, x2: float, y: float, cor=None, rotulo: str = "") -> None:
        self.pdf.seta(x1, y, x2, y, cor or C["cinza"], 0.8, 4)
        if rotulo:
            self.pdf.texto_centro((x1 + x2) / 2, y - 3, rotulo, 6, italico=True, cor=C["cinza"])

    def paragrafo(self, x: float, y: float, txt: str, w: float, tam: float = 9, cor=None, entre: float = 1.35, bold: bool = False) -> float:
        return self.pdf.paragrafo(x, y, txt, w, tam, bold=bold, cor=cor or C["preto"], entrelinha=entre)

    def _texto_ajustado(self, x: float, y: float, s: str, tam: float, w: float, bold: bool = True, cor=None, minimo: float = 5.5, centro: bool = False) -> None:
        """Escreve `s` em uma linha, reduzindo o corpo até caber em `w`."""
        while largura_texto(s, tam, bold) > w and tam > minimo:
            tam -= 0.25
        if centro:
            self.pdf.texto_centro(x, y, s, tam, bold=bold, cor=cor or C["preto"])
        else:
            self.pdf.texto(x, y, s, tam, bold=bold, cor=cor or C["preto"])

    def rodape(self, n: int, total: int) -> None:
        y = self.H - 30
        self.pdf.linha(MARGEM, y - 6, self.W - MARGEM, y - 6, C["areia"], 0.5)
        self.pdf.texto(MARGEM, y + 4, "CriminalRadar · Núcleo de Prática Criminal com o Claude · orquestração de agentes para o Direito Criminal", 7, cor=C["cinza"])
        self.pdf.texto_direita(self.W - MARGEM, y + 4, f"encarte {n} de {total}", 7, cor=C["cinza"])
        self.pdf.texto(MARGEM, y + 14, "O sistema prepara. O operador decide. Revisão humana em toda entrega.", 6.4, italico=True, cor=C["cinza"])

    # ------------------------------------------------------------------ página 1
    def pagina1(self) -> None:
        pdf = self.pdf
        pdf.nova_pagina()
        self.faixa(0, 132, C["preto"])
        pdf.retangulo(0, 132, self.W, 2.5, preenchimento=C["dourado"])
        v = self.v
        pdf.texto(MARGEM, 28, v["eyebrow"], 7.2, bold=True, cor=C["faixa_eyebrow"])
        tam_t = 23
        while largura_texto(v["titulo"], tam_t, True) > self.L and tam_t > 15:
            tam_t -= 1
        pdf.texto(MARGEM, 58, v["titulo"], tam_t, bold=True, cor=C["branco"])
        pdf.texto(MARGEM, 82, v["sub1"], 14.5, bold=True, cor=C["faixa_sub"])
        pdf.texto(MARGEM, 100, v["sub2"], 14.5, bold=True, cor=C["faixa_sub"])
        pdf.paragrafo(MARGEM, 120, v["linha"], self.L, 8.4, cor=C["faixa_linha"], entrelinha=1.2, max_linhas=1)

        # ---- quatro eras da operação jurídica
        y = 154
        self.eyebrow(MARGEM, y, "Quatro eras da operação jurídica — a tecnologia mudou; o modelo de trabalho precisa mudar também")
        y += 10
        cw = (self.L - 3 * 8) / 4
        ch = 92
        for i, (era, t, d) in enumerate(ERAS):
            x = MARGEM + i * (cw + 8)
            ultima = i == 3
            pdf.retangulo(x, y, cw, ch, preenchimento=C["gate"] if ultima else C["creme"], borda=C["gate_borda"] if ultima else C["areia"], espessura=0.8, raio=5)
            pdf.texto(x + 8, y + 15, era, 7.2, bold=True, cor=C["bordo"] if ultima else C["dourado"])
            pdf.paragrafo(x + 8, y + 29, t, cw - 16, 8.9, bold=True, cor=C["preto"], entrelinha=1.12, max_linhas=2)
            pdf.paragrafo(x + 8, y + 53, d, cw - 16, 6.9, cor=C["preto"], entrelinha=1.28, max_linhas=4)
            if i < 3:
                pdf.seta(x + cw + 0.5, y + 44, x + cw + 7.5, y + 44, C["cinza"], 0.8, 3.5)
        y += ch + 8
        y = pdf.paragrafo(MARGEM, y + 8, v["intro"], self.L, 9.2, bold=True, cor=C["preto"], entrelinha=1.33, max_linhas=5)

        # ---- definição
        y += 4
        self.eyebrow(MARGEM, y + 6, "A definição")
        pdf.texto(MARGEM, y + 25, "Prompt é instrução. Pipeline é processo.", 13, bold=True, cor=C["bordo"])
        y = pdf.paragrafo(MARGEM, y + 39, "Orquestração é dividir o trabalho em papéis, ordem e conferências: um chefe de gabinete entende o pedido e distribui; cada especialista faz uma tarefa; os gates conferem fontes e devolvem o que reprova; você aprova antes de qualquer ato externo. Não é um modelo mais inteligente — é um método de trabalho. E, no criminal, sem fonte não há autoridade: nenhuma súmula, tese ou precedente é citado de memória.", self.L, 8.6, cor=C["preto"], entrelinha=1.33, max_linhas=4)

        # ---- diagrama: produção linear × com orquestração
        y += 4
        x0 = MARGEM
        self.eyebrow(x0, y + 4, "Sem orquestração — produção jurídica linear, um cérebro e dez funções", C["cinza"])
        yb = y + 12
        bw, bh, gap = 82, 28, 16
        xs = [x0 + i * (bw + gap) for i in range(5)]
        for i, t in enumerate(["Ler os autos", "Pesquisar", "Escolher a tese", "Redigir"]):
            self.caixa(xs[i], yb, bw, bh, t)
        self.caixa(xs[4], yb, self.L - 4 * (bw + gap), bh, "Você revisa e entrega tudo", "fato, fonte, forma, prazo", fundo=C["reprova_fundo"], borda=C["reprova_borda"], cor_titulo=C["vermelho"])
        for i in range(4):
            self.seta_h(xs[i] + bw + 2, xs[i + 1] - 2, yb + bh / 2)

        y = yb + bh + 18
        self.eyebrow(x0, y + 4, "Com orquestração — o Criminal Squad", C["bordo"])
        yb = y + 12
        cw2, chh = 78, 28
        xc = [x0, x0 + 100, x0 + 214, x0 + 328, x0 + 426]
        self.caixa(xc[0], yb + 34, cw2, chh, "Pedido", "em linguagem natural")
        self.caixa(xc[1], yb + 34, cw2, chh, "Chefe de gabinete", "entende e distribui", fundo=C["gate"], borda=C["gate_borda"], tam=7.6)
        for j, (t, s_) in enumerate([("Leitor de autos", "cronologia e provas"), ("Pesquisador", "fontes e precedentes"), ("Redator", "tese e peça")]):
            self.caixa(xc[2], yb + j * 34, cw2 + 10, chh, t, s_)
            self.seta_h(xc[1] + cw2 + 2, xc[2] - 2, yb + j * 34 + chh / 2)
            self.seta_h(xc[2] + cw2 + 12, xc[3] - 2, yb + j * 34 + chh / 2)
        pdf.texto_centro(xc[1] + cw2 + 12 + (xc[2] - xc[1] - cw2 - 14) / 2, yb - 5, "delega", 6, italico=True, cor=C["cinza"])
        gw_ = cw2 + 4
        self.caixa(xc[3], yb + 18, gw_, 60, "Gates", "fontes · critérios · bloqueio · devolução", fundo=C["gate"], borda=C["gate_borda"])
        self.caixa(xc[4], yb + 34, self.L - (xc[4] - x0), chh, "Checkpoint humano", "você aprova e decide", fundo=C["humano"], borda=C["humano_borda"], tam=7.6, cor_titulo=C["verde"])
        self.seta_h(xc[0] + cw2 + 2, xc[1] - 2, yb + 34 + chh / 2)
        self.seta_h(xc[3] + gw_ + 2, xc[4] - 2, yb + 34 + chh / 2)
        yl = yb + 3 * 34 + 6
        xg = xc[3] + gw_ / 2
        pdf.linha(xg, yb + 78, xg, yl, C["vermelho"], 0.9)
        pdf.linha(xg, yl, xc[2] + (cw2 + 10) / 2, yl, C["vermelho"], 0.9)
        pdf.seta(xc[2] + (cw2 + 10) / 2, yl, xc[2] + (cw2 + 10) / 2, yb + 2 * 34 + chh + 3, C["vermelho"], 0.9, 4)
        pdf.texto_centro((xg + xc[2] + (cw2 + 10) / 2) / 2, yl - 3, "REPROVA E DEVOLVE", 6, bold=True, cor=C["vermelho"])
        y = yl + 16
        y = pdf.paragrafo(MARGEM, y, "O mesmo pedido, dois desenhos. Em cima, enquanto você lê não pesquisa; enquanto pesquisa não redige; enquanto redige não revisa o outro processo — e a conferência inteira fica para o fim, com você. Embaixo, a revisão pode devolver o trabalho para correção antes de chegar à sua mesa. Quem manda continua sendo você.", self.L, 7.9, cor=C["cinza"], entrelinha=1.32, max_linhas=3)

        # ---- três identidades: Executor × Promptador × Orquestrador
        y += 7
        self.eyebrow(MARGEM, y + 2, "Três identidades convivem hoje — em qual nível você está?")
        y += 8
        colw = (self.L - 2 * 12) / 3
        alt = 62
        for i, (t, d) in enumerate(IDENTIDADES):
            x = MARGEM + i * (colw + 12)
            pdf.retangulo(x, y, colw, alt, preenchimento=C["creme"], raio=5)
            pdf.retangulo(x, y, 4, alt, preenchimento=C["bordo"] if i == 2 else C["dourado"])
            pdf.texto(x + 12, y + 16, t, 10.5, bold=True, cor=C["bordo"] if i == 2 else C["preto"])
            pdf.paragrafo(x + 12, y + 29, d, colw - 22, 7.2, cor=C["preto"], entrelinha=1.28, max_linhas=3)
        y += alt + 10

        # ---- quatro níveis de utilização da IA
        kw = (self.L - 3 * 10) / 4
        for i, (n, l) in enumerate(NIVEIS):
            x = MARGEM + i * (kw + 10)
            pdf.retangulo(x, y, kw, 46, preenchimento=C["bordo"] if i == 3 else C["preto"], raio=6)
            pdf.texto(x + 12, y + 27, n, 19, bold=True, cor=C["dourado"])
            pdf.paragrafo(x + 30, y + 21, l.split(" — ")[0], kw - 38, 9, bold=True, cor=C["branco"], entrelinha=1.2, max_linhas=1)
            pdf.paragrafo(x + 30, y + 33, l.split(" — ")[1], kw - 38, 6.6, cor=C["faixa_sub"], entrelinha=1.2, max_linhas=1)

    # ------------------------------------------------------------------ página 2
    def pagina2(self) -> None:
        pdf = self.pdf
        pdf.nova_pagina()
        self.faixa(0, 30, C["preto"])
        pdf.retangulo(0, 30, self.W, 2, preenchimento=C["dourado"])
        pdf.texto(MARGEM, 19, "CRIMINAL SQUAD  ·  COMO A ORQUESTRAÇÃO ATUA NA OPERAÇÃO CRIMINAL", 8.5, bold=True, cor=C["branco"])
        y = 56
        pdf.texto(MARGEM, y, "O Criminal Squad, em uma frase", 15, bold=True, cor=C["preto"])
        y = pdf.paragrafo(MARGEM, y + 15, "É uma equipe de assistentes jurídicos de IA que não dorme — cada um especialista em uma tarefa — coordenada por um chefe de gabinete que entende o pedido e distribui o trabalho. Você fala normalmente, como falaria com alguém da equipe. Sem menu. Sem comando decorado.", self.L, 8.8, cor=C["cinza"], entrelinha=1.3, max_linhas=3)

        # ---- pipeline: do pedido à entrega
        y += 5
        n = len(PIPELINE); gap = 7
        pw = (self.L - (n - 1) * gap) / n
        ph = 60
        for i, (num, t, d) in enumerate(PIPELINE):
            x = MARGEM + i * (pw + gap)
            humano, gate = i in (0, 3), i == 4
            fundo = C["gate"] if gate else (C["humano"] if humano else C["caixa"])
            borda = C["gate_borda"] if gate else (C["humano_borda"] if humano else C["areia"])
            pdf.retangulo(x, y, pw, ph, preenchimento=fundo, borda=borda, espessura=0.7, raio=4)
            pdf.texto(x + 6, y + 12, num, 7, bold=True, cor=C["dourado"])
            pdf.paragrafo(x + 6, y + 25, t, pw - 10, 8.0, bold=True, cor=C["verde"] if humano else (C["bordo"] if gate else C["preto"]), entrelinha=1.15, max_linhas=2)
            pdf.paragrafo(x + 6, y + 45, d, pw - 10, 6.2, cor=C["cinza"], entrelinha=1.2, max_linhas=2)
            if i < n - 1:
                pdf.seta(x + pw + 0.5, y + 30, x + pw + gap - 0.5, y + 30, C["cinza"], 0.7, 3)
        y += ph + 8

        # ---- arquitetura: sete peças
        gw = (self.L - 6 * 5) / 7
        for i, g in enumerate(ARQUITETURA):
            x = MARGEM + i * (gw + 5)
            pdf.retangulo(x, y, gw, 28, preenchimento=C["creme"], borda=C["areia"], espessura=0.6, raio=3)
            pdf.texto_centro(x + gw / 2, y + 11, f"{i + 1}", 6.5, bold=True, cor=C["dourado"])
            self._texto_ajustado(x + gw / 2, y + 22, g, 7.0, gw - 6, bold=True, cor=C["preto"], centro=True)
        y += 34
        y = pdf.paragrafo(MARGEM, y + 4, "O chefe-roteador classifica o pedido, identifica o resultado esperado e escolhe o squad. O squad separa responsabilidades: o mesmo agente não pesquisa, escreve, revisa e aprova sozinho. O pipeline define a sequência, passa contexto entre etapas e prevê loops de correção. Cada skill é um especialista operacional, com método, critérios e fontes. Os checkpoints param, mostram o que foi feito e pedem aprovação. Os gates conferem fontes, bloqueiam itens não verificados e devolvem para correção. O rastro registra quem fez, com base em quê, qual versão foi aprovada e o que ficou pendente.", self.L, 7.9, cor=C["preto"], entrelinha=1.32, max_linhas=5)

        # ---- tabela dos squads (dimensões da operação criminal)
        y += 6
        pdf.texto(MARGEM, y + 4, "Muito além das peças: os squads da operação criminal", 12.5, bold=True, cor=C["preto"])
        y += 12
        c1 = 128.0
        pdf.texto(MARGEM + 6, y + 8, "SQUAD", 6.4, bold=True, cor=C["cinza"])
        pdf.texto(MARGEM + c1 + 8, y + 8, "ESPECIALISTAS", 6.4, bold=True, cor=C["cinza"])
        y += 12
        for i, (nome, membros) in enumerate(SQUADS):
            ln = quebrar(nome, c1 - 12, 7.6, True)
            lm = quebrar(membros, self.L - c1 - 16, 7.0)
            h = max(len(ln) * 9.4, len(lm) * 8.8) + 6
            if i % 2 == 0:
                pdf.retangulo(MARGEM, y, self.L, h, preenchimento=C["creme"], raio=2)
            pdf.retangulo(MARGEM, y, 2.5, h, preenchimento=C["bordo"])
            yy = y + 9.5
            for l in ln:
                pdf.texto(MARGEM + 8, yy, l, 7.6, bold=True, cor=C["preto"]); yy += 9.4
            yy = y + 9.5
            for l in lm:
                pdf.texto(MARGEM + c1 + 8, yy, l, 7.0, cor=C["preto"]); yy += 8.8
            y += h + 1
        y = pdf.paragrafo(MARGEM, y + 8, "Um mesmo mecanismo, múltiplas operações: do processo ao site, da audiência à palestra, do áudio à estratégia. Não é uma máquina de petições — é infraestrutura de capacidade profissional.", self.L, 6.6, italico=True, cor=C["cinza"], entrelinha=1.3, max_linhas=2)

        # ---- cinco leis
        y += 4
        pdf.texto(MARGEM, y + 4, "Escala com controle: as cinco leis", 12.5, bold=True, cor=C["preto"])
        y += 12
        colw5 = (self.L - 4 * 7) / 5
        for i, lei in enumerate(LEIS):
            x = MARGEM + i * (colw5 + 7)
            pdf.retangulo(x, y, colw5, 48, preenchimento=C["caixa"], borda=C["areia"], espessura=0.7, raio=4)
            pdf.texto(x + 9, y + 14, f"LEI {i + 1}", 6.8, bold=True, cor=C["dourado"])
            pdf.paragrafo(x + 9, y + 26, lei, colw5 - 16, 7.2, bold=True, cor=C["preto"], entrelinha=1.25, max_linhas=3)
        y += 48
        pdf.texto(MARGEM, y + 14, "O sistema prepara. O operador decide.", 10.5, bold=True, cor=C["bordo"])
        y = pdf.paragrafo(MARGEM, y + 25, "Estratégia, avaliação ética, orientação ao cliente, escolha da tese, aprovação final, assinatura e responsabilidade não se terceirizam. Arquitetura local-first: arquivos e ferramentas locais; indexação e acervo controlados pelo operador; envio ao modelo conforme provedor e configuração.", self.L, 6.6, italico=True, cor=C["cinza"], entrelinha=1.3, max_linhas=2)

        # ---- oferta: Núcleo de Prática Criminal com o Claude
        y += 4
        pdf.texto(MARGEM, y + 4, "Núcleo de Prática Criminal com o Claude", 12.5, bold=True, cor=C["preto"])
        pdf.texto(MARGEM + largura_texto("Núcleo de Prática Criminal com o Claude", 12.5, True) + 8, y + 4, "Criminal Squad é a tecnologia. O Núcleo é a implementação — 12 meses.", 7.6, cor=C["cinza"])
        y += 12
        colw3 = (self.L - 2 * 10) / 3
        for i, (t, d) in enumerate(OFERTA):
            x = MARGEM + i * (colw3 + 10)
            pdf.retangulo(x, y, colw3, 44, preenchimento=C["creme"], borda=C["areia"], espessura=0.7, raio=4)
            pdf.texto(x + 10, y + 14, t.upper(), 6.8, bold=True, cor=C["bordo"])
            pdf.paragrafo(x + 10, y + 26, d, colw3 - 18, 7.2, cor=C["preto"], entrelinha=1.28, max_linhas=2)
        y += 44
        pdf.paragrafo(MARGEM, y + 11, "Você recebe: CriminalSquad instalado na sua máquina, pronto para rodar · FirmaOS, o segundo cérebro no Claude · trilha quinzenal de IA na prática jurídica · trilha quinzenal de atualização jurídica criminal · grupo exclusivo no WhatsApp · garantia de 15 dias após a matrícula.", self.L, 7.2, cor=C["preto"], entrelinha=1.3, max_linhas=2)
        pdf.texto(MARGEM, y + 32, "O CriminalRadar que você acabou de ler — DJEN + SEEU + DataJud — é a primeira peça instalada.", 7.2, bold=True, cor=C["bordo"])

        # ---- CTA WhatsApp
        y += 42
        bw_, bh_ = 196, 40
        cta_h = 90
        bx, by = self.W - MARGEM - bw_ - 18, y + (cta_h - bh_) / 2
        largura_txt = bx - MARGEM - 34
        pdf.retangulo(MARGEM, y, self.L, cta_h, preenchimento=C["preto"], raio=8)
        pdf.retangulo(MARGEM, y, 5, cta_h, preenchimento=C["dourado"])
        tam_c = 11.5
        while largura_texto(self.v["cta_titulo"], tam_c, True) > largura_txt and tam_c > 8.5:
            tam_c -= 0.5
        pdf.texto(MARGEM + 20, y + 22, self.v["cta_titulo"], tam_c, bold=True, cor=C["branco"])
        pdf.paragrafo(MARGEM + 20, y + 36, self.v["cta_corpo"], largura_txt, 8.2, cor=C["faixa_sub"], entrelinha=1.3, max_linhas=4)
        pdf.retangulo(bx, by, bw_, bh_, preenchimento=C["whats"], raio=20)
        # ícone simples de balão
        pdf.retangulo(bx + 14, by + 11, 18, 18, preenchimento=C["branco"], raio=9)
        pdf.poligono([(bx + 16, by + 30), (bx + 22, by + 26), (bx + 16, by + 24)], preenchimento=C["branco"])
        pdf.retangulo(bx + 19, by + 16, 8, 8, preenchimento=C["whats"], raio=4)
        pdf.texto(bx + 40, by + 18, "Ficha de interesse pelo WhatsApp", 9, bold=True, cor=C["branco"])
        pdf.texto(bx + 40, by + 31, WHATSAPP_FMT, 9, cor=C["branco"])
        pdf.link(bx, by, bw_, bh_, WHATSAPP_URL)
        pdf.link(MARGEM, y, self.L, cta_h, WHATSAPP_URL)

        # ---- fecho
        y += cta_h + 18
        pdf.texto(MARGEM, y, "A peça é uma entrega. A operação é o futuro.", 11, bold=True, cor=C["preto"])
        pdf.texto_direita(self.W - MARGEM, y, "E QUEM MANDA CONTINUA SENDO VOCÊ.", 8.5, bold=True, cor=C["bordo"])

    def desenhar(self) -> None:
        self.pagina1()
        p1 = self.pdf.pag
        self.pagina2()
        p2 = self.pdf.pag
        self.pdf.pag = p1
        self.rodape(1, 2)
        self.pdf.pag = p2
        self.rodape(2, 2)
