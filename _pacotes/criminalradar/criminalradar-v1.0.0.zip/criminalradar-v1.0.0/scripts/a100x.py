#!/usr/bin/env python3
"""CLI do Radar (white-label: Advocacia 100X, CriminalRadar).  Uso: <cli> <comando> [opções]   (ou: python3 scripts/a100x.py ...)"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from datetime import date, datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from a100x import NOME, PRODUTO, ROTULO, VERSAO, agendador, cnj, config, estado, prazos  # noqa: E402
from a100x.marca import M as MARCA, skill as _skill  # noqa: E402

CLI = MARCA["cli"]
TAG = f"[{MARCA['nome']}]"
from a100x.relatorio import Log, registrar_falha, rodar  # noqa: E402


def _print(*a, **k):
    print(*a, **k, flush=True)


def _erro(msg: str, codigo: int = 1):
    _print(f"ERRO: {msg}", file=sys.stderr)
    sys.exit(codigo)


def _cfg_ou_padrao() -> dict:
    try:
        return config.carregar()
    except ValueError as e:
        _erro(str(e))


# ----------------------------------------------------------------- configurar
def cmd_configurar(a):
    cfg = _cfg_ou_padrao()
    mudou = False
    if a.init and not cfg.get("_existe"):
        mudou = True
    for par in a.set or []:
        if "=" not in par:
            _erro(f"use --set chave=valor (recebi {par!r})")
        k, v = par.split("=", 1)
        try:
            config.definir(cfg, k.strip(), v)
        except (KeyError, ValueError) as e:
            _erro(f"não consegui definir {k}: {e}")
        mudou = True
    if a.json:
        try:
            dados = json.loads(a.json)
        except json.JSONDecodeError as e:
            _erro(f"--json inválido: {e}")
        cfg = config._mesclar(cfg, dados)
        mudou = True
    if a.smtp_sugerir:
        from a100x.email_envio import sugerir_smtp
        s = sugerir_smtp(a.smtp_sugerir)
        if s:
            cfg["email"]["smtp"].update({"host": s["host"], "porta": s["porta"], "seguranca": s["seguranca"]})
            if s.get("usuario"):
                cfg["email"]["smtp"]["usuario"] = s["usuario"]
                if not s.get("relay"):
                    cfg["email"]["remetente"] = cfg["email"].get("remetente") or s["usuario"]
            mudou = True
            _print(f"SMTP configurado ({s.get('relay') or a.smtp_sugerir}): {s['host']}:{s['porta']} ({s['seguranca']})")
            for k, v in (s.get("dicas") or {}).items():
                _print(f"  falta definir email.smtp.{k.replace('_dica', '') if k != 'remetente_dica' else 'remetente (email.remetente)'}: {v}")
        else:
            _print(f"Sem sugestão automática para {a.smtp_sugerir}. Use `--smtp-sugerir brevo` (grátis, sem domínio) ou `--smtp-sugerir resend` (com domínio próprio); Google Workspace → smtp.gmail.com:587 starttls.")
    if mudou:
        caminho = config.salvar(cfg)
        _print(f"Configuração salva em {caminho}")
    if a.mostrar or not (mudou or a.validar):
        _print(json.dumps(config.mascarar(cfg), ensure_ascii=False, indent=2))
    if a.validar or mudou:
        probs = config.validar(cfg)
        if probs:
            _print("Pendências:")
            for p in probs:
                _print(f"  - {p}")
        else:
            _print("Configuração completa: pronta para rodar.")


# ----------------------------------------------------------------- listas
def _lista(cfg, chave, args, campo_id, normalizar=lambda x: x, extra=None):
    itens = cfg.setdefault(chave, [])
    if args.acao == "listar":
        if not itens:
            _print(f"(nenhum item em {chave})")
        for it in itens:
            _print("  " + " · ".join(f"{k}={v}" for k, v in it.items() if v))
        return
    valor = normalizar(args.valor)
    if args.acao == "add":
        novo = {campo_id: valor}
        novo.update(extra or {})
        if any(normalizar(i.get(campo_id, "")) == valor and all(i.get(k) == v for k, v in (extra or {}).items() if k == "uf") for i in itens):
            _print("já cadastrado.")
            return
        itens.append(novo)
        config.salvar(cfg)
        _print(f"adicionado: {novo}")
    elif args.acao == "remover":
        antes = len(itens)
        cfg[chave] = [i for i in itens if normalizar(i.get(campo_id, "")) != valor or (extra and "uf" in extra and i.get("uf") != extra["uf"])]
        config.salvar(cfg)
        _print("removido." if len(cfg[chave]) < antes else "não encontrado.")


def cmd_oab(a):
    cfg = _cfg_ou_padrao()
    if a.acao != "listar":
        if not a.valor or not a.uf:
            _erro("informe NUMERO e UF (ex.: oab add 123456 SP)")
        if not a.valor.strip().isdigit():
            _erro("número da OAB deve conter só dígitos")
    extra = {"uf": (a.uf or "").upper(), "nome": a.nome or "", "clientes": [c.strip() for c in (a.clientes or "").split(",") if c.strip()]} if a.acao != "listar" else None
    _lista(cfg, "oabs", a, "numero", lambda x: str(x).strip(), extra)


def cmd_processos(a):
    cfg = _cfg_ou_padrao()
    if a.acao != "listar":
        d = cnj.normalizar(a.valor or "")
        if not d:
            _erro(f"número CNJ inválido: {a.valor!r} (formato NNNNNNN-DD.AAAA.J.TR.OOOO)")
        if not cnj.digito_valido(d):
            _print(f"aviso: dígito verificador não confere para {cnj.formatar(d)} — confira o número (cadastrado mesmo assim).")
        a.valor = cnj.formatar(d)
        _print(f"{cnj.formatar(d)} — {cnj.descrever(d)}")
    _lista(cfg, "processos", a, "numero", lambda x: cnj.normalizar(x) or x, {"apelido": a.apelido or "", "cliente": a.cliente or ""} if a.acao != "listar" else None)


def cmd_partes(a):
    cfg = _cfg_ou_padrao()
    _lista(cfg, "partes", a, "nome", lambda x: str(x).strip().upper(), {"tribunal": (a.tribunal or "").upper()} if a.acao != "listar" else None)


# ----------------------------------------------------------------- rodar
def cmd_rodar(a):
    cfg = _cfg_ou_padrao()
    if not cfg.get("_existe"):
        _erro(f"Radar ainda não configurado. Rode {_skill('configurar')} (ou `{CLI} configurar --init`).", 3)
    log = Log(verbose=not a.json and not a.silencioso)
    opts = {"dias": a.dias, "sem_email": a.sem_email, "tudo": a.tudo, "sem_ia": a.sem_ia, "sem_datajud": a.sem_datajud,
            "agendado": a.agendado, "destinatarios": a.destinatario or None, "encarte_versao": a.encarte, "sem_nuvem": a.sem_nuvem}
    if a.agendado and (cfg.get("agenda") or {}).get("dias") == "uteis" and date.today().weekday() >= 5 and not a.dias:
        log("execução agendada em fim de semana — nada a fazer (agenda.dias = uteis)")
        return
    try:
        r = rodar(cfg, opts, log)
    except estado.ErroLock as e:
        _erro(str(e), 4)
    except Exception as e:  # noqa: BLE001
        log(f"FALHA: {type(e).__name__}: {e}")
        registrar_falha(cfg, e, log, opts)
        if a.json:
            _print(json.dumps({"ok": False, "erro": f"{type(e).__name__}: {e}"}, ensure_ascii=False))
        else:
            import traceback
            traceback.print_exc()
        sys.exit(1)
    if a.json:
        _print(json.dumps(r, ensure_ascii=False, indent=2, default=str))
    else:
        k = r.get("kpis", {})
        _print("")
        _print(f"✔ {ROTULO} — {date.today():%d/%m/%Y}")
        _print(f"  Publicações novas: {k.get('novas', 0)}  ·  críticas: {k.get('criticas', 0)}  ·  altas: {k.get('altas', 0)}  ·  prazos ≤ {k.get('alerta_dias', 5)} dias úteis: {k.get('prazos_proximos', 0)}")
        _print(f"  Processos consultados (DataJud): {k.get('processos_consultados', 0)}  ·  parados: {k.get('gargalos', 0)}  ·  em atenção: {k.get('atencao', 0)}")
        _print(f"  PDF: {r.get('pdf')}")
        _print(f"  E-mail: {'enviado para ' + ', '.join(r.get('destinatarios', [])) if r.get('email_enviado') else 'não enviado'}")
        for e in r.get("erros") or []:
            _print(f"  AVISO: {e}")
    if a.abrir and r.get("pdf"):
        _abrir(r["pdf"])
    sys.exit(2 if r.get("parcial") else 0)


def _abrir(caminho: str):
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", caminho])
        elif os.name == "nt":
            os.startfile(caminho)  # type: ignore[attr-defined]
        else:
            subprocess.Popen(["xdg-open", caminho])
    except OSError as e:
        _print(f"não consegui abrir {caminho}: {e}")


def cmd_abrir(a):
    est = estado.carregar()
    ur = est.get("ultimo_run") or {}
    if not ur.get("pdf") or not Path(ur["pdf"]).exists():
        _erro(f"nenhum PDF recente encontrado — rode `{CLI} rodar` primeiro.")
    _print(ur["pdf"])
    _abrir(ur["pdf"])


# ----------------------------------------------------------------- testar
def cmd_testar(a):
    cfg = _cfg_ou_padrao()
    alvo = a.alvo
    ok_total = True
    if alvo in ("apis", "tudo"):
        from a100x import djen, datajud
        from a100x.http import ErroHTTP
        try:
            fim = date.today()
            r = djen.buscar({"siglaTribunal": "TJSP", "dataDisponibilizacaoInicio": (fim - timedelta(days=3)).isoformat(), "dataDisponibilizacaoFim": fim.isoformat()}, max_paginas=1)
            _print(f"✔ DJEN (Comunica API): ok — {len(r)} itens de amostra (TJSP, 3 dias)")
        except ErroHTTP as e:
            ok_total = False
            _print(f"✘ DJEN: {e}")
        try:
            r = datajud.consultar("0000001-02.2024.8.26.0100", config.chave_datajud(cfg))
            if r.get("erro") and "indisponível" in r["erro"]:
                ok_total = False
                _print(f"✘ DataJud: {r['erro']}")
            else:
                _print(f"✔ DataJud (API pública): ok — índice {r.get('alias')} respondeu" + (" (processo de teste não existe, como esperado)" if not r.get("encontrado") else ""))
        except Exception as e:  # noqa: BLE001
            ok_total = False
            _print(f"✘ DataJud: {e}")
        for o in cfg.get("oabs") or []:
            try:
                fim = date.today()
                r = djen.buscar_por_oab(o["numero"], o["uf"], fim - timedelta(days=7), fim)
                _print(f"✔ DJEN OAB {o['numero']}/{o['uf']}: {len(r)} publicações nos últimos 7 dias")
            except Exception as e:  # noqa: BLE001
                ok_total = False
                _print(f"✘ DJEN OAB {o['numero']}/{o['uf']}: {e}")
    if alvo in ("email", "tudo"):
        from a100x.email_conector import ErroConector, enviar_por_conector
        from a100x.email_envio import ErroEmail, enviar
        probs = [p for p in config.validar(cfg) if "smtp" in p.lower() or "e-mail" in p.lower() or "destinat" in p.lower() or "provedor" in p.lower()]
        if probs:
            ok_total = False
            _print("✘ E-mail: " + " | ".join(probs))
        else:
            provedor = ((cfg.get("email") or {}).get("provedor") or "smtp").lower()
            try:
                txt = f"Teste do {ROTULO} enviado em {datetime.now():%d/%m/%Y %H:%M} ({'conector Gmail' if provedor == 'gmail-conector' else 'SMTP'}). Se você recebeu esta mensagem, o envio está funcionando."
                html = f"<p style='font-family:Helvetica,Arial'>{txt}</p>"
                dest = a.destinatario or (cfg.get("email") or {}).get("destinatarios") or []
                if provedor == "gmail-conector":
                    r = enviar_por_conector(cfg, f"Teste · {ROTULO}", html, txt, list(dest))
                else:
                    r = enviar(cfg, f"Teste · {ROTULO}", html, txt, [], a.destinatario or None)
                _print(f"✔ E-mail de teste enviado para {', '.join(r['destinatarios'])} via {provedor}")
            except (ErroEmail, ErroConector) as e:
                ok_total = False
                _print(f"✘ E-mail: {e}")
    if alvo == "drive" or (alvo == "tudo" and str((cfg.get("relatorios") or {}).get("nuvem") or "drive-doc") != "nenhum" and ((cfg.get("email") or {}).get("provedor") or "gmail-conector") == "gmail-conector"):
        from a100x.email_conector import ErroConector, criar_doc_no_drive
        try:
            dest = a.destinatario or (cfg.get("email") or {}).get("destinatarios") or []
            link = criar_doc_no_drive(cfg, f"{ROTULO} — teste {datetime.now():%d/%m/%Y %H:%M}", f"<h2>Teste do {ROTULO}</h2><p>Se você abriu este documento, a versão na nuvem está funcionando. Pode apagar.</p>", list(dest), log=_print)
            _print(f"✔ Google Drive: documento de teste criado e compartilhado — {link}")
        except ErroConector as e:
            ok_total = False
            _print(f"✘ Google Drive: {e} — o conector 'Google Drive' está ativo em claude.ai?")
    if alvo in ("ia", "tudo"):
        from a100x import ia
        b = ia.encontrar_claude(cfg)
        if not b:
            _print("• IA: `claude` não encontrado — o Radar funciona sem IA (resumos = trechos do texto oficial)")
        else:
            r = ia.resumir([{"id": 1, "tipo": "Intimação", "documento": "Despacho", "tribunal": "TJSP", "orgao": "1ª Vara", "texto": "Fica a parte autora intimada a se manifestar sobre a contestação no prazo de 15 (quinze) dias."}], cfg, log=lambda s: None)
            if r.get(1):
                _print(f"✔ IA ({b}): ok — resumo de teste: {r[1]['resumo']}")
            else:
                ok_total = False
                _print(f"✘ IA ({b}): não respondeu — verifique se o Claude Code está logado (`claude` → /login). O Radar segue funcionando sem IA.")
    sys.exit(0 if ok_total else 2)


# ----------------------------------------------------------------- status
def cmd_status(a):
    cfg = _cfg_ou_padrao()
    est = estado.carregar()
    ag = agendador.status(cfg) if cfg.get("_existe") else {"instalado": False}
    ur = est.get("ultimo_run") or {}
    info = {
        "versao": VERSAO, "configurado": bool(cfg.get("_existe")), "config": str(config.caminho_config()),
        "pendencias": config.validar(cfg) if cfg.get("_existe") else [f"Não configurado — rode {_skill('configurar')}"],
        "escopo": {"oabs": [f"{o.get('numero')}/{o.get('uf')}" for o in cfg.get("oabs") or []], "processos": len(cfg.get("processos") or []), "partes": len(cfg.get("partes") or [])},
        "email": {"destinatarios": (cfg.get("email") or {}).get("destinatarios"), "smtp": f"{(cfg['email']['smtp'].get('host') or '?')}:{cfg['email']['smtp'].get('porta')}"},
        "agenda": ag,
        "ultimo_run": {k: ur.get(k) for k in ("quando", "ok", "agendado", "n_novas", "n_criticas", "email_enviado", "pdf", "erros", "erro", "duracao_s") if k in ur},
        "ultimo_ok": est.get("ultimo_ok"), "ultimo_email": est.get("ultimo_email"),
        "publicacoes_ja_relatadas": len(est.get("publicacoes_vistas") or {}),
        "pasta_relatorios": str(config.pasta_relatorios(cfg)), "logs": str(config.pasta_logs()),
        "ia": {"ativa": (cfg.get("ia") or {}).get("ativa"), "modelo": (cfg.get("ia") or {}).get("modelo")},
    }
    if a.json:
        _print(json.dumps(info, ensure_ascii=False, indent=2, default=str))
        return
    _print(f"{NOME} · {PRODUTO} v{VERSAO}")
    _print(f"  Configuração: {'ok' if info['configurado'] and not info['pendencias'] else 'PENDENTE'} ({info['config']})")
    for p in info["pendencias"]:
        _print(f"    - {p}")
    e = info["escopo"]
    _print(f"  Monitorando: OAB {', '.join(e['oabs']) or '—'} · {e['processos']} processo(s) · {e['partes']} parte(s)")
    _print(f"  E-mail: {', '.join(info['email']['destinatarios'] or []) or '—'} via {info['email']['smtp']}")
    if ag.get("instalado"):
        _print(f"  Agenda: {ag.get('plataforma')} · {ag.get('hora')} ({ag.get('dias')}) · próxima: {ag.get('proxima')} · {'carregada' if ag.get('carregado') else 'NÃO carregada'}")
    else:
        _print(f"  Agenda: NÃO instalada — rode {_skill('agendar')}")
    if ur:
        st = "ok" if ur.get("ok") else f"FALHOU ({ur.get('erro')})"
        _print(f"  Última execução: {ur.get('quando')} · {st} · {ur.get('n_novas', 0)} novas · e-mail {'enviado' if ur.get('email_enviado') else 'não enviado'}")
        for err in ur.get("erros") or []:
            _print(f"    aviso: {err}")
        if ur.get("pdf"):
            _print(f"  Último PDF: {ur['pdf']}")
    else:
        _print("  Última execução: nunca")
    _print(f"  IA: {'ativa' if info['ia']['ativa'] else 'desativada'} ({info['ia']['modelo']}) · Relatórios: {info['pasta_relatorios']} · Logs: {info['logs']}")
    if a.log:
        logs = sorted(config.pasta_logs().glob("radar-*.log"))
        if logs:
            linhas = logs[-1].read_text(encoding="utf-8").splitlines()[-a.log:]
            _print("\n  Últimas linhas do log:")
            for l in linhas:
                _print("   " + l)


# ----------------------------------------------------------------- agendar
def cmd_agendar(a):
    cfg = _cfg_ou_padrao()
    if a.remover:
        r = agendador.remover(log=_print)
        _print("Agendamento removido." if r.get("removido") else "Não havia agendamento instalado.")
        return
    if a.status:
        _print(json.dumps(agendador.status(cfg), ensure_ascii=False, indent=2))
        return
    if a.executar:
        r = agendador.executar_agora()
        _print(("Job disparado" if r.get("ok") else "Falha ao disparar") + (f" — {r.get('detalhe')}" if r.get("detalhe") else ""))
        return
    if not cfg.get("_existe"):
        _erro(f"configure antes de agendar ({_skill('configurar')}).", 3)
    if a.hora and not config._hora_valida(a.hora):
        _erro(f"hora inválida: {a.hora!r} (use HH:MM, ex.: 07:30)")
    if a.hora:
        config.definir(cfg, "agenda.hora", a.hora)
    if a.dias:
        config.definir(cfg, "agenda.dias", a.dias)
    if a.hora or a.dias:
        config.salvar(cfg)
    try:
        r = agendador.instalar(cfg, log=_print)
    except RuntimeError as e:
        _erro(str(e))
    _print(f"Agendado: todos os {'dias úteis' if r['dias'] == 'uteis' else 'dias'} às {r['hora']} ({r['plataforma']}). Próxima execução: {r['proxima']}.")
    if r["plataforma"] == "macos":
        _print("O Mac precisa estar ligado (pode estar bloqueado). Se estiver dormindo, o job roda ao acordar; se desligado, o Radar recupera na próxima abertura do Claude Code.")


# ----------------------------------------------------------------- consultas avulsas (para os agentes)
def cmd_buscar_djen(a):
    from a100x import classificar, djen
    fim = date.today()
    dias = a.dias if a.dias is not None else (None if a.processo else 7)
    ini = fim - timedelta(days=dias) if dias else None
    if a.oab:
        if not a.uf:
            _erro("--uf obrigatório com --oab")
        itens = djen.buscar_por_oab(a.oab, a.uf, ini, fim, a.tribunal or "")
    elif a.processo:
        itens = djen.buscar_por_processo(a.processo, ini, fim if dias else None)
    elif a.parte:
        itens = djen.buscar_por_parte(a.parte, ini, fim, a.tribunal or "")
    else:
        _erro("informe --oab N --uf UF, --processo N ou --parte NOME")
    itens = [djen.normalizar_item(x) for x in djen.deduplicar(itens)]
    cfg = _cfg_ou_padrao()
    oabs = [(a.oab, a.uf.upper())] if a.oab else [(str(o.get("numero")), str(o.get("uf", "")).upper()) for o in cfg.get("oabs") or []]
    est = estado.carregar()
    cl_novos, adv_novos = classificar.aprender_partes(itens, oabs)
    clientes = {c for o in cfg.get("oabs") or [] for c in (o.get("clientes") or [])} | set((est.get("clientes_aprendidos") or {}).keys()) | set(cl_novos)
    adversarios = {c for o in cfg.get("oabs") or [] for c in (o.get("adversarios") or [])} | {n for n, k in (est.get("adversarios_aprendidos") or {}).items() if k >= 2} | {n for n, k in adv_novos.items() if k >= 2}
    for it in itens:
        it["triagem"] = classificar.classificar(it, cfg.get("prazos") or {}, None, oabs, clientes, adversarios)
        if not a.texto:
            it["texto"] = it["texto"][:600]
    itens.sort(key=lambda it: classificar.ordem_urgencia(it["triagem"]))
    if a.json:
        _print(json.dumps(itens, ensure_ascii=False, indent=1))
        return
    _print(f"{len(itens)} publicações ({(str(ini) + ' a ' + str(fim)) if ini else 'histórico completo'})")
    for it in itens:
        t = it["triagem"]
        p = t.get("prazo")
        np_ = t.get("nossa_parte") or {}
        _print(f"- {it['data']} [{t['urgencia']}] {it['processo']} {it['tribunal']} · {it['tipo']}/{it['documento']} · polo {np_.get('polo')} · {t['ato']} · prazo est.: {prazos.formatar_br(p['fim']) if p else '—'}" + (f" · prazo da outra parte: {t['prazo_outra_parte']}d" if t.get('prazo_outra_parte') else ""))


def cmd_consultar_datajud(a):
    from a100x import datajud
    cfg = _cfg_ou_padrao()
    saida = [datajud.consultar(n, config.chave_datajud(cfg), cfg_andamento=cfg.get("andamento") or {}) for n in a.numeros]
    if a.json:
        _print(json.dumps(saida, ensure_ascii=False, indent=1))
        return
    for r in saida:
        if not r.get("encontrado"):
            _print(f"- {r['numero']}: {r.get('erro')}")
            continue
        um = r.get("ultimo_movimento") or {}
        _print(f"- {r['numero']} ({r['tribunal']} {r.get('grau')}) · {r.get('classe')} · {r.get('orgao')}")
        _print(f"    último: {um.get('data')} {um.get('nome')} · parado {r.get('dias_parado')}d · {r.get('status')} · {r['alerta']['nivel']} {r['alerta']['mensagem']} · sync DataJud {r.get('atualizado_em')}")
        _print(f"    próximo ato: {r.get('proximo_ato')}")


def cmd_prazo(a):
    d = date.fromisoformat(a.data) if "-" in a.data else datetime.strptime(a.data, "%d/%m/%Y").date()
    penal_ = bool(a.penal or a.reu_preso or a.sem_recesso or MARCA.get("perfil") == "criminal") and not a.civel
    if penal_:
        r = prazos.contar_prazo_penal(d, a.dias, dobro=a.dobro, suspende_recesso=not (a.reu_preso or a.sem_recesso))
    else:
        r = prazos.contar_prazo(d, a.dias, dobro=a.dobro)
    un = "dias corridos (CPP 798)" if penal_ else "dias úteis (CPC 219)"
    _print(json.dumps(r, ensure_ascii=False, indent=2) if a.json else
           f"disponibilização {prazos.formatar_br(r['disponibilizacao'])} → publicação {prazos.formatar_br(r['publicacao'])} → início {prazos.formatar_br(r['inicio'])} → fim {prazos.formatar_br(r['fim'])} ({r['dias_contados']} {un}{' — em dobro' if r['dobro'] else ''}{' — prorrogado ao 1º dia útil' if r.get('prorrogado') else ''})\nBase: {r['base_legal']}\nEstimativa conservadora: feriados locais/forenses NÃO descontados.")


# ----------------------------------------------------------------- hook SessionStart
def cmd_hook_session_start(a):
    """Rápido e silencioso quando está tudo certo. Só imprime quando há algo a dizer ao usuário."""
    try:
        cfg = config.carregar()
    except ValueError as e:
        _print(f"{TAG} config.json inválido: {e}. Sugira ao usuário rodar {_skill('configurar')}.")
        return
    if not cfg.get("_existe"):
        _print(f"{TAG} Plugin instalado, mas o Radar ainda não foi configurado. Se o usuário pedir algo relacionado a publicações, prazos ou processos, sugira {_skill('configurar')} (leva 3 minutos).")
        return
    probs = config.validar(cfg)
    if probs:
        _print(f"{TAG} Configuração do Radar incompleta ({len(probs)} pendência(s)): " + " | ".join(probs) + f" → sugira {_skill('configurar')}.")
        return
    est = estado.carregar()
    ur = est.get("ultimo_run") or {}
    hoje = date.today()
    if ur and not ur.get("ok") and str(ur.get("quando", "")).startswith(hoje.isoformat()):
        _print(f"{TAG} A última execução do Radar hoje FALHOU ({ur.get('erro')}). Sugira {_skill('status')}.")
        return
    if ur and ur.get("ok") and ur.get("agendado") and not ur.get("email_enviado") and str(ur.get("quando", "")).startswith(hoje.isoformat()):
        _print(f"{TAG} O Radar de hoje foi gerado, mas o e-mail NÃO foi enviado ({'; '.join(ur.get('erros') or []) or 'motivo no log'}). PDF: {ur.get('pdf')}. Sugira {_skill('status')}.")
        return
    ag = cfg.get("agenda") or {}
    fim_de_semana = hoje.weekday() >= 5 and ag.get("dias", "uteis") == "uteis"
    if estado.gerou_hoje(est, hoje) or fim_de_semana or not cfg.get("catch_up_ao_abrir", True):
        return
    try:
        hh, mm = (ag.get("hora") or "07:30").split(":")
        passou_hora = datetime.now() >= datetime.now().replace(hour=int(hh), minute=int(mm), second=0, microsecond=0)
    except ValueError:
        passou_hora = True
    if not passou_hora:
        return
    lock = config.base_dir() / "radar.lock"
    if lock.exists():
        return
    logs = config.pasta_logs()
    logs.mkdir(parents=True, exist_ok=True)
    with open(logs / "catchup.log", "ab") as out:
        subprocess.Popen([sys.executable, str(Path(__file__).resolve()), "rodar", "--agendado", "--silencioso"], stdout=out, stderr=out, start_new_session=True)
    _print(f"{TAG} O Radar de hoje ({hoje:%d/%m}) ainda não tinha sido gerado (o Mac provavelmente estava desligado às {ag.get('hora')}). Iniciei a geração em segundo plano; o e-mail chega em alguns minutos. Avise o usuário em uma linha.")


# ----------------------------------------------------------------- parser
def main(argv=None):
    p = argparse.ArgumentParser(prog=CLI, description=f"{NOME} · {PRODUTO} v{VERSAO}")
    sub = p.add_subparsers(dest="cmd")

    s = sub.add_parser("configurar", help="ver/alterar a configuração")
    s.add_argument("--init", action="store_true", help="cria o config.json padrão se não existir")
    s.add_argument("--set", action="append", metavar="CHAVE=VALOR", help="ex.: --set email.smtp.host=smtp.gmail.com")
    s.add_argument("--json", metavar="OBJETO", help="mescla um objeto JSON na configuração")
    s.add_argument("--smtp-sugerir", metavar="EMAIL|brevo|resend", help="preenche host/porta/segurança pelo domínio do e-mail ou por relay (brevo, resend)")
    s.add_argument("--mostrar", action="store_true")
    s.add_argument("--validar", action="store_true")
    s.set_defaults(fn=cmd_configurar)

    s = sub.add_parser("oab", help="OABs monitoradas: add NUMERO UF | remover NUMERO UF | listar")
    s.add_argument("acao", choices=["add", "remover", "listar"])
    s.add_argument("valor", nargs="?")
    s.add_argument("uf", nargs="?")
    s.add_argument("--nome", default="")
    s.add_argument("--clientes", default="", help="nomes de clientes habituais, separados por vírgula (ajuda a identificar nosso polo)")
    s.set_defaults(fn=cmd_oab)

    s = sub.add_parser("processos", help="processos monitorados: add NUMERO | remover NUMERO | listar")
    s.add_argument("acao", choices=["add", "remover", "listar"])
    s.add_argument("valor", nargs="?")
    s.add_argument("--apelido", default="")
    s.add_argument("--cliente", default="")
    s.set_defaults(fn=cmd_processos)

    s = sub.add_parser("partes", help="partes monitoradas por nome: add NOME | remover NOME | listar")
    s.add_argument("acao", choices=["add", "remover", "listar"])
    s.add_argument("valor", nargs="?")
    s.add_argument("--tribunal", default="")
    s.set_defaults(fn=cmd_partes)

    s = sub.add_parser("rodar", help="gera o Radar agora (coleta, PDF e e-mail)")
    s.add_argument("--dias", type=int, help="janela retroativa em dias (padrão: config)")
    s.add_argument("--sem-email", action="store_true")
    s.add_argument("--sem-ia", action="store_true")
    s.add_argument("--sem-datajud", action="store_true")
    s.add_argument("--sem-nuvem", action="store_true", help="não cria a versão no Google Drive")
    s.add_argument("--tudo", action="store_true", help="inclui publicações já relatadas antes")
    s.add_argument("--destinatario", action="append", help="sobrescreve os destinatários (repetível)")
    s.add_argument("--agendado", action="store_true", help="modo job (avisa falhas por e-mail, respeita agenda.dias)")
    s.add_argument("--abrir", action="store_true", help="abre o PDF ao final")
    s.add_argument("--encarte", choices=["1", "2", "3"], help="versão da narrativa do encarte (padrão: rotação automática)")
    s.add_argument("--json", action="store_true")
    s.add_argument("--silencioso", action="store_true")
    s.set_defaults(fn=cmd_rodar)

    s = sub.add_parser("testar", help="testa apis | email | ia | drive | tudo")
    s.add_argument("alvo", choices=["apis", "email", "ia", "drive", "tudo"], nargs="?", default="tudo")
    s.add_argument("--destinatario", action="append")
    s.set_defaults(fn=cmd_testar)

    s = sub.add_parser("status", help="diagnóstico completo")
    s.add_argument("--json", action="store_true")
    s.add_argument("--log", type=int, metavar="N", help="mostra as últimas N linhas do log")
    s.set_defaults(fn=cmd_status)

    s = sub.add_parser("agendar", help="instala/remove o agendamento diário")
    s.add_argument("--hora", metavar="HH:MM")
    s.add_argument("--dias", choices=["uteis", "todos"])
    s.add_argument("--remover", action="store_true")
    s.add_argument("--status", action="store_true")
    s.add_argument("--executar", action="store_true", help="dispara o job agendado agora")
    s.set_defaults(fn=cmd_agendar)

    s = sub.add_parser("abrir", help="abre o último PDF gerado")
    s.set_defaults(fn=cmd_abrir)

    s = sub.add_parser("buscar-djen", help="consulta avulsa ao DJEN")
    s.add_argument("--oab")
    s.add_argument("--uf")
    s.add_argument("--processo")
    s.add_argument("--parte")
    s.add_argument("--tribunal")
    s.add_argument("--dias", type=int, default=None, help="janela em dias (padrão: 7; com --processo, histórico completo)")
    s.add_argument("--texto", action="store_true", help="inclui o texto integral")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_buscar_djen)

    s = sub.add_parser("consultar-datajud", help="andamento de um ou mais processos")
    s.add_argument("numeros", nargs="+")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_consultar_datajud)

    s = sub.add_parser("prazo", help="calcula prazo: DATA(AAAA-MM-DD ou DD/MM/AAAA) DIAS [--dobro] [--penal | --civel] [--reu-preso]")
    s.add_argument("--penal", action="store_true", help="dias corridos (CPP 798) com recesso suspenso (CPP 798-A) — perfil penal (padrão quando a marca é criminal)")
    s.add_argument("--civel", action="store_true", help="dias úteis (CPC 219) — perfil cível")
    s.add_argument("--reu-preso", action="store_true", help="penal sem suspensão no recesso (réu preso / Lei 11.340 / urgência — CPP 798-A I-III)")
    s.add_argument("--sem-recesso", action="store_true", help=argparse.SUPPRESS)
    s.add_argument("data")
    s.add_argument("dias", type=int)
    s.add_argument("--dobro", action="store_true")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_prazo)

    s = sub.add_parser("hook-session-start", help=argparse.SUPPRESS)
    s.set_defaults(fn=cmd_hook_session_start)

    s = sub.add_parser("versao", help="versão")
    s.set_defaults(fn=lambda a: _print(f"{NOME} · {PRODUTO} v{VERSAO} · python {sys.version.split()[0]}"))

    args = p.parse_args(argv)
    if not args.cmd:
        p.print_help()
        return
    args.fn(args)


if __name__ == "__main__":
    try:
        main()
    except BrokenPipeError:  # saída redirecionada para `head` etc.
        try:
            sys.stdout = open(os.devnull, "w")
        except OSError:
            pass
        sys.exit(0)
