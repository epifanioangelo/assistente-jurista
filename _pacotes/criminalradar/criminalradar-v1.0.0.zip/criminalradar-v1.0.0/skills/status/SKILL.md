---
name: status
description: Diagnóstico do CriminalRadar — configuração, agendamento, última execução, e-mail, logs e teste das conexões (DJEN, DataJud, e-mail, IA). Use quando o relatório não chegou, quando algo deu erro ou para conferir se está tudo funcionando.
user-invocable: true
allowed-tools: Bash, Read
argument-hint: "[--testar]"
---

# CriminalRadar · Status e diagnóstico

1. `criminalradar status --log 30` — mostre em linguagem simples: configurado? o que está monitorado (OABs, processos, papel: defesa/acusação/misto); e-mail; agendamento (instalado/carregado/próxima execução); última execução (quando, ok/falhou, quantas publicações, e-mail enviado?); último PDF; pendências.
2. Se pediram teste ou algo falhou: `criminalradar testar tudo` (DJEN, DataJud, e-mail de teste, IA). Cada linha diz ✔/✘ e a causa.
3. Diagnósticos comuns:
   - "O e-mail não chegou": veja `ultimo_run.email_enviado` e `erros`. Conector do Gmail desconectado ou Claude deslogado → reconectar em claude.ai → Conectores; `enviar_quando_vazio=false` e não havia novidade → comportamento esperado; veja a pasta de spam.
   - "Não rodou no horário": `agendar --status`; Mac desligado/dormindo no horário → o job roda ao acordar ou é recuperado ao abrir o Claude Code; verifique `~/.criminalradar/logs/launchd.err.log`.
   - "Publicação que eu vi no DJEN não apareceu": pode já ter sido relatada em dia anterior (dedup) → `criminalradar rodar --tudo --dias 7 --sem-email` para regerar; ou a OAB/UF cadastrada está errada; ou o DJEN indexou com atraso (a janela de 3 dias cobre isso no dia seguinte).
   - "A intimação da execução penal (SEEU) não apareceu": as intimações de advogado expedidas no SEEU vão automaticamente para o DJEN desde 2021 — então valem as mesmas causas acima (dedup, OAB errada, indexação atrasada). Se a intimação foi pessoal (Defensoria/MP/dativo/núcleo de prática) ou dirigida a outro advogado, ela não sai na busca pela sua OAB.
   - "DataJud não localizou o processo" ou "andamento da execução penal desatualizado": segredo de justiça, processo físico, STF ou sincronização atrasada do tribunal. Na execução penal a cobertura da DataJud é desigual por tribunal (alguns não reportam a classe "Execução da Pena") — confirmar manualmente no SEEU (seeu.pje.jus.br), com login/certificado para os autos.
   - "O prazo veio diferente do que eu contei": o Radar estima prazos penais em dias corridos (CPP 798), prorroga para o 1º dia útil, suspende o recesso de 20/12 a 20/01 (CPP 798-A) — exceto quando detecta réu preso, Lei 11.340 ou urgência (`criminalradar prazo DATA DIAS --penal --reu-preso` mostra a contagem sem a suspensão) — e não desconta feriados locais nem suspensões por portaria — confira no sistema do tribunal; fora do recesso a estimativa nunca é posterior à data real. Se a carteira tem intimação pessoal (Defensoria/MP/dativo/núcleo de prática), a publicação no DJEN é só informativa: `prazos.intimacao_pessoal=true` põe o aviso no relatório.
   - Erro de rede/HTTP 5xx: transitório; o Radar tenta 3 vezes com espera e avisa no PDF/e-mail.
4. Logs: `~/.criminalradar/logs/radar-AAAA-MM.log` (execuções), `launchd.out.log`/`launchd.err.log` (agendador), `catchup.log` (recuperação ao abrir o Claude).
