---
name: processos
description: Gerencia o que o CriminalRadar monitora — adiciona ou remove OABs, processos (número CNJ, inclusive execuções penais do SEEU) e partes por nome; lista o cadastro; faz uma consulta rápida de andamento na DataJud para confirmar o processo. Use quando o usuário disser "adiciona esse processo", "monitora a OAB do fulano", "tira esse caso", "quais processos estão cadastrados".
user-invocable: true
allowed-tools: Bash, Read
argument-hint: "[add|remover|listar] [número CNJ | OAB UF | nome da parte]"
---

# CriminalRadar · Cadastro do monitoramento

- Listar: `criminalradar oab listar` · `criminalradar processos listar` · `criminalradar partes listar`.
- OAB: `criminalradar oab add NUMERO UF --nome "…"` / `criminalradar oab remover NUMERO UF`.
- Processo: `criminalradar processos add NNNNNNN-DD.AAAA.J.TR.OOOO --apelido "Cliente / caso" --cliente "…"` / `criminalradar processos remover NUMERO`. A CLI valida o dígito verificador (Res. CNJ 65/2008) e mostra a Justiça/tribunal; se avisar que o dígito não confere, peça para a pessoa conferir o número antes de seguir. Serve para a ação penal, o inquérito judicializado e a **execução penal** (o SEEU usa a numeração CNJ — o número está na guia de execução e na própria intimação).
- Confirmar que o processo existe e ver o andamento: `criminalradar consultar-datajud NUMERO` (último movimento, dias parado, status). STF não está na DataJud; segredo de justiça não aparece. Na execução penal a cobertura da DataJud é desigual por tribunal: se vier "não localizado" ou muito defasado, a consulta é manual no SEEU (seeu.pje.jus.br).
- Parte por nome (atenção: nomes comuns geram centenas de publicações por dia; combine com `--tribunal`): `criminalradar partes add "NOME DO ASSISTIDO" --tribunal TJSP`.

Ao terminar, mostre a lista atualizada e lembre que a mudança vale a partir da próxima execução (`/criminalradar:relatorio` para ver agora).
