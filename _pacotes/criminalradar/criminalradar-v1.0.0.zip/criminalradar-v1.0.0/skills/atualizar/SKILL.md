---
name: atualizar
description: Atualiza o plugin CriminalRadar para a versão mais nova (a partir do zip recebido ou do marketplace), preservando OAB, e-mails, estado e agendamento; mostra a versão instalada. Use quando o usuário receber uma nova versão, perguntar "como atualizo", ou o status indicar versão nova.
user-invocable: true
allowed-tools: Bash, Read
---

# CriminalRadar · Atualizar

1. Versão atual: `criminalradar versao` e `claude plugin list | grep -A2 criminalradar`. Sem `claude` no PATH (usuário só com o app do Claude para computador), use o binário embutido: `"$CLAUDE_CODE_EXECPATH" plugin list | grep -A2 criminalradar` — vale para todos os comandos `claude plugin` abaixo.
2. **Recebeu um zip novo?** Peça o caminho do zip (ou da pasta descompactada). Descompacte se preciso (`unzip -q ARQUIVO.zip -d ~/Downloads/`) e rode o instalador que vem dentro: `bash "<pasta>/instalar.command"` (ele encontra o Claude Code sozinho — de terminal ou embutido no app). Ele copia a nova versão para `~/CriminalRadar/criminalradar`, atualiza o registro no Claude Code e preserva tudo em `~/.criminalradar` (OAB, e-mails, papel, clientes aprendidos, histórico, agendamento — o job diário resolve o caminho novo sozinho).
3. **Instalado a partir de um marketplace git?** `claude plugin marketplace update criminalradar && claude plugin update criminalradar@criminalradar -y`.
4. Peça para o usuário **reiniciar o Claude Code** (a nova versão só carrega em sessão nova) e confirme depois com `criminalradar versao` e `criminalradar status`.
5. Se o agendamento existia, confirme com `criminalradar agendar --status` (o instalador já regrava; se `carregado` for false, rode `criminalradar agendar`).

Nunca apague `~/.criminalradar`. Se algo falhar, `criminalradar status --log 30` mostra o motivo.
