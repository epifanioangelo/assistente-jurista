---
name: configurar
description: Configura o CriminalRadar em 3 minutos — OAB(s) e processos a monitorar, papel predominante (defesa, acusação ou misto), quantos dias para trás buscar, e-mails que recebem o relatório (enviado pelo conector do Gmail do claude.ai, sem senha), horário do envio diário e opções (IA, prazo em dobro da Defensoria, intimação pessoal, encarte do Núcleo de Prática Criminal). Use na primeira vez e sempre que o usuário quiser mudar o que é monitorado ou para onde o relatório vai.
user-invocable: true
allowed-tools: Bash, Read
argument-hint: "[o que mudar: oab | processos | papel | janela | email | horario | ia | intimacao]"
---

# CriminalRadar · Configurar

Você está guiando um(a) operador(a) do Direito Criminal — advogado(a) criminalista, defensor(a), promotor(a), assessor(a) — sem perfil técnico, pela configuração do **CriminalRadar**: todo dia ele consulta o DJEN (onde chegam também as intimações do SEEU) e a DataJud, classifica as publicações por urgência (sabendo de que lado você está: defesa ou acusação), estima prazos penais em dias corridos, extrai audiências (instrução, custódia, júri, justificação), gera o PDF no computador e envia o relatório completo por e-mail pelo Gmail conectado ao Claude.

Seja direto e acolhedor. **Uma pergunta por vez.** Nunca invente valores. O sistema prepara, o operador decide: cada resposta da pessoa vira um comando da CLI `criminalradar` (está no PATH deste plugin; se não estiver, use `"${CLAUDE_PLUGIN_ROOT}/bin/criminalradar"`). A configuração fica em `~/.criminalradar/config.json`.

## Passo 0 — Situação atual

Rode `criminalradar status --json`. Se `configurado` for `true`, diga o que já existe e pergunte **o que** a pessoa quer mudar (o argumento da skill, se veio, já responde). Se for a primeira vez, diga em 3 linhas o que vai acontecer e o que ela precisa ter à mão: número da OAB e os e-mails que vão receber o Radar.

Se a CLI falhar por falta de Python: macOS → `xcode-select --install`; Windows → python.org marcando "Add to PATH". Explique em uma frase e pare.

## Passo 1 — O que monitorar

- **OAB**: `criminalradar oab add NUMERO UF --nome "Nome"` (só dígitos; pode cadastrar várias — sócios, associados, núcleo).
- **Processos específicos** (opcional): `criminalradar processos add NNNNNNN-DD.AAAA.J.TR.OOOO --apelido "Cliente X"`. A CLI valida o dígito e mostra o tribunal. Vale também para o número da **execução penal** (o SEEU usa a numeração CNJ).
- **Parte por nome** (opcional, gera muito volume): `criminalradar partes add "NOME DO ASSISTIDO" --tribunal TJSP`.
- Nome do escritório/gabinete/núcleo e responsável (aparecem no PDF): `criminalradar configurar --set escritorio.nome="…" --set escritorio.responsavel="…"`.
- Clientes/adversários habituais (opcional; o Radar aprende sozinho): `--clientes "NOME A, NOME B"` no `oab add`.

## Passo 2 — Papel predominante (de que lado da mesa)

Pergunte: **"Você atua predominantemente pela defesa, pela acusação (MP ou assistente de acusação) ou de forma mista?"** Explique em uma frase que isso desempata o polo quando a publicação não diz de que lado a OAB está — e que, mesmo assim, o Radar confere o polo item a item. Grave com:
`criminalradar configurar --set prazos.papel=defesa` (ou `acusacao` ou `misto`).

## Passo 3 — Janela de busca (quantos dias para trás)

Pergunte: **"A cada execução, quantos dias para trás o Radar deve olhar?"** Explique que o padrão é **3 dias** (cobre fim de semana e atrasos de indexação do DJEN; publicações já relatadas nunca se repetem) e que a **primeira execução** olha **7 dias** para dar uma visão inicial. Ajuste com:
`criminalradar configurar --set busca.dias_retroativos=3 --set busca.primeira_vez_dias=7`
Para uma consulta pontual maior sem mudar a rotina: `/criminalradar:relatorio --dias 15`.

## Passo 4 — Para onde vai o relatório

1. Destinatários (vírgula separa vários): `criminalradar configurar --set email.destinatarios="a@x.com, b@y.com"`.
2. O envio sai pelo **conector do Gmail do claude.ai** — sem senha nenhuma. Pré-requisito: em claude.ai → Configurações → Conectores, o **Gmail** precisa estar conectado (se não estiver, oriente a conectar e volte). O e-mail traz o **relatório completo** (prioridades, agenda, todas as publicações, andamento, checklist e o encarte do Núcleo de Prática Criminal) e informa onde o **PDF** ficou salvo no computador.
3. Teste: `criminalradar testar email` — envia uma mensagem de teste pelo conector. Se falhar, a mensagem diz o motivo (conector não conectado, Claude deslogado).

## Passo 5 — Horário e opções

- Horário e dias: `criminalradar configurar --set agenda.hora=07:30 --set agenda.dias=uteis`.
- IA (resumo em linguagem clara de cada publicação, usando o Claude da própria pessoa): `ia.ativa=true|false`.
- **Prazo em dobro** para TODA a carteira: só cabe à **Defensoria Pública** (LC 80/94 arts. 44 I, 89 I, 128 I). Se a pessoa é defensor(a): `prazos.dobro=true --set prazos.motivo_dobro="Defensoria Pública"`. Deixe claro que **o Ministério Público NÃO tem prazo em dobro no processo penal** — quem atua pela acusação fica com `prazos.dobro=false`. Fora isso, o Radar apenas sinaliza os casos em que o texto sugere dobro.
- **Intimação pessoal**: pergunte **"Você tem prerrogativa de intimação pessoal? (Defensoria Pública, Ministério Público, defensor dativo, núcleo de prática jurídica)"**. Se sim: `criminalradar configurar --set prazos.intimacao_pessoal=true` — o relatório passa a avisar, em cada prazo, que a publicação no DJEN é apenas informativa e que a contagem oficial parte da intimação pessoal ou do acesso no Domicílio Judicial Eletrônico (CPP 370 §4º; LC 80/94 arts. 44 I, 89 I, 128 I; STJ EAREsp 2.841.872-DF; Res. CNJ 455/2022 arts. 11 §2º e 20 — sem acesso em 10 dias corridos, considera-se feita). Dobro é outra coisa: Defensoria sim (LC 80/94; Lei 1.060/50 art. 5º §5º); MP não (STF HC 120.275); dativo não; núcleo de prática jurídica — controverso, mande conferir antes de ligar `prazos.dobro`.
- Encarte do Núcleo de Prática Criminal com o Claude no fim do PDF e do e-mail: `relatorios.encarte=true|false`; versão da narrativa `relatorios.encarte_versao=auto|1|2|3` (auto = rotação).
- Pasta dos PDFs: `relatorios.pasta` (padrão `~/.criminalradar/relatorios`; evite `~/Documents` no macOS por causa da privacidade do sistema para jobs em segundo plano).

## Passo 6 — Validar e estrear

1. `criminalradar configurar --validar` — zero pendências.
2. `criminalradar testar apis` — DJEN e DataJud respondendo; mostra quantas publicações a OAB teve nos últimos 7 dias.
3. Primeira execução: `criminalradar rodar --abrir` (pode levar alguns minutos: coleta + IA + envio). Mostre os números, o caminho do PDF e confirme que o e-mail foi enviado.
4. Feche com `/criminalradar:agendar` para o relatório chegar sozinho todo dia — ou rode a skill se a pessoa disser sim.

## Regras

- Não peça o que já está configurado; mostre `criminalradar configurar --mostrar` para confirmar.
- Explique em uma frase o que cada comando faz antes de rodar; não despeje JSON.
- Lembre, uma vez, que os prazos penais do Radar são estimativas em dias corridos (CPP 798), suspensas no recesso de 20/12 a 20/01 (CPP 798-A) salvo réu preso, Maria da Penha e urgência, e que a contagem oficial continua sendo do operador — quem manda continua sendo você.
- Se a pessoa não tem Gmail conectado ao Claude e não quer conectar agora, configure o resto, rode `criminalradar rodar --sem-email --abrir` para ela ver o PDF, e deixe claro que o envio fica pendente (`/criminalradar:status` mostra).
