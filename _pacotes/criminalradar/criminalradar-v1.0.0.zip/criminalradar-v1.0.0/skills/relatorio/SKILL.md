---
name: relatorio
description: Gera o CriminalRadar agora — consulta DJEN (com as intimações do SEEU) e DataJud, classifica urgência, estima prazos penais, monta o PDF e envia por e-mail — e apresenta o resumo executivo aqui na conversa. Use quando o usuário pedir "roda o radar", "o que saiu hoje", "publicações de hoje", "gera o relatório", ou quiser reenviar/reabrir o PDF.
user-invocable: true
allowed-tools: Bash, Read
argument-hint: "[--dias N] [--sem-email] [--tudo] [--sem-ia]"
---

# CriminalRadar · Gerar o CriminalRadar agora

## Execução

1. Avise que a coleta pode levar de 30 segundos a alguns minutos (a DataJud responde devagar quando há muitos processos). Rode:
   `criminalradar rodar --json [argumentos recebidos]`
   Argumentos aceitos: `--dias N` (janela retroativa), `--sem-email` (só gera), `--tudo` (inclui publicações já relatadas em dias anteriores), `--sem-ia`, `--sem-datajud`, `--destinatario e@mail` (envio pontual para outra pessoa), `--abrir`.
2. Códigos de saída: `0` ok · `2` ok com avisos (algum tribunal/serviço falhou — mostre os avisos) · `3` não configurado → ofereça `/criminalradar:configurar` · `4` já há uma execução em andamento (aguarde ou veja `criminalradar status`) · `1` falha → rode `criminalradar status --log 40` e explique.

## Apresentação (curta, executiva)

Leia o JSON de saída (`kpis`, `pdf`, `json`, `email_enviado`, `erros`). Para os detalhes, leia o arquivo apontado em `json` (campo `prioridades`: cada item tem `processo`, `tribunal`, `orgao`, `data`, `triagem.urgencia`, `triagem.ato`, `triagem.prazo.fim`, `ia.resumo`, `ia.acao`, `link`).

Formato:
- Linha 1: `Radar DD/MM — N publicações novas (X críticas, Y altas) · N processos consultados · N parados`.
- Tabela **Prioridades** (até 8): Urgência · Processo · Ação · Prazo estimado (+ "restam N dias") · Resumo em uma linha.
- **Execução penal (SEEU)**: se houver intimações de Vara de Execução Penal / VEP / Vara de Execuções Criminais ou classes "Execução da Pena", "Execução Provisória da Pena", "Execução de Medidas Alternativas", "Execução de Pena de Multa", destaque-as em bloco próprio — chegaram pelo DJEN porque o SEEU está integrado a ele desde 2021.
- Alertas de andamento (processos GARGALO/ATENÇÃO), se houver. Para execução penal, se o Radar avisar que o andamento não está sincronizado no DataJud daquele tribunal, diga que a consulta é manual no SEEU (o Radar dá o link).
- Avisos de coleta, se houver.
- Última linha: caminho do PDF e status do e-mail (`enviado para …` / `não enviado — motivo`). Ofereça abrir: `criminalradar abrir`.

Lembre em uma frase: os prazos penais são estimativas em **dias corridos** (CPP 798), prorrogados para o 1º dia útil quando vencem em sábado, domingo ou feriado, suspensos no recesso de 20/12 a 20/01 (CPP 798-A) — salvo réu preso, Maria da Penha e urgência, que o Radar sinaliza quando detecta —, sem feriados locais — a data real pode ser posterior, nunca anterior (exceto se houver réu preso que o Radar não percebeu no recesso: confira); conferir prazo em dobro só nos itens da Defensoria Pública (o MP não tem dobro no processo penal). Se `prazos.intimacao_pessoal` está ativo, o relatório já avisa: a publicação no DJEN é só informativa — o prazo conta da intimação pessoal ou do acesso no Domicílio Judicial Eletrônico. O sistema prepara, o operador decide.

## Aprofundar

Se a pessoa quiser discutir uma publicação específica (o que fazer, tese, prazo exato), delegue ao agente `monitor-dje-djen` com o caminho do JSON e o `id` da publicação. Para o histórico completo de um processo, delegue ao agente `andamento-processual` com o número CNJ. Para uma intimação de **execução penal** (progressão, livramento, remição, falta grave, cálculo de pena…), delegue ao agente `execucao-penal-seeu` com o caminho do JSON e o `id`.
