---
name: agendar
description: Liga o envio automático do CriminalRadar todo dia no horário escolhido (launchd no macOS, cron no Linux, Agendador de Tarefas no Windows), verifica o agendamento ou o remove. Use quando o usuário quiser receber o relatório sozinho todo dia, mudar o horário ou parar o envio.
user-invocable: true
allowed-tools: Bash, Read
argument-hint: "[--hora HH:MM] [--dias uteis|todos] [--remover] [--status]"
---

# CriminalRadar · Agendar o CriminalRadar diário

1. Confira que está configurado: `criminalradar status --json` (`pendencias` deve estar vazio; senão, `/criminalradar:configurar`).
2. Confirme horário e dias (padrão: **07:30, dias úteis** — o DJEN disponibiliza as publicações de madrugada; 07:30 dá tempo de o Radar chegar antes do expediente forense e da primeira audiência). Como os prazos penais correm em dias corridos, pergunte se a pessoa prefere `--dias todos` para receber também aos sábados e domingos. Rode:
   `criminalradar agendar --hora HH:MM --dias uteis`
3. Verifique: `criminalradar agendar --status` (`instalado` e `carregado` = `true`, `proxima` com data/hora). Para testar sem esperar: `criminalradar agendar --executar` e, um minuto depois, `criminalradar status`.
4. Explique como funciona no sistema da pessoa:
   - **macOS (launchd)**: roda com o Claude Code fechado; o Mac pode estar bloqueado, mas precisa estar ligado. Se estiver dormindo, o job roda ao acordar; se estiver desligado, o Radar é recuperado automaticamente na próxima vez que o Claude Code abrir (o plugin verifica ao iniciar a sessão). Se o Mac fica fechado à noite, sugira `Ajustes > Bateria > Programar` para ligar às 07:25, ou um horário em que ele já esteja ligado.
   - **Linux (cron)** / **Windows (schtasks)**: mesma lógica; precisa da máquina ligada.
5. Remover: `criminalradar agendar --remover`.

**Alternativa sem depender do computador ligado:** se a pessoa mantém o app Claude aberto e a ferramenta de tarefas agendadas do Claude estiver disponível nesta sessão, você pode criar uma tarefa diária cujo prompt seja exatamente `Execute a skill /criminalradar:relatorio e resuma o resultado.` — deixe claro que ela só roda com o app aberto. O launchd continua sendo o caminho recomendado.
