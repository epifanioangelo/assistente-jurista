@echo off
rem CriminalRadar - instalador/atualizador (Windows)
setlocal
set "ORIGEM=%~dp0"
set "DESTINO=%USERPROFILE%\CriminalRadar\criminalradar"
echo ======================================================
echo   CriminalRadar - instalacao
echo ======================================================
rem Claude Code: a versao de terminal (claude) ou a embutida no app do Claude para computador (aba Code).
set "CLAUDE_BIN="
where claude >nul 2>nul && set "CLAUDE_BIN=claude"
if not defined CLAUDE_BIN (
  for /f "delims=" %%F in ('dir /b /s /o:n "%APPDATA%\Claude\claude-code\claude.exe" 2^>nul') do set "CLAUDE_BIN=%%F"
)
if not defined CLAUDE_BIN (
  for /f "delims=" %%F in ('dir /b /s /o:n "%LOCALAPPDATA%\Claude\claude-code\claude.exe" 2^>nul') do set "CLAUDE_BIN=%%F"
)
if not defined CLAUDE_BIN (
  echo Claude Code nao encontrado.
  echo   Instale o app do Claude ^(https://claude.ai/download^), entre com a sua conta, abra a aba Code uma vez e rode este instalador de novo.
  echo   ^(Ou instale o Claude Code de terminal: https://claude.com/claude-code^)
  pause & exit /b 1
)
if not "%CLAUDE_BIN%"=="claude" echo Usando o Claude Code embutido no app do Claude.
where python >nul 2>nul || where python3 >nul 2>nul || ( echo Python 3 nao encontrado. Instale em python.org marcando "Add to PATH" e rode de novo. & pause & exit /b 1 )
if exist "%DESTINO%" ( echo Atualizando instalacao existente... & rmdir /s /q "%DESTINO%" )
mkdir "%DESTINO%" 2>nul
robocopy "%ORIGEM%." "%DESTINO%" /E /XD __pycache__ tests ferramentas /XF instalar.cmd instalar.command >nul
call "%CLAUDE_BIN%" plugin marketplace remove criminalradar >nul 2>nul
call "%CLAUDE_BIN%" plugin marketplace add "%DESTINO%" >nul
call "%CLAUDE_BIN%" plugin list 2>nul | findstr /C:"criminalradar@criminalradar" >nul
if errorlevel 1 (
  call "%CLAUDE_BIN%" plugin install criminalradar@criminalradar >nul
) else (
  rem reinstala sempre: garante que o cache do Claude Code receba os arquivos novos mesmo sem mudanca de versao
  call "%CLAUDE_BIN%" plugin uninstall criminalradar@criminalradar >nul 2>nul
  call "%CLAUDE_BIN%" plugin install criminalradar@criminalradar >nul
)
echo Plugin instalado. Configuracao (se existia) preservada em %USERPROFILE%\.criminalradar
echo.
echo Proximos passos no Claude (aba Code - reinicie o app se ja estava aberto):
echo   /criminalradar:configurar   -^> OAB, e-mails e horario
echo   /criminalradar:agendar      -^> relatorio todo dia, sozinho
pause
