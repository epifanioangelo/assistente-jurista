# CriminalRadar

**Todo dia, antes da primeira audiência, você sabe exatamente o que o Judiciário publicou para a sua carteira criminal — inclusive na execução penal — e o que está parado.**

O CriminalRadar é o plugin do CriminalRadar para o Claude Code que transforma o DJEN (com as intimações do SEEU) e a DataJud em um relatório executivo diário: cada publicação classificada por urgência, cada prazo penal estimado em dias corridos com a base legal, cada processo parado apontado. Em PDF, na sua caixa de entrada, no horário que você escolher. Sem depender de ninguém lembrar de "olhar o diário". O sistema prepara; quem manda continua sendo você.

---

## O que chega na sua caixa de entrada

Um e-mail com o relatório completo do dia e um **PDF executivo** com:

- **Prioridades do dia** — as publicações críticas e altas, cada uma com: o que o juízo determinou (em uma frase clara), a ação exigida, o prazo estimado com a base legal (CPP, LEP, Lei 8.038/90, Lei 9.099/95, CPC nos recursos aos tribunais superiores) e quantos dias restam.
- **Todas as publicações novas** — tabela completa: data, processo, tribunal, órgão, tipo do ato, ação, urgência (CRÍTICA · ALTA · MÉDIA · BAIXA · CANCELADA), prazo. Cada processo é link para o documento no tribunal.
- **Agenda** — audiências de instrução, custódia, plenário do júri, justificação e admonitória, sessões de julgamento e perícias extraídas do texto das publicações, com data, hora, modalidade e link, em ordem cronológica.
- **Execução penal (SEEU)** — as intimações das Varas de Execução Penal em bloco próprio, com o incidente sinalizado e o link para consulta manual no SEEU.
- **Andamento processual (DataJud)** — último movimento, dias parado, status e alerta (GARGALO > 60 dias, ATENÇÃO > 30) dos processos cadastrados e dos que apareceram nas publicações; na execução penal, aviso quando o tribunal não sincroniza com a DataJud.
- **Checklist de hoje** — o que fazer com o que chegou.
- **Fontes, metodologia e avisos** — de onde veio cada dado, como cada prazo foi contado e o que falhou (se falhou). Transparência total.
- **Encarte do Núcleo de Prática Criminal com o Claude** — duas páginas finais sobre orquestração de squads jurídicos, com botão de WhatsApp (desligável em `relatorios.encarte`).

Publicação já relatada não volta a aparecer. Se um serviço do CNJ estiver fora, o Radar entrega o que conseguiu e avisa. Se nada rodar, você recebe um e-mail de falha — silêncio nunca é resposta.

## Como funciona

```
07:30 ─▶ DJEN (Comunica API do CNJ)      ─▶ publicações por OAB / processo / parte — inclusive as intimações do SEEU
     ─▶ triagem determinística            ─▶ polo (defesa × acusação) · ato exigido · urgência · prazo penal (CPP 798)
     ─▶ IA (Claude, opcional)             ─▶ resumo e ação em linguagem clara
     ─▶ DataJud (API pública do CNJ)      ─▶ andamento · dias parado · gargalos · execução sincronizada?
     ─▶ PDF + e-mail                       ─▶ na sua caixa de entrada
```

- **Triagem que sabe de que lado da mesa você está**: o Radar identifica a sua parte e o polo em cada publicação (pelo cabeçalho, pela comunicação, pelos assistidos/adversários habituais que ele aprende sozinho e pelo papel configurado — defesa, acusação ou misto), isola o que o juízo escreveu e só conta prazos dirigidos a você — "intime-se o MP para contrarrazões" não vira prazo da defesa; "com a resposta, intime-se…" fica sinalizado como condicionado. Calibrada às cegas por um painel de quatro processualistas penais sobre 60 publicações criminais reais do DJEN: 93% de urgência exata, 98% dentro de um nível e 98% de acerto no prazo (com o papel predominante configurado).
- **Motor determinístico** em Python 3 (só biblioteca padrão — nada para instalar). Rede, classificação, contagem de prazos, PDF e envio são código, não improviso.
- **Agendamento nativo** do sistema (launchd no macOS, cron no Linux, Agendador no Windows): roda com o Claude fechado. Se o computador estava desligado no horário, o Radar é recuperado automaticamente quando o Claude Code abre.
- **IA só enriquece, nunca bloqueia**: os resumos usam o Claude Code que você já tem (modelo Haiku, rápido e barato); sem IA o Radar segue com trechos do texto oficial.
- **E-mail sem senha**: sai pelo conector do Gmail já autorizado no claude.ai. O e-mail é o relatório completo (prioridades, agenda, todas as publicações, andamento, checklist e o encarte do Núcleo); o PDF fica salvo na máquina, com o caminho no e-mail.
- **Dados 100% locais**: `~/.criminalradar/` (configuração com permissão 600, estado, logs, PDFs). Só o seu e-mail recebe o relatório.

## SEEU: o que é automático e o que não é

- O **SEEU** (Sistema Eletrônico de Execução Unificado, Res. CNJ 280/2019) concentra mais de 70% das execuções penais do país — cerca de 1,2 milhão de processos em 33 tribunais.
- **Intimações — pelo DJEN, onde o tribunal ativou a integração.** Desde 2021 o SEEU tem integração com o DJEN (manual oficial em docs.seeu.pje.jus.br): a intimação de advogado expedida no SEEU vai para o Diário e chega pela **mesma busca por OAB** que o Radar faz na Comunica API do CNJ. Classes típicas: "Execução da Pena", "Execução Provisória da Pena", "Execução de Medidas Alternativas", "Execução de Pena de Multa"; órgãos "Vara de Execução Penal", "VEP", "Vara de Execuções Criminais". **Mas a integração não está ativa em todos os tribunais** — veja a tabela abaixo.
- **Andamento — parcial.** A DataJud cobre a execução penal de forma **desigual por tribunal** (tabela abaixo). O Radar informa, por processo, quando o andamento de execução penal não está sincronizado e manda consultar no SEEU.
- **Autos — manual.** A consulta pública do SEEU (seeu.pje.jus.br) fica atrás de verificação anti-robô e o webservice do SEEU exige credenciais institucionais, indisponíveis para advogados. **Não há leitura automática dos autos do SEEU.** O Radar oferece o link para você abrir manualmente (com login/certificado para os autos).
- **Resumo honesto**: SEEU → **sim** pelo DJEN nos tribunais que ativaram a integração (intimações, automático) + DataJud (andamento, quando o tribunal sincroniza) + link para consulta manual; **não** há leitura automática dos autos; em TJPE, TJMT, TJSE, TJAP e TRF3 a verificação não encontrou intimações do SEEU no DJEN — nesses, o painel do SEEU continua obrigatório.

**Cobertura verificada tribunal a tribunal (11/09/2026).** Para cada tribunal, tomamos 25 execuções penais ("Execução da Pena", classe do SEEU) com movimento recente na DataJud e perguntamos ao DJEN se houve comunicação publicada para elas nos últimos 120 dias. Nem todo movimento gera intimação — por isso a leitura é qualitativa: "sim" = 8 ou mais das 25; "parcial" = 3 a 7; "fraca" = 1 ou 2; **"não" = zero** (forte indício de que o tribunal ainda não publica as intimações do SEEU no Diário).

| Tribunal | Intimações do SEEU no DJEN | Andamento na DataJud (execuções; atualizadas em 60 dias) |
|---|---|---|
| TJSP | **sim** (10/25) | boa — 2,8 milhões; 369 mil |
| TJMG | **sim** (13/25; 10 citam o SEEU) | boa — 563 mil; 147 mil |
| TJGO | **sim** (11/25) | boa — 58 mil; 10 mil |
| TJPA | **sim** (8/25; 5 citam o SEEU) | boa — 70 mil; 17 mil |
| TJDFT | **sim** (10/25) | fraca — 41 processos |
| TJAL | **sim** (8/25) | parcial — 7 mil; 43 |
| TJPI | **sim** (8/25) | boa — 1,8 mil; todos |
| TRF2 | **sim** (17/25; 9 citam o SEEU) | boa — 6,2 mil; 333 |
| TRF6 | **sim** (9/25; 6 citam o SEEU) | parcial — 643; 33 |
| TJBA | parcial (6/25) | parcial — 2,6 mil; 377 |
| TJSC | parcial (5/25; 4 citam o SEEU) | parcial — 69 mil; 1,7 mil |
| TJRJ | parcial (4/25) | boa — 6,5 mil; 3,7 mil |
| TJRR | parcial (4/25) | boa — 14,6 mil; todos |
| TJAM | parcial (3/25) | boa — 16,7 mil; 14,4 mil |
| TJTO · TJCE · TJRO · TJAC · TJMS · TRF5 | fraca (1/25 cada) | TJTO 21 mil; TJCE 2,8 mil; TJRO 62 mil; TJAC 41 mil (22); TJMS 36 mil (190); TRF5 440 (376) |
| **TJPE · TJMT · TJSE · TJAP · TRF3** | **não** (0/25) | TJPE 8 mil (29); TJMT 37 mil (todos); TJSE 33 mil (5 mil); TJAP 1,8 mil (todos); TRF3 13 mil (20) |
| TJPR · TJRS · TJPB · TJMA | sem dados (a DataJud não recebe a classe "Execução da Pena" desses tribunais) | — |
| TJRN · TJES · TRF1 · TRF4 | sem dados (menos de 3 execuções com movimento recente na amostra) | TJES 791 (0); TRF4 39 mil (0); TRF1 86 (2) |
| Justiça Militar (STM, TJMMG, TJMRS) | sem dados | STM 2,4 mil (22); TJMMG 650 (todos); TJMRS 241 (todos) |

O Radar usa essa tabela: se a sua OAB é de um tribunal marcado como **não** (ou se aparece uma execução penal dele), o relatório traz um aviso para conferir o painel do SEEU e o Domicílio Judicial Eletrônico. A tabela é uma fotografia de 11/09/2026 e será refeita a cada versão.


## Prazos penais

O Radar conta os prazos penais em **dias corridos** (CPP 798): publicação no DJEN no 1º dia útil após a disponibilização e início no 1º dia útil seguinte (Lei 11.419/06 art. 4º §§3º-4º); se o prazo vence em sábado, domingo ou feriado, prorroga para o 1º dia útil (CPP 798 §3º para domingo e feriado; Lei 1.408/51 art. 3º para o sábado; Súmula 310 STF para o início na sexta). **Recesso**: o prazo penal fica **suspenso de 20/12 a 20/01**, inclusive (CPP 798-A, Lei 14.365/2022) — o Radar aplica a suspensão por padrão e **não** a aplica quando detecta (I) réu preso, nos prazos vinculados à prisão, (II) procedimento da Lei Maria da Penha (Lei 11.340/2006) ou (III) medida urgente por despacho fundamentado, sinalizando a hipótese no relatório — confira. Prazo em dobro só para a **Defensoria Pública** (LC 80/94 arts. 44 I, 89 I, 128 I; Lei 1.060/50 art. 5º §5º); **o Ministério Público não tem prazo em dobro no processo penal** (STF HC 120.275), o defensor dativo também não, e no núcleo de prática jurídica o dobro é controverso — confira. **Intimação pessoal** (MP, Defensoria Pública, defensor dativo e núcleo de prática jurídica — CPP 370 §4º; LC 80/94 arts. 44 I, 89 I, 128 I; STJ EAREsp 2.841.872-DF): a publicação no DJEN é apenas informativa; o prazo conta da intimação pessoal ou do acesso no Domicílio Judicial Eletrônico (Res. CNJ 455/2022 arts. 11 §2º e 20 — sem acesso em 10 dias corridos, considera-se feita). Com `prazos.intimacao_pessoal=true` (`criminalradar configurar --set prazos.intimacao_pessoal=true`) o Radar acrescenta esse aviso a cada prazo do relatório.

| Ato | Prazo (dias corridos) | Base |
|---|---|---|
| Resposta à acusação · defesa prévia (Lei de Drogas) | 10 · 10 | CPP 396/396-A · Lei 11.343/06 art. 55 |
| Defesa preliminar de funcionário público | 15 | CPP 514 |
| Resposta em ação penal originária · alegações escritas em ação penal originária | 15 · 15 sucessivos | Lei 8.038/90 art. 4º · art. 11 |
| Alegações finais/memoriais · após diligência (CPP 402) | 5 · 5 sucessivos | CPP 403 §3º · CPP 404 p.ú. |
| Requerimento de diligências (CPP 402) | sem prazo legal — só o do despacho | CPP 402 |
| 1ª fase do júri — alegações finais | **orais** em audiência (20 min, prorrogáveis por 10); não há prazo de 5 dias por lei — só há memoriais se o juiz converter os debates, e então vale o prazo do despacho (por analogia, CPP 403 §3º) | CPP 411 §4º |
| Embargos de declaração — opor (1º grau · 2º grau · JECrim) | 2 · 2 · 5 — ED tempestivos **interrompem** o prazo dos demais recursos (Lei 9.099/95 art. 83 §2º no JECrim; CPC 1.026 por analogia no penal comum) | CPP 382 · CPP 619 · Lei 9.099/95 art. 83 §1º |
| Manifestação/contrarrazões sobre embargos de declaração | sem prazo legal no CPP — só quando o despacho intimar; o Radar usa o prazo do despacho e, na falta, 5 (estimativa conservadora) | CPC 1.023 §2º por analogia |
| Apelação · razões/contrarrazões · apelação no JECrim (com razões) · contrarrazões no JECrim | 5 · 8 · 10 · 10 | CPP 593 · CPP 600 · Lei 9.099/95 art. 82 §1º · art. 82 §2º |
| Apelação supletiva do assistente de acusação | 15 (não habilitado) · 5 (habilitado), após esgotado o prazo do MP | CPP 598; Súmula 448 STF |
| Recurso em sentido estrito · razões/contrarrazões | 5 · 2 | CPP 586 · CPP 588 |
| Embargos infringentes e de nulidade | 10 | CPP 609 p.ú. |
| Carta testemunhável | 48 horas | CPP 640 |
| Agravo em execução | 5 | Súmula 700 STF (a LEP 197 só prevê o recurso, sem fixar prazo) |
| Recurso ordinário em HC (RHC) | 5 | Lei 8.038/90 art. 30 |
| Recurso ordinário em MS (RMS) | 15 | Lei 8.038/90 art. 33; CPC 1.027-1.028 |
| REsp/RE em matéria penal · contrarrazões | 15 · 15 (dias corridos no penal — STJ) | CPC 1.003 §5º e 1.029 · CPC 1.030 (aplicáveis pelo CPP 3º; contagem corrida por força do CPP 798; a Lei 8.038/90 art. 26 foi revogada pelo CPC/2015, art. 1.072 IV) |
| Agravo contra inadmissão de REsp/RE penal (AREsp/ARE) · contrarrazões | 15 · 15 | CPC 1.042 c/c 1.003 §5º · CPC 1.042 §3º (entendimento atual do STF e do STJ; Súmula 699 STF — superada pelo CPC/2015; Lei 8.038/90 art. 28 — revogado pelo CPC/2015, art. 1.072 IV) |
| Embargos de divergência | 15 | CPC 1.003 §5º c/c 1.043; RISTJ 266 |
| Agravo regimental/interno | 5 | Lei 8.038/90 art. 39; RISTJ 258; RISTF 317 |
| Mandado de segurança criminal (impetração) | 120 dias, decadencial | Lei 12.016/09 art. 23 |
| Pena de multa (pagamento) | 10 do trânsito em julgado | CP 50 |
| Execução penal — manifestação em incidentes (cálculo/atestado, progressão, livramento, remição, saída temporária, falta grave/regressão) | prazo fixado no despacho e, na falta, 3 (prazo legal supletivo) · audiência de justificação/admonitória = evento com data | LEP art. 196 |
| Revisão criminal · habeas corpus | sem prazo | — |
| Queixa-crime · representação | decadência de 6 meses; 12 meses nos crimes de violência doméstica contra a mulher. Prazo **material**: calendário comum, inclui o dia do começo, sem prorrogação e sem suspensão no recesso (não vem pelo DJEN) | CPP 38 · CPP 38 §2º (Lei 15.438/2026) · CP 10 |

**São estimativas conservadoras**: feriados estaduais, municipais e forenses e suspensões por portaria **não** são descontados de propósito — a data estimada pode ser anterior à real, nunca posterior. A única suspensão aplicada é a do recesso (CPP 798-A), retirada quando o Radar detecta réu preso, Lei 11.340/2006 ou urgência; se o réu está preso e o Radar não percebeu, a suspensão não cabe e a data real é anterior à estimada — por isso o relatório sinaliza a hipótese, e a conferência é sua. Publicação cível que cair na carteira (indenização, família, improbidade) é contada em dias úteis pelo CPC.

## Instalação em 3 passos

**Pré-requisitos:** Claude Code logado — o app do Claude para computador (aba Code) já o inclui; a versão de terminal também serve · Python 3.9+ (o macOS pergunta se quer instalar na primeira vez: `xcode-select --install`) · o conector **Gmail** conectado em claude.ai (é por ele que o e-mail sai).

1. **Instale o plugin**: descompacte o zip recebido e dê **duplo clique em `instalar.command`** (Mac) ou `instalar.cmd` (Windows). O instalador registra o plugin no Claude Code; quando chegar uma versão nova, rode o mesmo instalador — configuração, histórico e agendamento são preservados (`/criminalradar:atualizar` orienta).
2. **Configure em 3 minutos:** `/criminalradar:configurar` — OAB(s), processos (inclusive execuções penais), papel (defesa, acusação ou misto), janela de busca, e-mails de destino, horário. O assistente testa cada etapa (DJEN, DataJud, e-mail) e gera o primeiro Radar na hora.
3. **Ligue o piloto automático:** `/criminalradar:agendar` — todo dia útil às 07:30 (ou todos os dias, já que prazo penal corre no fim de semana).

Guia detalhado, sem termos técnicos: [INSTALAR.md](INSTALAR.md).

## Comandos

| Comando | O que faz |
|---|---|
| `/criminalradar:configurar` | Primeira configuração e mudanças (OAB, processos, papel, e-mail, horário, IA, dobro da Defensoria, intimação pessoal) |
| `/criminalradar:relatorio` | Gera o Radar agora e mostra o resumo na conversa (`--dias N`, `--sem-email`, `--tudo`) |
| `/criminalradar:agendar` | Liga/desliga o envio automático diário; verifica o agendamento |
| `/criminalradar:status` | Diagnóstico: configuração, agenda, última execução, logs, teste das conexões |
| `/criminalradar:processos` | Cadastro do que é monitorado: OABs, processos (número CNJ, inclusive execução penal), partes por nome |
| `/criminalradar:atualizar` | Instala uma versão nova preservando tudo |
| `/criminalradar:ajuda` | Visão geral, prazos penais, SEEU e perguntas frequentes |

**Agentes** para análise aprofundada — o squad que o Claude aciona sozinho quando o assunto surge: `monitor-dje-djen` (triagem criminal e estratégia sobre publicações do DJEN), `andamento-processual` (histórico, status e gargalos via DataJud e demais plataformas) e `execucao-penal-seeu` (o incidente de execução por trás de uma intimação do SEEU: progressão, livramento, remição, falta grave, cálculo de pena, indulto, domiciliar, monitoração — com prazo, o que preparar e o que só se vê nos autos).

**CLI** (para quem prefere o terminal ou quer integrar): `criminalradar rodar | status | testar | agendar | oab | processos | partes | buscar-djen | consultar-datajud | prazo | abrir`. Contagem avulsa: `criminalradar prazo DATA DIAS --penal [--reu-preso] [--dobro]` — dias corridos com suspensão no recesso (CPP 798-A); `--reu-preso` conta sem a suspensão; no CriminalRadar, `prazo` sem flag já conta como penal.

## O que o Radar faz — e o que não faz

- Faz: monitorar, classificar, estimar, priorizar, lembrar, entregar. Todo dia, do mesmo jeito, sem esquecer.
- Não faz: substituir a leitura integral da intimação, a contagem oficial do prazo no sistema do tribunal, a intimação pessoal do MP, da Defensoria, do defensor dativo e do núcleo de prática jurídica (para eles a publicação no DJEN é só informativa), nem a responsabilidade do operador (EAOAB art. 32). Não lê os autos do SEEU. Não redige a peça no seu lugar — prepara o material; a tese, a revisão e a assinatura são suas.
- Cobertura: DJEN cobre STJ, TST, TSE, STM, TRFs, TRTs, TREs, TJs e TJMs — e as intimações do SEEU; **STF fica fora** (DJe próprio) e também não está na DataJud. Processos em segredo de justiça, inquéritos sigilosos e processos físicos não aparecem nas APIs públicas.

## Segurança e privacidade

- Configuração em `~/.criminalradar/config.json` com permissão 600. Nenhuma senha de e-mail: o envio sai pelo conector do Gmail do claude.ai.
- As consultas usam apenas APIs públicas do CNJ (DJEN e DataJud — chave pública oficial publicada pelo próprio CNJ; pode ser sobrescrita em `datajud.api_key`).
- Nada é enviado a servidores do CriminalRadar. O resumo por IA roda no Claude Code do próprio usuário. Nomes de assistidos e números de processo ficam na sua máquina.

## Para desenvolvedores

```
criminalradar/
├── .claude-plugin/plugin.json · marketplace.json
├── marca.json                          # identidade do produto (nome, pastas, cores, oferta, perfil criminal)
├── bin/criminalradar                   # wrapper da CLI (entra no PATH do Claude)
├── scripts/                            # CLI e motor (stdlib): djen, datajud, cnj, prazos, classificar, ia, pdf, e-mail, agendador…
├── skills/{configurar,relatorio,agendar,status,processos,ajuda,atualizar}/SKILL.md
├── agents/{monitor-dje-djen,andamento-processual,execucao-penal-seeu}.md
└── hooks/hooks.json · session-start.sh # recuperação do Radar do dia ao abrir o Claude
```

Rodar sem instalar: `claude --plugin-dir /caminho/criminalradar`. Ambiente isolado para testes: `CRIMINALRADAR_HOME=/tmp/cs ./bin/criminalradar …`.

## Licença e suporte

© CriminalRadar. Uso licenciado aos clientes CriminalRadar; redistribuição não autorizada. Dúvidas e suporte pelos canais oficiais do CriminalRadar.
