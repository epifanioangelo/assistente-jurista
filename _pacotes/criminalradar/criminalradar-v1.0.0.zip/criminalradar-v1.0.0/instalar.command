#!/bin/bash
# CriminalRadar — instalador/atualizador (macOS: duplo clique; Linux: bash instalar.command)
# Instala (ou atualiza) o plugin no Claude Code. A configuração, o estado e o agendamento ficam em ~/.criminalradar e são preservados.
set -e
ORIGEM="$(cd "$(dirname "$0")" && pwd)"
DESTINO="$HOME/CriminalRadar/criminalradar"
echo "══════════════════════════════════════════════════════"
echo "  CriminalRadar — instalação"
echo "══════════════════════════════════════════════════════"
# Claude Code: a versão de terminal (`claude`) ou a embutida no app do Claude para computador (aba Code).
CLAUDE_BIN="$(command -v claude 2>/dev/null || true)"
if [ -z "$CLAUDE_BIN" ]; then
  for c in /opt/homebrew/bin/claude /usr/local/bin/claude "$HOME/.claude/local/claude" "$HOME/.local/bin/claude"; do [ -x "$c" ] && CLAUDE_BIN="$c" && break; done
fi
if [ -z "$CLAUDE_BIN" ]; then
  CLAUDE_BIN="$(ls "$HOME/Library/Application Support/Claude/claude-code"/*/claude.app/Contents/MacOS/claude "$HOME/.config/Claude/claude-code"/*/claude 2>/dev/null | sort -V | tail -1 || true)"
  [ -n "$CLAUDE_BIN" ] && echo "→ Usando o Claude Code embutido no app do Claude."
fi
if [ -z "$CLAUDE_BIN" ] || [ ! -x "$CLAUDE_BIN" ]; then
  echo "✘ Claude Code não encontrado."
  echo "  Instale o app do Claude (https://claude.ai/download), entre com a sua conta, abra a aba Code uma vez e rode este instalador de novo."
  echo "  (Ou instale o Claude Code de terminal: https://claude.com/claude-code)"
  read -r -p "Enter para sair" _; exit 1
fi
if ! command -v python3 >/dev/null 2>&1; then echo "✘ Python 3 não encontrado. No macOS rode:  xcode-select --install   (ou instale em python.org) e rode de novo."; read -r -p "Enter para sair" _; exit 1; fi
VERSAO="$(python3 -c "import json;print(json.load(open('$ORIGEM/.claude-plugin/plugin.json'))['version'])")"
echo "→ Versão do pacote: $VERSAO"
mkdir -p "$(dirname "$DESTINO")"
if [ -d "$DESTINO" ]; then
  ATUAL="$(python3 -c "import json;print(json.load(open('$DESTINO/.claude-plugin/plugin.json'))['version'])" 2>/dev/null || echo "?")"
  echo "→ Instalação existente ($ATUAL) será atualizada para $VERSAO"
  rm -rf "$DESTINO.old"; mv "$DESTINO" "$DESTINO.old"
fi
mkdir -p "$DESTINO"
# copia o plugin (sem testes, caches e o próprio instalador)
( cd "$ORIGEM" && tar --exclude='./__pycache__' --exclude='*/__pycache__' --exclude='./scripts/tests' --exclude='./instalar.command' --exclude='./instalar.cmd' --exclude='./ferramentas' -cf - . ) | ( cd "$DESTINO" && tar -xf - )
rm -rf "$DESTINO.old"
chmod +x "$DESTINO/bin/criminalradar" "$DESTINO/hooks/session-start.sh" 2>/dev/null || true
echo "→ Registrando no Claude Code…"
ATUAL_MKT="$(python3 -c "import json,os;d=json.load(open(os.path.expanduser('~/.claude/plugins/known_marketplaces.json')));print((d.get('criminalradar') or {}).get('source',{}).get('path',''))" 2>/dev/null || true)"
if [ "$ATUAL_MKT" = "$DESTINO" ]; then
  "$CLAUDE_BIN" plugin marketplace update criminalradar >/dev/null 2>&1 || true
else
  [ -n "$ATUAL_MKT" ] && "$CLAUDE_BIN" plugin marketplace remove criminalradar >/dev/null 2>&1 || true
  "$CLAUDE_BIN" plugin marketplace add "$DESTINO" >/dev/null
fi
if "$CLAUDE_BIN" plugin list 2>/dev/null | grep -q "criminalradar@criminalradar"; then
  # mesma versão já instalada (hotfix sem bump)? o "update" diz "já está na versão" e não copia nada — reinstala para atualizar o cache
  INST_VER="$("$CLAUDE_BIN" plugin list 2>/dev/null | grep -A1 'criminalradar@criminalradar' | grep -o 'Version: [^ ]*' | cut -d' ' -f2)"
  if [ "$INST_VER" = "$VERSAO" ]; then
    "$CLAUDE_BIN" plugin uninstall criminalradar@criminalradar >/dev/null 2>&1; "$CLAUDE_BIN" plugin install criminalradar@criminalradar >/dev/null
  else
    "$CLAUDE_BIN" plugin update criminalradar@criminalradar -y >/dev/null 2>&1 || { "$CLAUDE_BIN" plugin uninstall criminalradar@criminalradar >/dev/null 2>&1; "$CLAUDE_BIN" plugin install criminalradar@criminalradar >/dev/null; }
  fi
else
  "$CLAUDE_BIN" plugin install criminalradar@criminalradar >/dev/null
fi
INSTALADA="$("$CLAUDE_BIN" plugin list 2>/dev/null | grep -A1 'criminalradar@criminalradar' | grep -o 'Version: .*' || echo "Version: ?")"
echo "✔ Plugin instalado ($INSTALADA)."
# se já havia agendamento, o launcher resolve o novo caminho sozinho; só regrava para garantir
if [ -f "$HOME/.criminalradar/config.json" ]; then
  echo "→ Configuração existente preservada em ~/.criminalradar"
  if [ -f "$HOME/Library/LaunchAgents/com.criminalradar.radar.plist" ] || crontab -l 2>/dev/null | grep -q criminalradar; then
    "$DESTINO/bin/criminalradar" agendar >/dev/null 2>&1 && echo "→ Agendamento diário confirmado."
  fi
fi
echo
echo "Próximos passos no Claude (aba Code — reinicie o app se já estava aberto):"
echo "  /criminalradar:configurar   → OAB, e-mails e horário (3 minutos)"
echo "  /criminalradar:agendar      → relatório todo dia, sozinho"
echo "  /criminalradar:ajuda        → como funciona"
echo
read -r -p "Enter para fechar" _
