# Instalar o CriminalRadar

Tempo total: **10 minutos**. Você não precisa saber programar — o Claude conduz cada etapa.

## Antes de começar, tenha à mão

1. **Claude Code** — o app do Claude para computador (claude.ai/download) já o inclui na aba **Code**: instale, entre com a sua conta (Pro, Max, Team ou Enterprise) e abra a aba Code uma vez. A versão de terminal (`claude`) também serve.
2. **Número da OAB** (e UF) de quem será monitorado — pode ser mais de uma (sócios, associados, núcleo).
3. **E-mails que vão receber o Radar** (você, sócios, secretaria, gabinete).
4. **Gmail conectado ao Claude**: em claude.ai → Configurações → Conectores, conecte o "Gmail". É por ele que o Radar envia o e-mail — sem senha nenhuma.
5. **Python 3** (o motor do Radar). No Mac, se o Claude avisar que falta, rode `xcode-select --install` e aceite; no Windows, instale em python.org marcando "Add to PATH".

## Passo 1 — Instalar o plugin

1. Descompacte o zip que você recebeu (duplo clique).
2. Abra a pasta e dê **duplo clique em `instalar.command`** (Mac) — ou `instalar.cmd` (Windows). Se o Mac perguntar se pode abrir, confirme (ou clique com o botão direito → Abrir). O plugin é copiado para `~/CriminalRadar/criminalradar`.
3. Reinicie o Claude Code. Digite `/criminalradar:ajuda` — se responder, está instalado.

**Nova versão?** Rode o instalador do zip novo. Nada se perde: OAB, e-mails, papel, histórico e agendamento ficam em `~/.criminalradar`.

## Passo 2 — Configurar

Digite `/criminalradar:configurar` e responda às perguntas: OAB, processos (opcional — inclusive o número da execução penal), papel predominante (defesa, acusação ou misto), quantos dias para trás buscar, e-mails, horário. O Claude testa a conexão com o DJEN e a DataJud, envia um e-mail de teste e gera o **primeiro Radar** (cobre os últimos 7 dias). Abra o PDF e veja se faz sentido para a sua carteira.

Se você é da Defensoria Pública, diga isso: o Radar passa a contar em dobro (LC 80/94). Quem atua pela acusação não tem dobro no processo penal — e o Radar sabe. Se você tem prerrogativa de **intimação pessoal** (Defensoria, MP, defensor dativo, núcleo de prática jurídica), diga também: o Radar passa a avisar, em cada prazo, que a publicação no DJEN é só informativa e que a contagem oficial parte da intimação pessoal ou do acesso no Domicílio Judicial Eletrônico.

## Passo 3 — Ligar o envio automático

Digite `/criminalradar:agendar`. Padrão: todo dia útil às 07:30. Como prazo penal corre em dias corridos, você pode pedir "todos os dias" para receber também no fim de semana. Pronto: o Radar chega sozinho.

**Importante (Mac):** o computador precisa estar ligado no horário (pode estar bloqueado). Se estiver dormindo, o Radar roda quando ele acordar; se estiver desligado, é recuperado na próxima vez que você abrir o Claude Code. Dica: `Ajustes do Sistema → Bateria → Programar` para ligar às 07:25.

## Dia a dia

- `/criminalradar:relatorio` — quer ver agora? Gera e resume na conversa.
- `/criminalradar:processos` — "adiciona o processo X", "monitora a OAB do Dr. Y", "cadastra a execução do fulano".
- `/criminalradar:status` — o e-mail não chegou? Diagnóstico completo e teste das conexões.
- Pergunte ao Claude sobre qualquer publicação do dia ("o que eu faço com a intimação do processo X?") — o agente `monitor-dje-djen` responde com prazo em dias corridos, base legal e providência.
- Intimação da Vara de Execução Penal? Pergunte "o que é essa intimação da VEP" — o agente `execucao-penal-seeu` identifica o incidente (progressão, livramento, remição, falta grave…), o prazo do agravo e o que só se vê nos autos do SEEU.

## Problemas comuns

| Sintoma | Causa provável | Solução |
|---|---|---|
| O Radar não chegou | computador desligado no horário; Gmail desconectado do Claude; spam | abra o Claude Code (recupera sozinho); reconecte o Gmail em claude.ai → Conectores; veja o spam; `/criminalradar:status` |
| Publicação que vi no DJEN não apareceu | já relatada em dia anterior; OAB/UF errada; indexação atrasada | `/criminalradar:relatorio --tudo --dias 7 --sem-email`; confira a OAB; aguarde o dia seguinte |
| Intimação do SEEU não apareceu | mesmas causas acima; intimação pessoal (Defensoria/MP/dativo/núcleo de prática) ou dirigida a outro advogado | as intimações de advogado do SEEU saem no DJEN — confira a OAB; intimação pessoal não passa pelo DJEN |
| "processo não localizado na DataJud" | segredo de justiça, físico, STF, tribunal atrasado; execução penal em tribunal que não sincroniza | confirmar no sistema do tribunal; execução penal: consultar no SEEU (seeu.pje.jus.br) |
| O prazo veio diferente do que contei | dias corridos (CPP 798) sem feriado local nem portaria de suspensão; no recesso (20/12 a 20/01) o prazo fica suspenso (CPP 798-A), salvo réu preso, Maria da Penha e urgência — o Radar sinaliza quando não suspende | confira no tribunal (e se o réu está preso); fora do recesso a estimativa nunca é posterior à data real |
| "Python 3 não encontrado" | motor não instalado | Mac: `xcode-select --install` · Windows: python.org |

Suporte: canais oficiais do CriminalRadar.
