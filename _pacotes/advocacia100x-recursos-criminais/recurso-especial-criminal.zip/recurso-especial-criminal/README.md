# Instalação universal — Recurso Especial Criminal (REsp — STJ)

Este pacote é portátil. O arquivo `SKILL.md` contém as instruções principais; as pastas `references/`, `scripts/`, `assets/` e `evals/`, quando presentes, são complementares.

## Como usar

1. Em um cliente compatível com Agent Skills, instale a pasta inteira mantendo sua estrutura.
2. Em ChatGPT, Claude, Gemini, Microsoft Copilot, OpenRouter ou outra LLM com upload de arquivos, envie `SKILL.md` e apenas os complementos necessários.
3. Em uma interface sem upload, cole o conteúdo de `SKILL.md` antes do pedido e forneça os dados do caso separadamente.
4. Ferramentas citadas são opcionais. Sem integração disponível, peça à LLM que gere um plano ou minuta sem executar ações externas.

## Segurança

Use somente dados autorizados e minimizados. Confirme legislação e precedentes em fonte oficial atual. Nenhuma resposta substitui revisão profissional humana, e nenhuma ação externa deve ocorrer sem aprovação explícita.
