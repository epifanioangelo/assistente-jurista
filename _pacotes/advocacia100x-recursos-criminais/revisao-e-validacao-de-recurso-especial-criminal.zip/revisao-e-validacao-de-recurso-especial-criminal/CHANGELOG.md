# Changelog — Revisão e Validação de Recurso Especial Criminal

## 1.0.0-universal (20/09/2026)
- Pacote universal (contrato universal 1.1): `SKILL.md` com bloco de compatibilidade, `README.md`, `references/high-performance-contract.md` e `references/fontes-oficiais-transcritas.md`.

## 1.0.0 (20/09/2026)
- Primeira edição, derivada da skill cível de revisão de recurso especial (v3.0.0) e adaptada ao processo penal: CPP, art. 638 (remissão ao CPC e ao RISTJ), art. 798 (dias corridos), art. 609, parágrafo único (embargos infringentes), art. 617 (reformatio in pejus), art. 806 (custas e deserção na ação privada); Lei 11.636/2007, art. 7º; LC 80/94 (Defensoria: intimação pessoal e dobro); STF, HC 120.275 (MP sem dobro); STJ, HC 482.549 (HC com recurso pendente); REsp 1.595.636/RN (sem recurso adesivo); Súmulas 115, 203 e 640; Temas 1.214 e 1.423.
- Regime de relevância (Lei 15.484/2026 e ER STJ 55/2026, em vigor desde 03/09/2026) aplicado à ação penal: presunção do art. 105, § 3º, I, da CF não dispensa o tópico; execução penal como presunção incerta; técnica de caso concreto nas Turmas; resumo estruturado não exigível na 3ª Seção (IN 42/2026, art. 2º, parágrafo único).
