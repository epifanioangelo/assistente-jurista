# Instalação universal — Revisão e Validação de Recurso Especial Criminal — Edição Especialista V1.0

Este pacote é portátil. O arquivo `SKILL.md` contém as instruções principais; a pasta `references/` é complementar: `references/fontes-oficiais-transcritas.md` traz os textos oficiais transcritos (Lei 15.484/2026, Emenda Regimental STJ 55/2026, IN STJ/GP 42/2026, CPC, CPP, LEP, LC 80/94, Lei 11.636/2007, CF, súmulas e precedentes criminais) e `references/high-performance-contract.md` traz o contrato operacional do perfil de análise jurídica.

## Como usar

1. Em um cliente compatível com Agent Skills, instale a pasta inteira mantendo sua estrutura.
2. Em ChatGPT, Claude, Gemini, Microsoft Copilot, OpenRouter ou outra LLM com upload de arquivos, envie `SKILL.md` e, se quiser as transcrições literais à mão, `references/fontes-oficiais-transcritas.md`.
3. Em uma interface sem upload, cole o conteúdo de `SKILL.md` antes do pedido e forneça o recurso, o acórdão recorrido e a data de publicação separadamente.
4. Ferramentas citadas são opcionais. Sem integração disponível, peça à LLM que produza o veredito por bloco sem executar ações externas.

## O que esta skill faz

Audita um recurso especial criminal já redigido, bloco a bloco (cabimento penal, prequestionamento, dialeticidade, Súmula 126, dissídio, relevância da questão federal na ação penal, prazo em dias corridos, custas e formalidades, precedente qualificado), e devolve um veredito estruturado com o que sanar antes do protocolo, inclusive a decisão sobre a via paralela do habeas corpus. Depois da inadmissão, indica qual recurso cabe contra cada fundamento de negativa de seguimento. Cobre o regime de relevância em vigor desde 03/09/2026 (Lei 15.484/2026 e Emenda Regimental STJ 55/2026) aplicado ao processo penal pelo CPP, art. 638.

## Segurança

Use somente dados autorizados e minimizados. Confirme legislação e precedentes em fonte oficial atual. Nenhuma resposta substitui revisão profissional humana, e nenhuma ação externa deve ocorrer sem aprovação explícita.

## Versão

1.0.0-universal, redigida em 20/09/2026, com revisão prevista até 20/10/2026 (ver `CHANGELOG.md`).
