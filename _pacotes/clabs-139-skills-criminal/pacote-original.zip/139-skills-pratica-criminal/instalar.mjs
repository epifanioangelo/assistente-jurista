#!/usr/bin/env node
// Instalador — 139 Skills de Prática Criminal para o Claude Code (© Criminal Lab)
// Copia as skills para ~/.claude/skills/ e os agentes para ~/.claude/agents/,
// SEM sobrescrever nada que você já tenha. Funciona em Windows, macOS e Linux.
//   Como usar:  node instalar.mjs
import { cpSync, existsSync, mkdirSync, readdirSync } from 'node:fs';
import { homedir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const AQUI = dirname(fileURLToPath(import.meta.url));
const CLAUDE = join(homedir(), '.claude');

const major = Number(process.versions.node.split('.')[0]);
if (major < 18) {
  console.error(`\n  ❌ Seu Node.js é a versão ${process.versions.node}. Instale o Node 18 ou superior`);
  console.error('     (baixe a versão LTS em https://nodejs.org) e rode de novo: node instalar.mjs\n');
  process.exit(1);
}

function instalarPasta(origem, destinoBase, tipo) {
  if (!existsSync(origem)) return { instalados: 0, preservados: 0 };
  mkdirSync(destinoBase, { recursive: true });
  let instalados = 0;
  let preservados = 0;
  for (const entry of readdirSync(origem, { withFileTypes: true })) {
    const de = join(origem, entry.name);
    const para = join(destinoBase, entry.name);
    if (existsSync(para)) {
      preservados++; // nunca sobrescreve o que o usuário já tem
      continue;
    }
    cpSync(de, para, { recursive: true });
    instalados++;
  }
  console.log(`  ✓ ${tipo}: ${instalados} instalado(s)${preservados ? ` · ${preservados} já existiam (preservados)` : ''}`);
  return { instalados, preservados };
}

console.log('\n  ⚖️  139 Skills de Prática Criminal para o Claude Code — Criminal Lab\n');
const s = instalarPasta(join(AQUI, 'skills'), join(CLAUDE, 'skills'), 'Skills (peças e institutos)');
const a = instalarPasta(join(AQUI, 'agents'), join(CLAUDE, 'agents'), 'Agentes especialistas');

console.log(`\n  ✅ Pronto! ${s.instalados + a.instalados} item(ns) instalados em ${CLAUDE}`);
console.log('\n  Próximos passos:');
console.log('  1. Feche e reabra o Claude Code (ou abra uma conversa nova).');
console.log('  2. Peça em linguagem natural — ex.: "prepare um habeas corpus", "monte a apelação",');
console.log('     "calcule a prescrição", "prepare a audiência de custódia de amanhã".');
console.log('  3. As skills são acionadas automaticamente pelo contexto do seu pedido.');
console.log('\n  ⚠️  Toda peça gerada é RASCUNHO TÉCNICO: a revisão e a responsabilidade final');
console.log('     são sempre do(a) advogado(a). Confira cada citação antes de protocolar.\n');
